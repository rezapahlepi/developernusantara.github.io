<?php
include "config/koneksi.php";
include "config/library.php";
include "config/fungsi_indotgl.php";
include "config/fungsi_combobox.php";
include "config/class_paging.php";

// Bagian Home
if ($_GET[module]=='home'){
  echo "<h2>Welcome $_SESSION[namauser]</h2>
          <p>Please choose the option at your left </p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>";
  echo "</p>";
}

// Bagian Profil Lembaga
elseif ($_GET[module]=='profil'){
  $sql  = mysql_query("SELECT * FROM modul WHERE id_modul='11'");
  $r    = mysql_fetch_array($sql);

  echo "<h2>Profil Lembaga</h2>
        <form method=POST enctype='multipart/form-data' action=aksi2.php?module=profil&act=update>
        <input type=hidden name=id value=$r[id_modul]>
        <table>
        <tr><td><img src=foto_berita/$r[gambar]></td></tr>
        <tr><td>Ganti Foto : <input type=file size=30 name=fupload></td></tr>
        <tr><td><textarea name=isi cols=94 rows=30>$r[static_content]</textarea></td></tr>
        <tr><td><input type=submit value=Update></td></tr>
        </form></table>";
}

// Bagian User
elseif ($_GET[module]=='user'){
  include "admin/modul/mod_user.php";
}

// Bagian Modul
elseif ($_GET[module]=='modul'){
  include "modul/mod_modul.php";
}

// Bagian Agenda
elseif ($_GET[module]=='agenda'){
  include "modul/mod_agenda.php";
}

// Bagian Berita
elseif ($_GET[module]=='berita'){
  include "../mod_berita.php";
}


// Bagian Local
elseif ($_GET[module]=='local'){
  include "../mod_local.php";
}

// Bagian Pengumuman
elseif ($_GET[module]=='umum'){
  include "modul/mod_pengumuman.php";
}


// Bagian Banner
elseif ($_GET[module]=='banner'){
  include "modul/mod_banner.php";
}

// Bagian Hubungi Kami
elseif ($_GET[module]=='hubungi'){
  include "modul/mod_hubungi.php";
}

// Bagian upload
elseif ($_GET[module]=='upload'){
  include "modul/mod_upload.php";
}

// Bagian music player
elseif ($_GET[module]=='mp'){
  include "modul/mod_mp.php";
}

// Bagian music player
elseif ($_GET[module]=='vp'){
  include "modul/mod_vp.php";
}
// Bagian about us
elseif ($_GET[module]=='about'){
  $sql  = mysql_query("SELECT * FROM modul WHERE id_modul='32'");
  $r    = mysql_fetch_array($sql);

  echo "<h2>Profil Lembaga</h2>
        <form method=POST enctype='multipart/form-data' action=aksi2.php?module=about&act=update>
        <input type=hidden name=id value=$r[id_modul]>
        <table>
        <tr><td><img src=foto_berita/$r[gambar]></td></tr>
        <tr><td>Ganti Foto : <input type=file size=30 name=fupload></td></tr>
        <tr><td><textarea name=isi cols=94 rows=30>$r[static_content]</textarea></td></tr>
        <tr><td><input type=submit value=Update></td></tr>
        </form></table>";
}
// Bagian upload
elseif ($_GET[module]=='gallery'){
  include "admin/modul/mod_gallery.php";
}
// modul profile
elseif ($_GET[module]=='profile'){
include "admin/modul/mod_profile.php";}

// modul frenz
elseif ($_GET[module]=='friend'){
  include "admin/modul/mod_friend.php";
}
elseif ($_GET[module]=='search'){
  include "search.php";
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA</b></p>";
}
?>
