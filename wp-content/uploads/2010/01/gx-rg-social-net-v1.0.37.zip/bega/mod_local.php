<script language='JavaScript' type='text/javascript' src='./tiny_mce/tiny_mce.js'></script>
<script language='JavaScript' type='text/javascript'>
/// setup dan inialisasi editor teks
	

	// O2k7 skin
	tinyMCE.init({
		// General options
		mode : "textareas",
		elements : "elm2",
		theme : "advanced",
		skin : "o2k7",
		plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,inlinepopups",

		// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,code,",
		theme_advanced_buttons3 : "sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl|,insertdate,inserttime,preview,|,forecolor,backcolor,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,justifyleft,justifycenter,justifyright,justifyfull",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		content_css : "css/content.css",

		// Drop lists for link/image/media/template dialogs
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "lists/image_list.js",
		media_external_list_url : "lists/media_list.js",

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});</script>
<?php

switch($_GET[act]){
  // Tampil Berita
  default:
    echo "<h2>Lokal Art</h2>
          <input type=button value='Tambah Berita' onclick=location.href='?module=local&act=tambahlocal'>
          <table>
          <tr><th>no</th><th>judul</th><th>Kategori</th><th>tgl. posting</th><th>aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    if ($_SESSION[leveluser]=='admin'){
      $tampil = mysql_query("SELECT * FROM berita  WHERE id_kategori>=10 ORDER BY id_berita DESC limit $posisi,$batas");
    }
    else{
      $tampil=mysql_query("SELECT * FROM berita 
                          WHERE id_kategori>=9 AND id_user='$_SESSION[namauser]'       
                           ORDER BY id_berita DESC");
    }
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
      $tgl_posting=tgl_indo($r[tanggal]);
      $kata=$r[id_kategori];
      echo "<tr><td>$no</td>
                <td><a href=?module=berita&act=editberita&id=$r[id_berita]>$r[judul]</a></td>
                <td>$kata</td>
                <td>$tgl_posting</td>
		            <td><a href=./aksi.php?module=berita&act=hapus&id=$r[id_berita]>Hapus</a></td>
		        </tr>";
      $no++;
    }
    echo "</table>";
  
    if ($_SESSION[leveluser]=='admin'){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM berita"));
    }
    else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM berita WHERE id_user='$_SESSION[namauser]'"));
    }  
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>$linkHalaman</div><br>";
    break;
  
  case "tambahlocal":
    echo "<h2>Tambah Berita Local Art</h2>
          <form method=POST action='./admin/aksi.php?module=berita&act=input' enctype='multipart/form-data'>
          <table>
          <tr><td>Judul</td>     <td> : <input type=text name='judul' size=60></td></tr>
          <tr><td>Kategori</td>  <td> : 
          <select name='kategori'>
            <option value=0 selected>- Pilih Kategori -</option>";
            $tampil=mysql_query("SELECT * FROM kategori WHERE id_kategori>=10 ORDER BY nama_kategori");
            while($r=mysql_fetch_array($tampil)){
              echo "<option value=$r[id_kategori]>$r[nama_kategori]</option>";
            }
    echo "</select></td></tr>
          <tr><td>Isi Berita</td><td> : <textarea name='isi_berita' cols=80 rows=30 style='width:100%'></textarea></td></tr>
          <tr><td>Cover</td>    <td> : <input type=file name='fupload' size=40></td></tr>
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
    
  case "editberita":
    $edit = mysql_query("SELECT * FROM berita WHERE id_berita='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

    echo "<h2>Edit Berita</h2>
          <form method=POST enctype='multipart/form-data' action=./admin/aksi.php?module=berita&act=update>
          <input type=hidden name=id value=$r[id_berita]>
          <table>
          <tr><td>Judul</td>     <td> : <input type=text name='judul' size=40 value='$r[judul]'></td></tr>
          <tr><td>Kategori</td>  <td> : <select name='kategori'>";
 
    $tampil=mysql_query("SELECT * FROM kategori ORDER BY nama_kategori");
    while($w=mysql_fetch_array($tampil)){
      if ($r[id_kategori]==$w[id_kategori]){
        echo "<option value=$w[id_kategori] selected>$w[nama_kategori]</option>";
      }
      else{
        echo "<option value=$w[id_kategori]>$w[nama_kategori]</option>";
      }
    }
    echo "</select></td></tr>
          <tr><td>Isi Berita</td><td> : <textarea name='isi_berita' cols=80 rows=30 style='width:100%'>$r[isi_berita]</textarea></td></tr>
          <tr><td>Cover</td><td> : <img src='./admin/foto_berita/$r[gambar]' width=300 height=300 hspace=10 border=0></td></tr>
         <tr><td>Ganti Cover</td>    <td> : <input type=file name='fupload' size=30> *)</td></tr>
         <tr><td colspan=2>*) Apabila gambar tidak diubah, dikosongkan saja.</td></tr>
         <tr><td colspan=2><input type=submit value=Update>
                           <input type=button value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
?>
