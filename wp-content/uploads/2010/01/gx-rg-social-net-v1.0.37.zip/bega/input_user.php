<?php
include "config/koneksi.php";
//Enkripsi password sebelum disimpan di database

$reg=mysql_query("SELECT * FROM user WHERE id_user='$_POST[id_user]' OR password='$_POST[password]'");
$ketemu=mysql_num_rows($reg);
// Apabila username dan password ditemukan
if ($ketemu > 0)
{
echo "<b>Username,password,nama lengkap atau email sudah terdaftar. <br>Silahkan ganti profile anda.</b>
<br><a href='register.php'>BACK</a>";
}
else{
mysql_query("INSERT INTO user(id_user,password,nama_lengkap,tgl_lhr,address) VALUES('$_POST[id_user]','$_POST[password]','$_POST[nama_lengkap]','$_POST[tgl_lhr]','$_POST[address]')");
header('location:index.php');
}
?>
