<?php
session_start();
include "config/koneksi.php";
include "config/library.php";

$module=$_GET[module];
$act=$_GET[act];


// Menghapus data
if (isset($module) AND $act=='hapus'){
  mysql_query("DELETE FROM ".$module." WHERE id_".$module."='$_GET[id]'");
  header('location:media3.php?module='.$module);
}

// Menghapus friend
elseif ($module=='friend' AND $act=='del'){
mysql_query("DELETE FROM friend WHERE username1='$_SESSION[namauser]' AND username2='$_GET[id]'");
mysql_query("DELETE FROM friend WHERE username2='$_SESSION[namauser]' AND username1='$_GET[id]'");
header('location:media3.php?module='.$module);
}

// Menambah friend
elseif ($module=='friend' AND $act=='add'){
mysql_query("INSERT INTO friend (username1,username2) VALUES ('$_SESSION[namauser]','$_GET[id]')");
mysql_query("INSERT INTO friend (username1,username2) VALUES ('$_GET[id]','$_SESSION[namauser]')");
header('location:media3.php?module='.$module);
}

// Menambah comment sendiri
elseif ($module=='profile' AND $act=='komen'){
mysql_query("INSERT INTO comment (pengirim,penerima,comment) VALUES ('$_SESSION[namauser]','$_GET[id]','$_POST[koment]')");
header('location:media3.php?module='.$module);
}

// Menambah comment teman
elseif ($module=='friend' AND $act=='komen'){
mysql_query("INSERT INTO comment (pengirim,penerima,comment) VALUES ('$_SESSION[namauser]','$_GET[id]','$_POST[koment]')");
header('location:media3.php?module='.$module);
}


// Menghapus comment
elseif ($module=='profile' AND $act=='delkom'){
mysql_query("DELETE FROM comment WHERE id_comment='$_GET[id]'");
header('location:media3.php?module='.$module);
}


// Input user
elseif ($module=='user' AND $act=='input'){
  $pass=md5($_POST[password]);
  mysql_query("INSERT INTO user(id_user,
                                password,
                                nama_lengkap,
                                email) 
	                       VALUES('$_POST[id_user]',
                                '$pass',
                                '$_POST[nama_lengkap]',
                                '$_POST[email]')");
  header('location:media3.php?module='.$module);
}

// Update user
elseif ($module=='user' AND $act=='update'){
  // Apabila password tidak diubah
  if (empty($_POST[password])) {
    mysql_query("UPDATE user SET id_user      = '$_POST[id_user]',
                                 nama_lengkap = '$_POST[nama_lengkap]',
                                 email        = '$_POST[email]'  
                           WHERE id_user      = '$_POST[id]'");
  }
  // Apabila password diubah
  else{
    $pass=md5($_POST[password]);
    mysql_query("UPDATE user SET id_user      = '$_POST[id_user]',
                                 password     = '$pass',
                                 nama_lengkap = '$_POST[nama_lengkap]',
                                 email        = '$_POST[email]'  
                           WHERE id_user      = '$_POST[id]'");
  }
  header('location:media3.php?module='.$module);
}

// Update profile
elseif ($module=='profile' AND $act=='update'){
  // Apabila password tidak diubah
  if (empty($_POST[password])) {
    mysql_query("UPDATE user SET id_user      = '$_POST[id_user]',
                                 nama_lengkap = '$_POST[nama_lengkap]',
                                 tgl_lhr      = '$_POST[tgl_lhr]',
								 address	  = '$_POST[address]'
                           WHERE id_user      = '$_POST[id]'");
  }
  // Apabila password diubah
  else{
    $pass=md5($_POST[password]);
    mysql_query("UPDATE user SET id_user      = '$_POST[id_user]',
                                 password     = '$pass',
                                 nama_lengkap = '$_POST[nama_lengkap]',
                                 tgl_lhr      = '$_POST[tgl_lhr]',
								 address	  = '$_POST[address]'
                           WHERE id_user      = '$_POST[id]'");
  }
  header('location:media3.php?module='.$module);
}

// update gambar
elseif ($module=='profile' AND $act=='editgambar'){
// baca variabel
$tipe_file = $_FILES['fupload']['type'];
$lokasi_file = $_FILES['fupload']['tmp_name'];
$nama_file = $_FILES['fupload']['name'];
$ukuran_file = $_FILES['fupload']['size'];
$direktori = "imgs/$nama_file";

//jika nama file sudah ada
if (file_exists($direktori)){
echo "upload gagal !!! <br>
Nama file <b>$nama_file</b> sudah ada<br>
Ganti dulu nama filenya agar bisa di upload";
}
else{
// jika tipe file bukan jpeg
if ($tipe_file != "image/gif" AND
$tipe_file != "image/jpeg" AND
$tipe_file != "image/pjpeg" AND
$tipe_file != "image/png"){
echo "upload gagal !!! <br>
Tipe file <b>$nama_file</b> : $tipe_file <br>
Tipe file yang boleh di upload : gif,jpg, dan png.";
}
else{
//Tentukan lebar dan panjang
$lebar_max=500;
$panjang_max=500;

//dapatkan ukuran gambar yg di upload
$ukuran_gbr = GetImageSize($lokasi_file);

//jika ukuran gambar > lebar & panjang
if (($ukuran_gbr[0] > $lebar_max) OR
($ukuran_gbr[1] > $panjang_max)){
echo "Upload Gagal !!!<br>
Ukuran gambar : <b>$ukuran_gbr[0] x $ukuran_gbr[1]</b> <br>
Ukuran gambar tidak boleh > $lebar_max x $panjang_max.";
}
else{
$url       = "http://localhost/bega/imgs";
move_uploaded_file($lokasi_file,"$direktori");
echo "Nama File        : <b>$nama_file</b> sukses di upload<br>";
echo "Tipe Filenya     : <b>$tipe_file</b><br><br>";
echo "<img src=$url/$nama_file>
<a href=media3.php?module=profile>BACK</a>";
// masukan ke database
include "config/koneksi.php";

mysql_query("UPDATE user SET gambar='$nama_file' WHERE id_user= '$_SESSION[namauser]'");

}
}
}
}

// Input modul
elseif ($module=='modul' AND $act=='input'){
  mysql_query("INSERT INTO modul(nama_modul,
                                 link,
                                 publish,
                                 aktif,
                                 status,
                                 urutan) 
	                       VALUES('$_POST[nama_modul]',
                                '$_POST[link]',
                                '$_POST[publish]',
                                '$_POST[aktif]',
                                '$_POST[status]',
                                '$_POST[urutan]')");
  header('location:media.php?module='.$module);
}

// Update modul
elseif ($module=='modul' AND $act=='update'){
  mysql_query("UPDATE modul SET nama_modul = '$_POST[nama_modul]',
                                link       = '$_POST[link]',
                                publish    = '$_POST[publish]',
                                aktif      = '$_POST[aktif]',
                                status     = '$_POST[status]',
                                urutan     = '$_POST[urutan]'  
                          WHERE id_modul   = '$_POST[id]'");
  header('location:media.php?module='.$module);
}







?>
