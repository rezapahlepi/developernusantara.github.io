<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="config/adminstyle.css" media="screen,projection" />
<title>::: GX-RG Social Networking :::</title>
</head>

<body>
<div id="wrap">

<div id="header">
<p id="toplinks">Skip to: <a href="#content">Content</a> | <a href="#sidebar">Navigation</a> | <a href="#footer">Footer</a></p>
<h1><a href="index.php">GX<span class="fade">-RG</span></a></h1>
<p id="slogan">social networking web...</p>
</div>

<div id="content">
<h2>REGISTER HERE...</h2>
<form method=POST action=input_user.php>
<table>
<tr><td>Username</td>
<td> : <input type=text name='id_user'></td></tr>
<tr><td>Password</td>
<td> : <input type=password name='password'></td></tr>
<tr><td>Full Name</td>
<td> : <input type=text name='nama_lengkap' size=30></td></tr>
<tr><td>Birth Day</td>
<td> : <input type=text name='tgl_lhr' size=30></td></tr>
<tr><td>Address</td>
<td> : <input type=text name='address' size=30></td></tr>
<tr><td colspan=2><input type=submit name='prosesi' value=SUBMIT>
<input type=button value=CANCEL onclick=self.history.back()>
</td></tr>
</table>
</form></div>

<div id="sidebar">
<h2>Choose Here:</h2>
<ul class="links">
<li><a href="index.php"> back to index</a></li>
</ul>
</div>

<div id="footer">
<p><a href="about.php">About</a> | <a href="#">Privacy policy</a> | <a href="#">Sitemap</a> | <a href="#">RSS</a> | <a href="#header">Back to top</a><br />
Copyleft &copy; <a href="http://gxrg.org">GXRG.ORG</a> | Developed by <a href="http://shiro.gxrg.org">shiro.gxrg.org</a></p>
</div>

</div>
</body>
</html>











