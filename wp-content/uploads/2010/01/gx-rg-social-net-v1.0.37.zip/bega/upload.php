<?php
// baca variabel
$tipe_file = $_FILES['fupload']['type'];
$lokasi_file = $_FILES['fupload']['tmp_name'];
$nama_file = $_FILES['fupload']['name'];
$ukuran_file = $_FILES['fupload']['size'];

// jika tipe file bukan jpeg
if ($tipe_file != "image/gif" AND
$tipe_file != "image/jpeg" AND
$tipe_file != "image/pjpeg" AND
$tipe_file != "image/png"){
echo "upload gagal !!! <br>
Tipe file <b>$nama_file</b> : $tipe_file <br>
Tipe file yang boleh di upload : gif,jpg, dan png.";
}
else{
//Tentukan lebar dan panjang
$lebar_max=300;
$panjang_max=300;

//dapatkan ukuran gambar yg di upload
$ukuran_gbr = GetImageSize($lokasi_file);

//jika ukuran gambar > lebar & panjang
if (($ukuran_gbr[0] > $lebar_max) OR
($ukuran_gbr[1] > $panjang_max)){
echo "Upload Gagal !!!<br>
Ukuran gambar : <b>$ukuran_gbr[0] x $ukuran_gbr[1]</b> <br>
Ukuran gambar tidak boleh > $lebar_max x $panjang_max.";
}
else{
$direktori = "imgs/$nama_file";
$url       = "http://localhost/coba/imgs";
move_uploaded_file($lokasi_file,"$direktori");
echo "Nama File        : <b>$nama_file</b> sukses di upload<br>";
echo "Tipe Filenya     : <b>$tipe_file</b><br><br>";
echo "<img src=$url/$nama_file>
<a href=media3.php?module=profile>BACK</a>";
// masukan ke database
include "config/koneksi.php";

mysql_query("INSERT INTO foto(nama_file,ukuran_file,direktori,username) VALUES('$nama_file','$ukuran_file','$direktori','$_SESSION[namauser]')");

?> 















?>