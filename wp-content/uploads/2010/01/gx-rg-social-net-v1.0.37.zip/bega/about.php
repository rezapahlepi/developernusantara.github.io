<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="config/adminstyle.css" media="screen,projection" />
<title>::: GX-RG Social Networking :::</title>
</head>

<body>
<div id="wrap">

<div id="header">
<p id="toplinks">Skip to: <a href="#content">Content</a> | <a href="#sidebar">Navigation</a> | <a href="#footer">Footer</a></p>
<h1><a href="index.php">GX<span class="fade">-RG</span></a></h1>
<p id="slogan">social networking web...</p>
</div>

<div id="content">
<h2>About...</h2>
GX-RG adalah website jejaring sosial agar kita bisa berkomunikasi dengan semua orang berupa komentar dan dan mengupdate foto profile, baik dimanapun mereka berada, melalui internet yang perkembangannya makin pesat setiap harinya. 
<br><br>
<h2>GX-RG GNU License</h2>
GX-RG didistribusikan secara gratis (no guarantee) dan dengan kode terbuka,siapapun berhak mengembangkan website ini asalkan selalu menyertai code sumber dalam pendistribusiannya.
<br><br>
<h2>GX-RG Bug</h2>
Apabila terdapat kesalahan script atau bug dan ingin membantu dalam perkembangan GX-RG silahkan kirim pesan ke email saya.
<br><br>
<h2>GX-RG Developer</h2>
Name  :5h1r0<br>
Email : shiro.gx@gmail.com
<br><br>





</div>

<div id="sidebar">
<h2>Choose Here:</h2>
<ul class="links">
<li><a href="index.php"> back to index</a></li>
</ul>
</div>

<div id="footer">
<p><a href="#">About</a> | <a href="#">Privacy policy</a> | <a href="#">Sitemap</a> | <a href="#">RSS</a> | <a href="#header">Back to top</a><br />
Copyleft &copy; <a href="http://gxrg.org">GXRG.ORG</a> | Developed by <a href="http://shiro.gxrg.org">shiro.gxrg.org</a></p>
</div>

</div>
</body>
</html>











