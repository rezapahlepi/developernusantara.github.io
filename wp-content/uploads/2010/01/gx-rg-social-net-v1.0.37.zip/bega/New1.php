<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>----Index----</title>

<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#000000">
<table style="width:400px;height:550px" align="center" border="0">
  <tr>
	<td>
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			   codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0"
			   width="400" height="550">
		<param name="movie" value="g.swf"> 
		<param name="quality" value="high">
		<param name="menu" value="false">
		<!--[if !IE]> <-->
		<object data="g.swf"
				width="400" height="550" type="application/x-shockwave-flash">
		 <param name="quality" value="high">
		 <param name="menu" value="false">
		 <param name="pluginurl" value="http://www.macromedia.com/go/getflashplayer">
		 FAIL (the browser should render some flash content, not this).
		</object>
		<!--> <![endif]-->
	   </object>
	</td>
  </tr>
</table>
</body>
</html>
