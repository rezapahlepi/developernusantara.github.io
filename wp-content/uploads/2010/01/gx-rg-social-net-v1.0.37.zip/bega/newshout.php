<?
//ambil nama yang memberikan komentar
$shoutby = $_POST['shoutby'];
if($shoutby == "Enter your name here"||$shoutby == ""){
  //tidak memasukkan nama
  $shoutby = "Visitor";
}
if($_POST['shout']){
  if($_POST['shout'] != "Komentar..."){
    $shout = $_POST['shout'];
    //pengamanan: mengganti < & > untuk mengamankan dari hack
    $shout = str_replace("<", " ", $shout);
    $shout = str_replace(">", " ", $shout);
    include_once("mysql.inc.php");
   
    // koneksi ke database
    $connection = @mysql_connect($host, $user, $password) or die(mysql_error());
    $db = @mysql_select_db($name,$connection) or die(mysql_error());
   
    //  masukkan komentar yang diberikan ke database
    $sql = "INSERT INTO `shouts`(`shoutby`,`shout`) VALUES('$shoutby','$shout')";
//close connection
$result = @mysql_query($sql,$connection);
  }
}
?>
<html>
<head>
</head>
<body>
<!-- onLoad="window.open('index.php','_self')"> -->
<script type="text/javascript">
<!--
window.location = "index.php"
//-->
</script>

</body>
</html>