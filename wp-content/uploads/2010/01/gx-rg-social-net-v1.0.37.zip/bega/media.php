<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="_your description goes here_" />
<meta name="keywords" content="_your,keywords,goes,here_" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" title="style (screen)" />
<title>SONiC</title>
<!--[if lte IE 6]>
<style type="text/css">
html, body
	{
	height: 100%;
	overflow: auto;
	}
#left {
	position: absolute; left: 0;
	width: 35%;
}

</style>
<![endif]-->
</head>

<body>
<div id="left">
 <div id="outer">
	<img class="lime" src="3.jpg" alt="" /><h1><span class="green">s</span>o<span class="yellow">n</span>ic.com</h1><br /><br />
	<a class="nav" href="#">login</a>
	<a class="nav" href="#">register</a>
 </div>
</div>

<div id="main">
<pre>










<?php
	include "kanan.php";
?>	










<span class="credit">&copy; 2009 sonic[dot]com develop by <a href="http://shiro.gxrg.org>shiro</a></span>
</div>

</pre>
</body>

</html>
