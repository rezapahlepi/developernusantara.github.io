-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 08, 2010 at 07:28 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gxrg`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id_comment` int(100) NOT NULL AUTO_INCREMENT,
  `pengirim` varchar(50) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id_comment`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id_comment`, `pengirim`, `penerima`, `comment`) VALUES
(22, 'gege', 'bambang', 'yo'),
(23, 'gege', 'beky', 'haii bek'),
(25, 'gege', 'gege', 'hMMM???'),
(29, 'gege', 'gege', 'coklah..\r\ngg banged loo!!!'),
(27, 'gege', 'bambang', 'coklh\r\n'),
(28, 'gege', 'bambang', '<!--');

-- --------------------------------------------------------

--
-- Table structure for table `friend`
--

CREATE TABLE IF NOT EXISTS `friend` (
  `id_friend` int(100) NOT NULL AUTO_INCREMENT,
  `username1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `username2` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_friend`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `friend`
--

INSERT INTO `friend` (`id_friend`, `username1`, `username2`) VALUES
(16, 'orange', 'gege'),
(15, 'gege', 'orange'),
(7, 'gege', 'bambang'),
(8, 'bambang', 'gege'),
(18, 'beky', 'gege'),
(17, 'gege', 'beky');

-- --------------------------------------------------------

--
-- Table structure for table `modul`
--

CREATE TABLE IF NOT EXISTS `modul` (
  `id_modul` int(5) NOT NULL AUTO_INCREMENT,
  `nama_modul` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `static_content` text COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `publish` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  `status` enum('user','admin') COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  `urutan` int(5) NOT NULL,
  PRIMARY KEY (`id_modul`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=40 ;

--
-- Dumping data for table `modul`
--

INSERT INTO `modul` (`id_modul`, `nama_modul`, `link`, `static_content`, `gambar`, `publish`, `status`, `aktif`, `urutan`) VALUES
(2, 'Manajemen User', '?module=user', '', '', 'N', 'admin', 'Y', 1),
(18, 'Write Info', '?module=berita', '', '', 'N', 'user', 'N', 4),
(10, 'Manajemen Modul', '?module=modul', '', '', 'N', 'admin', 'Y', 2),
(27, 'Write Local Art', '?module=local', '', '', 'N', 'user', 'N', 5),
(28, 'Upload File', '?module=upload', '', '', 'N', 'user', 'N', 6),
(34, 'Profile', '?module=profile', '', '', 'Y', 'user', 'Y', 3),
(35, 'Friends', '?module=friend', '', '', 'Y', 'user', 'Y', 4),
(38, 'Search', '?module=search', '', '', 'N', 'user', 'N', 8),
(39, 'FProfile', '?module=fprofile', '', '', 'N', 'user', 'N', 9),
(33, 'Upload Gallery', '?module=gallery', '', '', 'N', 'user', 'N', 7);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tgl_lhr` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'anonymous.jpg',
  `level` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `password`, `nama_lengkap`, `tgl_lhr`, `address`, `gambar`, `level`) VALUES
('orange', 'orange', 'orangegirl', '', '', 'anonymous.jpg', 'user'),
('beky', 'beky', 'beky dlema', '', '', 'anonymous.jpg', 'user'),
('bambang', 'bambang', 'bambang ajah', '16 agustus 1945', 'jonggol', 'anonymous.jpg', 'user'),
('gege', 'gege', 'gege luu', '17 Maret 1987', 'jonggol', 'anonymous.jpg', 'user'),
('admin', 'admin', 'Administrator', '', '', 'anonymous.jpg', 'admin'),
('ee', 'ee', 'ee', '18 jan 2009', 'xmla', 'anonymous.jpg', 'user');
