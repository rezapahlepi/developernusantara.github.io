<?php
session_start();
if (empty($_SESSION[namauser]) AND empty($_SESSION[passuser])){
  echo "<link href='config/adminstyle.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
}
else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="config/adminstyle.css" media="screen,projection" />
<title>::: GX-RG Social Networking :::</title>
</head>

<body>
<div id="wrap">

<div id="header">
<p id="toplinks">Skip to: <a href="#content">Content</a> | <a href="#sidebar">Navigation</a> | <a href="#footer">Footer</a></p>
<h1>GX<span class="fade">-RG</span></h1>
<p id="slogan">social networking web...</p>
</div>

<div id="content">
  <?php
		include"config/koneksi.php";
$url       = "http://localhost/bega/imgs";
$scr=$_GET[search];
if ($scr==""){
echo"<br><br><br><center>Maaf, username dengan kata kunci '<b>$scr</b>' tidak ditemukan.</center><br><br><br><br>
<input type=button value=Batal onclick=self.history.back()>";
}
else{
    $tampak=mysql_query("SELECT * FROM user WHERE id_user like '$scr%' ");
	$ada=mysql_num_rows($tampak);
	if ($ada > 0){
    echo "<h2>Search Friends</h2>
	          <table>
          <tr><th>no</th><th>foto</th><th>username</th><th>action</th></tr>"; 
    $no=1;
    while ($r=mysql_fetch_array($tampak)){
    $test=mysql_query("SELECT * FROM friend WHERE username1='$_SESSION[namauser]' AND username2='$r[id_user]'");
    $h=mysql_num_rows($test);
	   echo "<tr><td>$no</td>
             <td><img src='$url/$r[gambar]' width=50 heigth=75></td>
             <td>$r[id_user]</td>
             <td>";
			 if ($h > 0){
			 echo "Already Friend";}
			 else{echo "<a href=./aksi2.php?module=friend&act=add&id=$r[id_user]>Add as Friend</a>";
			 }
             echo "</td></tr>";
      $no++;
    }
  echo "</table>
  <input type=button value=Batal onclick=self.history.back()>";
}
else{
echo "<br><br><br><center>Maaf, username dengan kata kunci '<b>$scr</b>' tidak ditemukan.</center><br><br><br><br>
<input type=button value=Batal onclick=self.history.back()>";
}
}  
?>
</div>

<div id="sidebar">
</div>

<div id="footer">
<p><a href="#">Privacy policy</a> | <a href="#">Sitemap</a> | <a href="#">RSS</a> | <a href="#header">Back to top</a><br />
Copyleft &copy; <a href="http://gxrg.org">GXRG.ORG</a> | Developed by <a href="http://shiro.gxrg.org">shiro.gxrg.org</a></p>
</div>

</div>
</body>
</html>
























<?php
}
?>
