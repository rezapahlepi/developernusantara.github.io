<?php
$host    = 'localhost';
$user    = 'root';
$password = '12345';
$name    = 'shoutbox';
?>