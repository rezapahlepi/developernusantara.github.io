<table width=100% cellspacing=0 bgcolor="#ffffff">
<link rel="stylesheet" href="style.css" type="text/css" />
<script type="text/javascript" src="dolphin.js"></script><body>

<div id="dolphincontainer">
	<div id="dolphinnav">
	<ul>
	<li><a href="http://127.0.0.1/web/" rel="home"><span>Home</span></a></li>
	<li><a href="media.php?module=berita" rel="info"><span>Info</span></a></li>
	<li><a href="media.php?module=local" rel="local"><span>Local Art</span></a></li>
	<li><a href="media.php?module=gallery" rel="gallery"><span >Gallery</span></a></li>
	<li><a href="media.php?module=mv" rel="mv"><span >Music & Video</span></a></li>
	<li><a href="./forum" rel="forum"><span>Forum</span></a></li>
	<li><a href="media.php?module=about" rel="about"><span>About Us</span></a></li>
	<li><a href="media.php?module=hubungi" rel="contact"><span>Contact Us</span></a></li>
	</ul>
	
	</div>
	
	<!-- Sub Menus container. Do not remove -->
	<div id="dolphin_inner">
  <div id="home" class="innercontent">
	<a href="index.php">ttB[dot]com lastest news</a>
	</div>
	<div id="info" class="innercontent">
	Joey's statue of a white dog was originally given to Jennifer Aniston as a good luck present from her best friend.
	</div>

	<div id="local" class="innercontent">
	During this period, then-locally famous Suzy Waud anchored evening broadcasting.
	</div>

	<div id="gallery" class="innercontent">
	George Louis Costanza is a fictional character on the United States based television sitcom Seinfeld (1989�1998).
	</div>
	
		<div id="mv" class="innercontent">
	George Louis Costanza is a fictional character on the United States based television sitcom Seinfeld (1989�1998).
	</div>
	
	<div id="forum" class="innercontent">
	George Louis Costanza is a fictional chccaracter on the United States based television sitcom Seinfeld (1989�1998).
	</div>
  <div id="about" class="innercontent">
	We are the real Teru-TeruBouzu!! let's read About Us!!
  </div>
  <div id="contact" class="innercontent">
	For another information, Lets Contact Us!!
  </div>
	<!-- End Sub Menus container -->
	</div>

	</div>

<script type="text/javascript">

//dolphintabs.init("ID_OF_TAB_MENU_ITSELF", SELECTED_INDEX)
dolphintabs.init("dolphinnav", 1)

</script>
</td></tr>
		

</table>
</body>
