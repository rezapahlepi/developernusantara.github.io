<?php
$eet=mysql_query("INSERT INTO friend (username1,username2) VALUES ('$_SESSION[namauser]','$_GET[id]')");
$ett=mysql_query("INSERT INTO friend (username1,username2) VALUES ('$_GET[id]','$_SESSION[namauser]')");
?>