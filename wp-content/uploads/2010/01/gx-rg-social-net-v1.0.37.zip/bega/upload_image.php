<?php
//Fungsi untuk meng-upload gambar
function UploadImage($img_name){
header("Content-type: image/jpeg");

//direktori gambar
$vdir_upload = "imgs/";
$vfile_upload = $vdir_upload . $img_name;

//Simpan gambar dalam ukuran sebenarnya
move_uploaded_file($_FILES["img"]["tmp_name"], $vfile_upload);

//identitas file asli
$im_src = imagecreatefromjpeg($vfile_upload);
$src_width = imageSX($im_src);
$src_height = imageSY($im_src);

//Simpan dalam versi small 110 pixel
//set ukuran gambar hasil perubahan
$dst_width = 110;
$dst_height = ($dst_width/$src_width)*$src_height;

//proses perubahan ukuran
$im = imagecreatetruecolor($dst_width,$dst_height);
imagecopyresampled($im, $im_src, 0, 0, 0, 0, $dst_width, $dst_height, $src_width, $src_height);

//Simpan gambar
imagejpeg($im,$vdir_upload . "small_" . $img_name);

//Simpan dalam versi medium 320 pixel
//set ukuran gambar hasil perubahan
//$dst_width = 320;
//$dst_height = ($dst_width/$src_width)*$src_height;

//proses perubahan ukuran
$im = imagecreatetruecolor($dst_width,$dst_height);
imagecopyresampled($im, $im_src, 0, 0, 0, 0, $dst_width, $dst_height, $src_width, $src_height);

//Simpan gambar
imagejpeg($im,$vdir_upload . "medium_" . $img_name);

imagedestroy($im_src);
imagedestroy($im);
}
//Upload Gambar
UploadImage($_FILES["img"]["name"]);

include "config/koneksi.php";
mysql_query("UPDATE user SET gambar = '$_img_name' 
                           WHERE id_user      = '$_SESSION[username]'");
header('location:media3.php?module=profile');

?>

