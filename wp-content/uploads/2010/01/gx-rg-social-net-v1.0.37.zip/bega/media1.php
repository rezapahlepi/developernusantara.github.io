
<html>
<head>
<title>::: SONIC[dot]com - Social Networking :::</title>
<link href="config/adminstyle.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="header">
  <div id="content">
		<?php include "kanan.php"; ?>
        
          </div>

	<div id="menu">
      <ul>
        <li><a href=?module=login>&#187; Login</a></li>
        
        <li><a href=register.php>&#187; Register</a></li>
      </ul>
	    <p>&nbsp;</p>
  </div>

		<div id="footer">
			Copyright &copy; 2009 sonic.com<br>Developed by shiro.gxrg.org & orange89
		</div>
</div>
</body>
</html>
