<?php
  session_destroy();
  echo "<center><b>YOUR LOGOUT IS SUCCESSFULL<b>";

// Apabila setelah logout langsung menuju halaman utama website, aktifkan baris di bawah ini:


?>
