<table width=100% cellspacing=5>

<?php
include "config/koneksi.php";
//Menu index
$menu=mysql_query("SELECT * FROM modul WHERE publish='Y' and aktif='Y'ORDER BY urutan");
echo "<tr><td class=bullet>&bull; </td>
<td><div id=menu>
<a href=?module=home> Home</a></div></td></tr>";
while($r=mysql_fetch_array($menu)) {
echo "<tr><td class=bullet>&bull; </td>
<td><div id=menu>
<a href=$r[link]>&#187; $r[nama_modul]</a></div></td></tr>";
}
echo "<tr><td colspan=2><hr color=#265180></td></tr>";

?>
</table>