<html>
<head>
<title>::: SONIC[dot]com - Social Networking :::</title>
<link href="../config/adminstyle.css" rel="stylesheet" type="text/css" />
  <!-- wrap START -->
<div id="wrap">
<!-- container START -->
<div id="container">
</head>
<body>
<div id="header">
  <div id="content">

		<h2>Login</h2>
    <img src="images/login-welcome.gif" width="97" height="105" hspace="10" align="left">

<form method="POST" action="cek_login.php">
<table>
<tr><td>Username</td><td> : <input type="text" name="username"></td></tr>
<tr><td>Password</td><td> : <input type="password" name="password"></td></tr>
<tr><td colspan="2"><input type="submit" value="Login"></td></tr>
</table>
</form>

<p>&nbsp;</p>
  </div>
	<div id="footer">
		Copyright &copy; 2009 by shiro.gxrg.org
	</div>
</div>
</body>
</html>

