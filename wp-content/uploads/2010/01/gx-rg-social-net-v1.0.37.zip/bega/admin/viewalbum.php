<?php
session_start();
include "../config/koneksi.php";
include "../config/library.php";

$module=$_GET[module];
$act=$_GET[act];


// Menghapus data
if (isset($module) AND $act=='hapus1'){
  mysql_query("DELETE FROM ".$module." WHERE id_".$module."='$_GET[id]'");
  header('location:media.php?module='.$module);
}


// Input user
elseif ($module=='file' AND $act=='view'){
  echo "<script>var ofile='./upload/$_GET[id]'

if (document.all)
creditwindow=window.open(ofile,'','width=445,height=250')
else
creditwindow=window.open(ofile,'','width=445,height=250,scrollbars')"
  ;
}


?>
