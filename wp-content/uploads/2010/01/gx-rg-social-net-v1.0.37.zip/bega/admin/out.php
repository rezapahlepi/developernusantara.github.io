<html>
<head>
<title>::: SONIC[dot]com - Social Networking :::</title>
<link href="../config/adminstyle.css" rel="stylesheet" type="text/css" />
  <!-- wrap START -->
<div id="wrap">
<!-- container START -->
<div id="container">
</head>
<body>
<div id="header">
  <div id="content">
<?php include "logout.php" ?>
<p>&nbsp;</p>
  </div>
	<div id="footer">
		Copyright &copy; 2009 by shiro.gxrg.org
	</div>
</div>
</body>
</html>

