<h2>Upload Files</h2>
          
          <input type=button value='Tambah Files' onclick=location.href='javascript:openfile()'>
<?php
mysql_connect("localhost","root","");
mysql_select_db("db_sn");

?>

<h2>Files</h2>   
          <table><tr><th>Nama Files</th><th>Ukuran File</th><th>URL Lengkap</th><th>Aksi</th></tr>
    

<?php
    $p      = new Paging;
    $batas  = 15;
    $posisi = $p->cariPosisi($batas);
    $tampil = mysql_query("SELECT * FROM upload_file WHERE id_upload ORDER BY id_upload DESC limit $posisi,$batas");
    $no = $posisi+1;
while ($data=mysql_fetch_array($tampil)){
  echo "<tr><td>$data[nama_file]</td>
        <td>$data[ukuran_file] bytes</td><td>http://localhost/web/gudang/$data[nama_file]</td>
        <td><a href='./upload/hapus_file.php?id=$data[id_upload]&file=$data[direktori]'>Hapus</a> | <a href='http://localhost/web/gudang/$data[nama_file]'>View</a></td></tr>";
$no++;
}
echo "</table>";

$jmldata = mysql_num_rows(mysql_query("SELECT * FROM upload_file"));
    
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>$linkHalaman</div><br>";
?>

<script>

///////////////////////files
function openfile(){

var ofile="./upload/form_uploadfiles.php"

if (document.all)
creditwindow=window.open(ofile,"","width=445,height=250")
else
creditwindow=window.open(ofile,"","width=445,height=250,scrollbars")
}
</script>
