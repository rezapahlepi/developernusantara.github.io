	<?php
	echo "<h2>$_SESSION[namauser]'s Profile</h2><table>";
	$url       = "http://localhost/coba/imgs";
	$tampil=mysql_query("SELECT * FROM user WHERE id_user='$_SESSION[namauser]'");
    while ($r=mysql_fetch_array($tampil)){
	echo "<img src='$url/$r[gambar]'><br><br>
	<br><br>";
	}
    echo "</table>";
	echo "<h2>Comment's on $_SESSION[namauser]</h2>";
	echo "<form name='input' action='' method='get' id='input'><table><tr><td>
          <textarea name='koment' value='Comment here!!!' rows='5' cols='50'></textarea></td></tr><tr><td>
		  <input type='submit' value='submit' class=
          'buttons' ></td></tr></table>
        </form>";
    ?>