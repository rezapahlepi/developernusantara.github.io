<h2>Upload Gallery</h2>
<?php

if ($_SESSION[leveluser]=='admin'){
      echo "<input type=button value='Tambah Album' onclick=location.href='javascript:openalbum()'>
      <input type=button value='Tambah Photo Album' onclick=location.href='javascript:inputalbum()'>
          <input type=button value='Tambah Personal Photos' onclick=location.href='javascript:openphoto()'>";
    }
    else{
      echo "<input type=button value='Tambah Personal Photos' onclick=location.href='javascript:openphoto()'>";
    }
?>
          
<h2>Personal Photo</h2>   
          <table><tr><th>Photo</th><th>Keterangan</th><th>Aksi</th></tr>
    

<?php
    $p      = new Paging;
    $batas  = 5;
    $posisi = $p->cariPosisi($batas);
    $muka = mysql_query("SELECT * FROM personal WHERE id ORDER BY id DESC limit $posisi,$batas");
    $no = $posisi+1;
    while($z=mysql_fetch_array($muka)){
      
      echo "<tr><td><img src='upload/$z[photo]' width=150 height=120 hspace=10 border=0 align=left></td><td>$z[deskripsi]</td>";
      
      if ($_SESSION[leveluser]=='admin'){
      echo "<td><a href='./upload/hapus_photo.php?id=$z[id]&file=$z[photo]'>Hapus</a> | <a href='upload/$z[photo]'>View</a></td></tr> ";
    }
    else{
      echo " <td><a href='upload/$z[photo]'>View</a></td></tr> ";
    }  
        
        

		        echo "</tr>";
      $no++;
    }
    echo "</table>";
  
    
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM personal"));
    
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>$linkHalaman</div><br>";
    
    ////////////////////////////////////////

?>



<script>
//////////////photo
function openalbum(){

var photoalbum="./upload/form_uploadalbum.php"

if (document.all)
creditwindow=window.open(photoalbum,"","width=680,height=630")
else
creditwindow=window.open(photoalbum,"","width=680,height=630,scrollbars")
}

function openphoto(){

var photofile="./upload/form_uploadfoto.php"

if (document.all)
creditwindow=window.open(photofile,"","width=445,height=250")
else
creditwindow=window.open(photofile,"","width=445,height=250,scrollbars")
}

</script>
