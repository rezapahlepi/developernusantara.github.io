<h2>Upload Music</h2>
          
          <input type=button value='Tambah Music' onclick=location.href='javascript:openmusic()'>
          
<?php

mysql_connect("localhost","root","12345");
mysql_select_db("pintar");

?>

<h2>Music Files</h2>   
          <table><tr><th>Music</th><th>Nama Files</th><th>Ukuran File</th><th>Aksi</th></tr>
    

<?php

$p      = new Paging;
    $batas  = 5;
    $posisi = $p->cariPosisi($batas);
    $tampil = mysql_query("SELECT * FROM upload_music WHERE id_upload ORDER BY id_upload DESC limit $posisi,$batas");
    $no = $posisi+1;

while ($data=mysql_fetch_array($tampil)){
  echo "<tr><td>$data[nama_file]</td>
        <td>$data[deskripsi]</td>
        <td>$data[ukuran_file] bytes</td>";
      
      if ($_SESSION[leveluser]=='admin'){
        echo "<td><a href='./upload/hapus_music.php?id=$data[id_upload]&file=$data[direktori]'>Hapus</a> | <a href=''>View</a></td></tr>";
        }
    else{
      echo " <td><a href='upload/$data[direktori]'>View</a></td></tr> ";
    }  
$no++;
}
echo "</table>";
$jmldata = mysql_num_rows(mysql_query("SELECT * FROM upload_music"));
    
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>$linkHalaman</div><br>";
?>




<script>


///////////////////////music
function openmusic(){

var musicfile="./upload/form_uploadmusic.php"

if (document.all)
creditwindow=window.open(musicfile,"","width=550,height=250")
else
creditwindow=window.open(musicfile,"","width=550,height=250,scrollbars")
}


</script>
