<?php
switch($_GET[act]){
  // Tampil friend
  default:
$url       = "http://localhost/coba/imgs";
$scr=$_GET[search];
if ($scr==""){
echo"<br><br><br><center>Maaf, username dengan kata kunci '<b>$scr</b>' tidak ditemukan.</center><br><br><br><br>";
}
else{
    $tampak=mysql_query("SELECT * FROM user WHERE id_user like '$scr%' ");
	$ada=mysql_num_rows($tampak);
    if ($ada > 0){
    echo "<h2>Search Friends</h2>
	          <table>
          <tr><th>no</th><th>foto</th><th>username</th><th>action</th></tr>"; 
    $no=1;
    while ($s=mysql_fetch_array($tampak)){
       echo "<tr><td>$no</td>
             <td><img src='$url/$s[gambar]'></td>
             <td>$s[id_user]</td>
             <td><a href=./aksi2.php?module=friend&act=add&id=$s[id_user]>Add as Friend</a>
             </td></tr>";
      $no++;
    }
  echo "</table>";
}
else{
echo"<br><br><br><center>Maaf, username dengan kata kunci '<b>$scr</b>' tidak ditemukan.</center><br><br><br><br>";
}
}  
} 
?>
