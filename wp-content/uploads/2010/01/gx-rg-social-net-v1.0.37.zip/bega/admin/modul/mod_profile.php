<?php
switch($_GET[act]){
  // Tampil Profile
  default:
    echo "<h2>$_SESSION[namauser]'s Profile</h2><table>";
	$url       = "http://localhost/bega/imgs";
	$tampil=mysql_query("SELECT * FROM user WHERE id_user='$_SESSION[namauser]'");
    while ($r=mysql_fetch_array($tampil)){
	echo "<img src='$url/$r[gambar]' width=150 heigth=200><br><br>
	<a href=?module=profile&act=editgambar&id=$r[id_user] class='red'>Edit Picture</a><br><br>";
	echo("<b>Username	: $r[id_user]<br></b>");
	echo("<b>Full Name	: $r[nama_lengkap]<br></b>");
	echo("<b>Birth Day	: $r[tgl_lhr]<br></b>");
	echo("<b>Address	: $r[address]<br><br></b>");
	echo("<a href=?module=profile&act=editprofile&id=$r[id_user] class='red'>Edit</a><br><br>");
}
    echo "</table>";
	echo "<h2>Comment's on $_SESSION[namauser]</h2>";
	echo "<form name='input' action='./aksi2.php?module=profile&act=komen&id=$_SESSION[namauser]' method='post' id='input'><table><tr>
	<td colspan=2>
          <textarea name='koment' value='Comment here!!!' rows='5' cols='50'></textarea></td></tr><tr><td>
		  <input type='submit' value='submit' class=
          'buttons' ></td><td><input type='reset' name='reset' value='reset'></td></tr></table>
        </form>";
    echo "<table>";
    $k=mysql_query("SELECT * FROM comment WHERE penerima='$_SESSION[namauser]' ORDER BY id_comment DESC");
    while ($d=mysql_fetch_array($k)){
    echo " <tr>
             <td><b>$d[pengirim]</b> said: $d[comment]</td>
             <td><a href=./aksi2.php?module=profile&act=delkom&id=$d[id_comment]>Hapus</a></td></tr>";
      }
    echo "</table>";
    
	
	
	
	
	break;
    
  case "editprofile":
    $edit=mysql_query("SELECT * FROM user WHERE id_user='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<h2>Edit User</h2>
          <form method=POST action=./aksi2.php?module=profile&act=update>
          <input type=hidden name=id value='$r[id_user]'>
          <table>
          <tr><td>Username</td>     <td> : <input type=text name='id_user' value='$r[id_user]'></td></tr>
          <tr><td>Password</td>     <td> : <input type=text name='password'> *) </td></tr>
          <tr><td>Nama Lengkap</td> <td> : <input type=text name='nama_lengkap' value='$r[nama_lengkap]'></td></tr>
          <tr><td>Birth Day</td>       <td> : <input type=text name='tgl_lhr' value='$r[tgl_lhr]'></td></tr>
		  <tr><td>Address</td>     <td> : <input type=text name='address' size=30 value='$r[address]'></td></tr>
          <tr><td colspan=2>*) Apabila password tidak diubah, dikosongkan saja.</td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;
	
case "editgambar":
    $edit=mysql_query("SELECT * FROM user WHERE id_user='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<h2>Edit Picture</h2>
          <form method=POST action=./aksi2.php?module=profile&act=editgambar enctype='multipart/form-data'>
          Image (JPG/JPEG) <input name='fupload' type='file'/></td>
		  <input name='submit' type='submit' value='Upload' /><input type=button value=Batal onclick=self.history.back()>
          ";
    break;  
	
}
?>
