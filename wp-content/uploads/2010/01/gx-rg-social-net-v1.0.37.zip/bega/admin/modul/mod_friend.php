<?php
switch($_GET[act]){
  // Tampil friend
  default:
    echo "<h2>$_SESSION[namauser]'s Friends</h2>";
	
	$url       = "http://localhost/bega/imgs";
	$tampak=mysql_query("SELECT * FROM friend, user WHERE friend.username1='$_SESSION[namauser]' AND friend.username2=user.id_user  ORDER BY id_friend ");
	$ada=mysql_num_rows($tampak);
	if ($ada > 0){
    echo"<table>"; 
    $no=1;
    while ($r=mysql_fetch_array($tampak)){
       echo "<tr><td>$no</td>
             <td><img src='$url/$r[gambar]' width=50 heigth=75></td>
             <td><a href=?module=friend&act=lihat&id=$r[username2]>$r[username2]</a></td>
             <td><a href=./aksi2.php?module=friend&act=del&id=$r[username2]>Hapus</a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
	}
	else{
	echo "$_SESSION[namauser] belum mempunyai teman
	
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>";
    }
	break;
  
case "lihat":
    $l=mysql_query("SELECT * FROM user WHERE id_user='$_GET[id]'");
    
    echo "<h2>$_GET[id]'s Profile</h2><table>";
	$url       = "http://localhost/bega/imgs";
	while ($r=mysql_fetch_array($l)){
	echo "<img src='$url/$r[gambar]' width=150 heigth=200><br><br>
	<br><br>";
	}
    echo "</table>";
	echo "<h2>Comment's on $_GET[id]</h2>";
	echo "<form name='input' action='./aksi2.php?module=friend&act=komen&id=$_GET[id]' method='post' id='input'><table><tr>
	<td colspan=2>
          <textarea name='koment' value='Comment here!!!' rows='5' cols='50'></textarea></td></tr><tr><td>
		  <input type='submit' value='submit' class=
          'buttons' ></td><td><input type='reset' name='reset' value='reset'></td></tr></table>
        </form>";
    echo "<table>";
    $k=mysql_query("SELECT * FROM comment WHERE penerima='$_GET[id]' ORDER BY id_comment DESC");
    while ($d=mysql_fetch_array($k)){
    echo " <tr>
             <td><b>$d[pengirim]</b> said: $d[comment]</td>
             <td><a href=./aksi2.php?module=friend&act=delkom2&id=$d[id_comment]>Hapus</a></td></tr>";
      }
    echo "</table>";
    break;
	 

 
}
?>
