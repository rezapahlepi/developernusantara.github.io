<html>
<body>
<?php
echo "<form method='post' action='upload_image.php' enctype='multipart/form-data'>
Image (JPG/JPEG) <input name='img' type='file'/></td>
<input name='submit' type='submit' value='Upload' />";
?>
</body>
</html>