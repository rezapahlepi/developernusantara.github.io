<?php
sleep(3);
echo 'Content';
?>