<HTML>
<HEAD>
<TITLE>GXRG Youtube Downloader</TITLE>

<br></br>
<marquee behavior="scroll" direction="left"><a href="http://gxrg.org">GXRG.org</a href></marquee>
<link rel="stylesheet" type="text/css" href="default.css" media="screen"/>
</HEAD>
<br></br>
<body>
<center>
<b><font color="white">enter video URL in here</font></b>
<br></br>
<center><form method="post">

<input type="text" name="url" value="" style="width: 300px">

<input type="submit" value="DOWNLOAD THIS">

</form>



<br />
<hr>
<br />


<?php

if(isset($_POST['url']))
{
  include('curl.php');
  include('youtube.php');
  
  $tube = new youtube();
  
  $download_link = $tube->get($_POST['url']);
   
  if($download_link) { ?>
    
    <b>Download URL=====>></b> : <a href="<?=$download_link;?>"><?=$download_link;?></a> 
  
  <?php } else { ?>
    Error locating download URL.  
  <?php } 
  


}

?>
</body>