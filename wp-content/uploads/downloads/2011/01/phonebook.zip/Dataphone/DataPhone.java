import java.sql.*;
import java.util.*;

public class DataPhone {
  private Connection koneksi;	
  private ResultSet hasil;
  private Statement statement;
  /** Konstruktor*/


  String Ntable; // variabel Global
  Scanner input = new Scanner(System.in);

  public DataPhone() {
    koneksi = null;
    hasil = null;
    statement = null;
   }

  public void dbOpen() {
    String namadriver = "com.mysql.jdbc.Driver";
    String namadb = "jdbc:mysql://localhost:3306/Phone";
    String user = "root";
    String pass = "toor";

    try {
      /** Perintah klas koneksi */
      Class.forName(namadriver);

      /** Perintah Koneksi */
      koneksi = DriverManager.getConnection(namadb, user, pass );

      System.out.println("");	
      System.out.println("      .-..            .        .  ");
      System.out.println(".-.._.|-'|-. .-..-..-,|-..-..-.|_,");
      System.out.println("`-|' ''  ' '-`-'' '`'-`-'`-'`-'' `");
      System.out.println("`-'   ");
      System.out.println("     [G]unadarma [X]malang [R]esearch [G]rup ");
      System.out.println("     Thanks to GXRG Crew");
      System.out.println("");

     } catch (Exception e) {
      System.out.println("Error : " + e);
	
     }
   }
  public void dbviewtable() {
    /** Menampilkan table yang sudah ada */

    try {
      statement = koneksi.createStatement();
      hasil = statement.executeQuery("show tables");

        System.out.println("");
        System.out.println("+--------+");
	System.out.println("| Table  |");
        System.out.println("+------- +");
      while(hasil.next()) {
        String table = hasil.getString(1);
        System.out.println("| " + table + "   |");
      } System.out.println("+------- +");

    } catch (Exception e) {
      System.err.println("Exception: " + e);

    }
  }

  public void dbCreate() {
    /** Membuat table database */

    try {
      System.out.print("\nCreate table name -> ");
      String Ntable = input.nextLine();
      Statement statement = koneksi.createStatement();
      statement.execute ("create table " + Ntable + "(ID_GX varchar(10), Nama varchar(20), No_Hp varchar(15), Email varchar(35), primary key (ID_GX))");

     } catch (SQLException sqle) {
      System.out.println("Error : " + sqle);

     }
   }

  public void dbInsert() {
    /** Mengisi table database */
    
    System.out.print("\nInput Name tables -> ");
    String Ntable = input.nextLine();
    System.out.print("Input Id GX  -> ");
    String id = input.nextLine();
    System.out.print("Input Nama   -> ");
    String Nama = input.nextLine();
    System.out.print("Input No Hp  -> ");
    String Hp = input.nextLine();
    System.out.print("Input Email  -> ");
    String Email = input.nextLine();

    try {
      Statement statement = koneksi.createStatement();
      statement.execute ("insert into " + Ntable + " values ( \'" + id + "\' , \'" + Nama + "\' , \'" + Hp + "\' , \'" + Email +  "\' )");

     } catch (SQLException sqle) {
      System.out.println("Error : " + sqle);

     }
   }

  public void dbEdit() {
    /** Mengupdate data yang ada pada database */

    System.out.print("\nInput Name tables -> ");
    String Ntable = input.nextLine();
    System.out.print("Input Id GX -> ");
    String id = input.nextLine();
    try {
      statement = koneksi.createStatement();
      hasil = statement.executeQuery("SELECT ID_GX, Nama, No_Hp, Email FROM " + Ntable + " Where ID_GX =" + id);

        System.out.println("");
        System.out.println("+----------------------------------------------------------+");
	System.out.println("| ID \t| Nama \t|   Hp \t\t| Email                    |");
        System.out.println("+----------------------------------------------------------+");

      while(hasil.next()) {
        String ID_GX = hasil.getString(1);
        String Nama = hasil.getString(2);
        String No_Hp = hasil.getString(3);
        String Email = hasil.getString(4);
        System.out.println("| " + ID_GX + "\t| " + Nama + "\t| " + No_Hp + "\t| " + Email + "           |");
      } System.out.println("+----------------------------------------------------------+");

    } catch (Exception e) {
      System.err.println("Exception: " + e);
    } 

    /** Update Database */
    System.out.print("\nChange Nama to  -> ");
    String NNama = input.nextLine();
    System.out.print("Change No Hp to -> ");
    String NHp = input.nextLine();
    System.out.print("Change Email to -> ");
    String NEmail = input.nextLine();

    try {
      Statement statement = koneksi.createStatement();
      statement.execute ("update " + Ntable + " set No_Hp = \'" + NHp + "\', Nama = \'" + NNama + "\', Email = \'" + NEmail + "\' where ID_GX = \'" + id + "\'" );

     } catch (SQLException sqle) {
      System.out.println("Error : " + sqle);

     }
   }

  public void dbView() {
    /** Melihat isi database */

    System.out.print("\nInput Name tables -> ");
    String Ntable = input.nextLine();
    try {
      statement = koneksi.createStatement();
      hasil = statement.executeQuery("SELECT ID_GX, Nama, No_Hp, Email FROM " + Ntable);

        System.out.println("");
        System.out.println("+----------------------------------------------------------+");
	System.out.println("| ID \t| Nama \t|   Hp \t\t| Email                    |");
        System.out.println("+----------------------------------------------------------+");

      while(hasil.next()) {
        String ID_GX = hasil.getString(1);
        String Nama = hasil.getString(2);
        String No_Hp = hasil.getString(3);
        String Email = hasil.getString(4);
        System.out.println("| " + ID_GX + "\t| " + Nama + "\t| " + No_Hp + "\t| " + Email + "           |");
      } System.out.println("+----------------------------------------------------------+");

    } catch (Exception e) {
      System.err.println("Exception: " + e);
    } 
   }

  public void dbClose() {
    /** Memutus koneksi database*/
    try {
      koneksi.close();
      System.out.println("\n Bye :)");
      System.exit(0);

     } catch(SQLException sqlex) {
      System.out.println("Error: tidak bisa disconnect");

     }
   }

  public void dbLoop() {
    /** Perulangan */

    System.out.println("");
    System.out.print("  Back to Main Menu [Y / T] -> ");
    String jawab = input.nextLine();

    if( jawab.equals("T") || jawab.equals("t")) {
     System.exit(0);
     }
    else { 
     DataPhone ponsel = new DataPhone();
     ponsel.dbMenu();
     }
   }

  public void dbMenu() {
    /** Menampilkan Menu awal*/
    DataPhone ponsel = new DataPhone();
     ponsel.dbOpen();

    System.out.println("   (1.) Create Table ");
    System.out.println("   (2.) Insert Table");
    System.out.println("   (3.) Edit Table");
    System.out.println("   (4.) View Table");
    System.out.println("   (5.) Close");
    System.out.print("   --> ");
    Integer pilih = input.nextInt();
    System.out.print("--------------------------------------------\n");

    if (pilih == 1) {
      ponsel.dbCreate(); 
      ponsel.dbLoop();

     } else if (pilih == 2) {
      ponsel.dbviewtable();
      ponsel.dbInsert();
      ponsel.dbLoop();

     } else if (pilih == 3) {
      ponsel.dbviewtable();
      ponsel.dbEdit();
      ponsel.dbLoop();

     } else if (pilih == 4) {
      ponsel.dbviewtable();
      ponsel.dbView();
      ponsel.dbLoop();

     } else {
      ponsel.dbClose();

     }
   }

  public static void main(String [] args) {
    DataPhone ponsel = new DataPhone();
    ponsel.dbMenu();

     }
 }
