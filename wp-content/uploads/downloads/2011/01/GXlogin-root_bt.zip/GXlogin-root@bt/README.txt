===============
GXlogin-root@bt
===============

Author by   : ChRistian
Email       : christiangilaa [at] ymail [dot] com
Site        : http://cgilaa12.wordpress.com, http://projects.gxrg.org
Credits     : [G]unadarma [X]malang [R]esearch [G]roups

How to install and use :

1. first you must install term/ansicolor the rubygems library
   type : gem1.8 install term-ansicolor
2. second step you must install highline/import the rubygems library 
   type : gem1.8 install highline
3. then add execute permission, type : chmod +x configure.rb
4. run configure.rb, type : ./configure.rb
5. wait untill prosess configure finish, enjoyed !
6. you can also change your password anytime you want with running chgpasswd.rb
   type : ./chgpasswd.rb

Report error :

Report error to <christiangilaa@ymail.com>
