#!/usr/bin/ruby

system "clear"
puts "\n"
	        puts "	[ GXlogin-root@bt.rb ]"
                puts "		       .--."
                puts "                      |o_o |"
                puts "                      |:_/ |"
                puts "                     //   \\ \\"
                puts "                    (|     | )"
                puts "                   /'\\_   _/`\\"
                puts "                   \\___)=(___/"

require 'rubygems'
require 'highline/import'
trap("INT") { interrrupted = true }

sleep(1)
puts "\n^set new password for GXlogin-root@bt^"
sleep(1)
pass = ask("-> Enter new password : ") { |q| q.echo = "*" }
    $key   = "xw1q"
    $qpass = pass.crypt($key)
file = File.open("/etc/security/pass.txt","w")
file.puts "#{$qpass}"
file.close
sleep(2)
puts "\nchanging password done!"
sleep(1)
puts "please reboot to see the effect.."
sleep(1)
puts "\n#christiangilaa@ymail.com\n#http://projects.gxrg.org/"
exit 1
