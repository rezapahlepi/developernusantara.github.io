#!/usr/bin/ruby
#"[ GXlogin-root@bt ]"
#puts "\nAuthor by : ChRistian"
#puts "Email	  : christiangilaa [at] ymail [dot] com"
#puts "Site	  : http://cgilaa12.wordpress.com, http://projects.gxrg.org"
#puts "Credits	  : [G]unadarma [X]malang [R]esearch [G]roups"
require 'rubygems'
require 'highline/import'
require 'term/ansicolor'
include Term::ANSIColor
puts green, bold, "     _________  ___.__                 .__                                   __    ________.    __
    /  __/\\   \\/  /|  |    ____   ___  |__| ____       _______  ____   _____/  |_ / ___ \\_ |___/  |_
   /  \\  _ \\     / |  |   /  _ \\ / __\\ |  |/    \\  ____\\_  __ \\/  _ \\ /  _ \\   __| / ._\\ \\ __ \\   __\\
   \\   \\_\\\\/     \\ |  |__(  <_> ) /_/ >|  |   |  \\/____/|  | \\(  <_> |  <_> )  |<  \\_____/ \\_\\ \\  |
    \\___  /___/\\  \\|____/ \\____/\\___ / |__|___|  /      |__|   \\____/ \\____/|__| \\_____\\ |___  /__|
        \\/      \\_/            /____/          \\/                                            \\/",reset
puts "\n"
interrupted = false
trap("TSTP") { interrupted = true }
trap("INT") { interrrupted = true }
system "stty eof '?'"
for stupid in 1..3
pass = ask("GXRG-CREW root password : ") { |q| q.echo = "*" }.crypt("xw1q")
file = File.read("/etc/security/pass.txt").chomp.to_s
	 if pass == "#{file}"
		system "startx"
		exit 1
	 elsif pass != "#{file}" && stupid == 3
print red, bold,       "your access is denied !\n",reset
		sleep (1)
print red, bold,       "shuting down system\n",reset		
		sleep (2)
		system "init 0"
		exit 1
	else
print red, bold,      "wrong password !",reset
puts
	end
end
