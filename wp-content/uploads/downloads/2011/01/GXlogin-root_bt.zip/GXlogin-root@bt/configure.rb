#!/usr/bin/ruby

require 'fileutils'

trap("INT") { interrupted = true }
trap("SIGTSTP") { interrupted = true }
         FileUtils.chmod 0001, %w(GXlogin-root@bt.rb chgpasswd.rb)
sleep(1)
puts "configuring file..."
 sleep(2)
	FileUtils.mv %w(GXlogin-root@bt.rb), "/etc/"
 sleep(2)
puts "succeed moving file GXlogin-root@bt.rb"
 sleep(2)
puts "fetching file..."
lastline = 0
     file = File.open("/etc/rc.local", "r+")
     file.each { lastline = file.pos unless file.eof? }
     file.seek(lastline, IO::SEEK_SET)
     file.puts "sudo /etc/GXlogin-root@bt.rb\nExit 0"
     file.close
 sleep(2)
puts "succeed fetching file GXlogin-root@bt.rb > /etc/rc.local"
 sleep(2)
puts "removing virtual console"
    vc = Dir.glob("/etc/event.d/tty*")
	 FileUtils.mv vc, "/tmp/"
    vC = Dir.glob("/tmp/tty1")
	 FileUtils.mv vC, "/etc/event.d/"
	 FileUtils.rm_r Dir.glob("/tmp/tty*")
 sleep(3)
puts "succeed removing virtual console"
 sleep(1)
puts "installing GXlogin-root@bt.rb succeeded"
 sleep(2)

require 'rubygems'
require 'highline/import'
	pass = ask("set new root password : ") { |q| q.echo = "*" }
	$key = "xw1q"
	$qpass = pass.crypt($key)
 sleep(1)
puts "creating your password at -> /etc/security/pass.txt"
    pw = Dir.glob("/etc/security/")
	 FileUtils.touch "#{pw}pass.txt";
    pf = File.open("/etc/security/pass.txt","w")
    pf.puts "#{$qpass}"
    pf.close
 sleep(2)
puts "creating password succeeded !"
 sleep(1)
puts "reboot to see the effect!"
 sleep(1)
puts "#you can change your password with running chgpasswd.rb\n#christiangilaa@ymail.com"
 sleep(2)
	  FileUtils.rm %w(configure.rb)
