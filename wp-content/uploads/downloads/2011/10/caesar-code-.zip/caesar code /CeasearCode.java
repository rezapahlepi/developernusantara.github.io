/*
Caesar Chiper in java v.0.1  (c)copyleft 04/2011
Author  : Andhika Arya Budhi P
Credits	: GXRG [Gunadarma X-Malang Research Group] 
Email   : dhika [dot] linix [at] gmail.com
Licence : Licensed under the GNU General Public License
*/

import java.io.*;
import java.lang.*;

class CeasearCode{
public static void main (String args[])throws IOException{
	InputStreamReader input= new InputStreamReader(System.in);
	BufferedReader dis= new BufferedReader(input);

	System.out.println("+-++-++-++-++-++-+ +-++-++-++-++-++-+");
	System.out.println("|C||a||e||s||a||r| |C||h||i||p||e||r|");
	System.out.println("+-++-++-++-++-++-+ +-++-++-++-++-++-+");
	System.out.println("Menu Utama");
	System.out.println("1. Enkripsi");
	System.out.println("2. Dekripsi");
	System.out.println("3. Dekripsi via BruteForce");
	System.out.println("4. Exit");
	System.out.print("Masukkan Pilihan : ");
try {
	String masukan = dis.readLine();
	int pil = Integer.parseInt(masukan);

	switch(pil){
	case 1: ekripsi();
	break;
	case 2: deskripsi();
	break;
	case 3: bruteforce();
	break;
	case 4: System.exit(0);
	default:
	System.out.println("Pilihan Tidak Ada");

	}
}catch (java.lang.NumberFormatException exc) { System.out.println("OOps masukan hanya huruf !");}
}

public static void ekripsi() throws IOException{
	InputStreamReader input= new InputStreamReader(System.in);
	BufferedReader dis= new BufferedReader(input);
	
	System.out.print("Masukan teks \t:");
	String teks = dis.readLine();
	int a = teks.length();

	// kovert string to cchar 
	char teks1[] = new char[a];
	for(int i=0; i<a; i++)
	{
		teks1[i]  = teks.charAt(i);
	}


	System.out.print("Masukan kunci \t:");
	String key = dis.readLine();
	int mod = Integer.parseInt(key);
	int keys = mod %26;
	char w[] = new char[a];
	
	//konert to ascii code 
	for(int i=0; i<a; i++){
		int j = (int) teks1[i] ;
		int x = j + keys;
		if (x >= 97)       
		{ 
			if(x > 122){
			int n1 = x - 122 ;
			int n2 = n1 -1 ;
			int n3 = 97 + n2 ; 
			w[i] = (char) n3;
			}else{ 
			w[i] = (char) x ;
			}
			
		}else if (x >= 65 ){
			if (x > 90) {		  
			int n1 = x - 90 ;
			int n2 = n1 -1 ;
			int n3 = 65 + n2 ;
		  	w[i] = (char) n3;
			} else {
			w[i] = (char) x;
			}
		
		}	

		if (j == 32){
		w[i] = (char) 32 ;		
		}
		
	}

	String enkripsi =  new String(w);
	System.out.println("Enkripsi \t:" + enkripsi);
	}






public static void deskripsi() throws IOException{
	InputStreamReader input= new InputStreamReader(System.in);
	BufferedReader dis= new BufferedReader(input);
	
	System.out.print("Masukan Enkripsi \t:");
	String teks = dis.readLine();
	int a = teks.length();

	// kovert string to cchar 
	char teks1[] = new char[a];
	for(int i=0; i<a; i++)
	{
		teks1[i]  = teks.charAt(i);
	}


	System.out.print("Masukan kunci \t\t:");
	String key = dis.readLine();
	int mod = Integer.parseInt(key);
	int keys = mod %26;
	char w[] = new char[a];
	
	//konert to ascii code 
	for(int i=0; i<a; i++){
		int j = (int) teks1[i] ;
		int x = j - keys;
		if (x <= 97)       
		{ 
			if(x < 97){
			int n1 = x + 122 ;
			int n2 = n1 +1 ;
			int n3 = n2 - 97 ; 
			w[i] = (char) n3;
			}else{ 
			w[i] = (char) x ;
			}
			
		}else if (x <= 65 ){
			if (x < 65) {		  
			int n1 = x + 90 ;
			int n2 = n1 + 1 ;
			int n3 =  n2 - 65 ;
		  	w[i] = (char) n3;
			} else {
			w[i] = (char) x;
			}
		
		}else {w[i] = (char) x;}	

		if (j == 32){
		w[i] = (char) 32 ;		
		}
		
	}

	String dekripsi =  new String(w);
	System.out.println("Dekripsi \t\t:" + dekripsi);
	}




	
	
public static void bruteforce() throws IOException{
	InputStreamReader input= new InputStreamReader(System.in);
	BufferedReader dis= new BufferedReader(input);
	
System.out.print("Masukan Enkripsi \t:");
String teks = dis.readLine();
	int a = teks.length();

	// kovert string to cchar 
	char teks1[] = new char[a];
	for(int i=0; i<a; i++)
	{
		teks1[i]  = teks.charAt(i);
	}
	
char w[] = new char[a];
for (int q = 0 ; q<=24 ; q++){
int keys = q ;
	//konert to ascii code 
	for(int i=0; i<a; i++){
		int j = (int) teks1[i] ;
		int x = j - keys;
		if (x <= 97)       
		{ 
			if(x < 97){
			int n1 = x + 122 ;
			int n2 = n1 +1 ;
			int n3 = n2 - 97 ; 
			w[i] = (char) n3;
			}else{ 
			w[i] = (char) x ;
			} 

			
		}else if (x <= 65 ){
			if (x < 65) {		  
			int n1 = x + 90 ;
			int n2 = n1 + 1 ;
			int n3 =  n2 - 65 ;
		  	w[i] = (char) n3;
			} else {
			w[i] = (char) x;
			}
			
		}	
else {w[i] = (char) x;}	
		if (j == 32){
		w[i] = (char) 32 ;		
		}

	
	}

	String dekripsi =  new String(w);
	System.out.println("Dekripsi kunci ke- "+ q+":" + dekripsi);
}
	}

}



