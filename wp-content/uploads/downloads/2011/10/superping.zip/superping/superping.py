#!/usr/bin/python
#
#  superping.py - A fastest network administration tools used to test the reachability of a host.
#  By abi71 <l0g.bima@gmail.com> (http://rndc.or.id, http://gxrg.org, http://abi71.wordpress.com) 
# 
#  This program is very simple used only for class C network, 
#  to be running on all classes of network, you can use the 
#  Python module representation and manipulation of 
#  network addresses such as netaddr,ipaddr,IPY.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Full GPLv3 license is included in Release Notes

__author__ = "abi71 <l0g.bima@gmail.com>"
__version__ = "v.1.0"
__release__ = "18/4/2011"
__license__ = "GNU/GPL License"
__credits__="[G]unadarma[X]malang[R]esearchs[Group]"

import os
import sys
import socket
import threading

# packet size (bytes)
packet_size=1

class superping(threading.Thread):
	global packet_size
	
	def __init__(self, host):
		threading.Thread.__init__(self)
		self.host=host
	def run(self):
		''' using linux ping network administration utility '''
		if os.system('ping -s %s -w 2 %s > /dev/null' % (packet_size, self.host)) == 0:
			# live host
			print "%s" % (self.host)

def format_check(start_host=None, end_host=None):
     try:
	if len(start_host.split('.')) == 4 and len(start_host.split('.')) == 4:
	     try:
		# split 3 byte network 
		net1=start_host.split('.')[0]
		net2=start_host.split('.')[1]
		net3=start_host.split('.')[2]
		# get start & end host range 
		srange=int(start_host.split('.')[3])
		erange=int(end_host.split('.')[3])
	     except ValueError, err:
		print err
		sys.exit(0)
	     if erange<srange:
		print "FATAL: bad ip address ranges."
	     try:
		socket.inet_aton(start_host)
		socket.inet_aton(end_host)
		# do ping
		for ip in range(srange, erange+1):
			s=superping("%s.%s.%s.%s" % (net1, net2, net3, ip))
			s.start()
	     except socket.error, err:
		print '%s:%s' %(host,err)
		sys.exit(0)
     except IndexError:
	print "FATAL: bad ipv4 address format."
			

if len(sys.argv)==3:
	start_host=sys.argv[1]
	end_host=sys.argv[2]
	format_check(start_host, end_host)
else:
	print "Author by %s\n" % __author__
	print "Usage: python superping.py [start_host] [end_host]"

## EOF ##