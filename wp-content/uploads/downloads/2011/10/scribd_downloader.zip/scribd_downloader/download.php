<html>
<head>
<title>Scribd Downloader</title>
<meta name="description" content="Scribd Downloader" />
<meta name="keywords" content="scribd,downloader" />
<style type="text/css">
body {
	font-family: Comic Sans MS;
}
</style>
<?php
$link = $_POST['link'];

if ($link == "") {
	echo "</head>";
	echo "<body>";
	echo "<h1>URL Incorrect!!</h1>";
} else {
	$link = explode("/",$link);
	$no = $link[4];
	$dl = "http://www.scribd.com/mobile/documents/$no/download";
	echo "<meta http-equiv='refresh' content='3;url=$dl'>";
	echo "</head>";
	echo "<body>";
	echo "<h1>Your request has downloading!</h1>";
}
?>
</body>
</html>