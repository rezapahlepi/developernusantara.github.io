<!--
Author  : japar
Credits : [G]unadarma [X]malang [R]esearch [G]roups
		  rndc.or.id
Desc	: for downloading from scribd.com without login
-->

<html>
<head>
<title>Scribd Downloader</title>
<meta name="description" content="Scribd Downloader" />
<meta name="keywords" content="scribd,downloader" />
<style type="text/css">
.kotak {
	background-color: #e0ffff;
	border: #b0c4de 2px dashed;
}

body {
	font-family: Comic Sans MS;
}
</style>
</head>
<body>
Enter URL :
<form action="download.php" method="post" autocomplete="off" />
<input class="kotak" type="text" name="link" size="80" />
<input type="submit" value="download">
</form>
</body>
</html>