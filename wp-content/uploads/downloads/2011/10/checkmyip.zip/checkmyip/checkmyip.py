#!/usr/bin/python
#
#  checkmyip.py 1.0 - IP Address Checker
#  By abi <l0g.bima@gmail.com> (http://rndc.or.id, http://gxrg.org, http://abi71.wordpress.com) 
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Full GPLv3 license is included in Release Notes

__author__ = "Abi"
__version__ = "1.0"

import re, os, sys, urllib

def cmyip():
	try:
		gotIP = False
		result = urllib.urlopen("http://www.cmyip.com/")
		result = result.readlines()
		
		for i in result:
			if re.search("<title>", i):
				print "cmyip.com : %s" % i.split()[4]
				gotIP = True
				break
		if not gotIP:
			print "cmyip.com : -"
	except IOError:
		print "cmyip.com : -"
		
def ipaddress():
	try:
		gotIP = False
		result = urllib.urlopen("http://www.ipaddress.com")
		result = result.readlines()

		for i in result:
			if re.search("<b>IP:", i):
				tmp = i.split("<b>")[1]
				tmp = tmp.split('<')[0]
				print "ipaddress.com : %s" % tmp.strip("IP: ")
				gotIP = True
				break
			
		if not gotIP:
			print "ipaddress.com : -"
	except IOError:
		print "ipaddress.com : -"
		
def ipgue():
	try:
		gotIP = False
		result = urllib.urlopen("http://www.ipgue.com")
		result = result.readlines()

		for i in result:
			if re.search("Your IP :", i):
				print "ipgue.com : %s" % i.split()[3]
				gotIP = True
				break
			
		if not gotIP:
			print "ipgue.com : -"
	except IOError:
		print "ipgue.com : -"
		
def stilllistener():
	try:
		gotIP = False
		result = urllib.urlopen("http://www.stilllistener.com/checkpoint1/")
		result = result.readlines()

		for i in result:
			if re.search("Your IP:</b>", i):
				tmp = i.split("<b>Your IP:</b> ")[1]
				print "stilllistener.com : %s" % tmp.split("<")[0]
				gotIP = True
				break
	
		if not gotIP:
			print "stilllistener.com : -"
	except IOError:
		print "stilllistener : -"
		
def whatismyipaddress():
	try:
		gotIP = False
		result = urllib.urlopen("http://whatismyipaddress.com/")
		result = result.readlines()

		for i in result:
			if re.search("<!-- contact us before using a script to get your IP address -->", i):
				tmp = i.split("<")[1]
				print "whatismyipaddress.com : %s" % tmp.split("-->")[1]
				gotIP = True
				break
	
		if not gotIP:
			print "whatismyipaddress.com : -"
	except IOError:
		print "whatismyipaddress.com : -"

if sys.platform == 'linux' or sys.platform == 'linux2':
        clearing = 'clear'
else:
        clearing = 'cls'
os.system(clearing)
	
try:
   print "checkmyip %s by %s - IP Address Checker\n" % (__version__, __author__)
   print "Trying to fetch... be patient !\n"
   cmyip()
   ipaddress()		
   ipgue()
   stilllistener()
   whatismyipaddress()
   print "\nKeep anonymous :D\n"
except KeyboardInterrupt:
	print "\nProgram interupted by user...\n"

##EOF##