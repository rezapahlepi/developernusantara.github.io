/*
* author : ainan zaka (zhack)
* Email: ainan.zaka@gmail.com
* Credits: [G]unadarma [X]malang [R]esearch [G]roups 
* license: Licensed under the GNU General Public License  
*
* Thanks to : Gxrg Crew, acha
*/

import java.util.*;
import java.net.*;

public class Urlinfo {
  public static void main(String[] args) {
   try {
     Scanner masuk = new Scanner(System.in);
 
     System.out.print("Input URL (Don't forget input \"https://,http://, or ftp://\") --> ");
     String url = masuk.nextLine();
     String versiJava = System.getProperty("java.version");
     String YourOS = System.getProperty("os.name");
     String OSver = System.getProperty("os.version");

     URL aURL = new URL(url);
     URLConnection  urlcon= aURL.openConnection();
    
     String host = aURL.getHost(); 
     
     InetAddress kill = InetAddress.getByName(host);
     String host1 = kill.getHostAddress();

     System.out.println("\n[*] Trying Fetch url...\n");

     System.out.println("\nIP \"" + url + "\" => " + host1);   
     System.out.println("\nprotocol        : " + aURL.getProtocol());
     System.out.println("Port            : " + aURL.getDefaultPort());
     System.out.println("Name Host       : " + host);
     System.out.println("Name Path       : " + aURL.getRef());

     System.out.println( "URL Connection  : " + urlcon );
     System.out.println( "Date            : " + new Date(urlcon.getDate()) );  
     System.out.println( "Last Modified   : " + new Date(urlcon.getLastModified()) ); 
     System.out.println( "Content encoding: " + urlcon.getContentEncoding() );
     System.out.println( "Content type    : " + urlcon.getContentType() );   
     System.out.println( "Content length  : " + urlcon.getContentLength() );

     System.out.println("\nSystem Operasi yg anda gunakan -----------\n");
     System.out.println("You use System Operation " + YourOS + " versi " + OSver);
     System.out.println("Versi java "+ versiJava);

     System.out.println("[*] Thanks for using this Program ");
     System.out.println("[*] System Exit ");

    } catch (Exception e) {
     System.out.println("Error : " + e);
    }

   } 
 } 
