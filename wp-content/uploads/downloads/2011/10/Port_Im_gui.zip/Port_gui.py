#!/usr/bin/env python
import wx,socket,time

class gui(wx.Frame):
	def scan(self,event):
		try:
			get=self.host.GetValue()
			target=socket.gethostbyname(get)
		except:
			wx.MessageDialog(self, 'Host Invalid and please check your connections..', 'Error', wx.OK|wx.ICON_ERROR).ShowModal()
		port={1:'tcp/Service Multiplexer',2:'tcp/management Utility',3:'Compression Process',4:'Unassigned',5:'Remote Job Entry',6:'Unassigned',7:'echo',8:'Unassigned',9:'Discard',11:'active users',80:'http',22:'ssh',21:'ftp',20:'ftp/udp',23:'telnet',25:'smtp',53:'dns server',67:'dhcp',68:'dhcp',69:'tftp',443:'https',110:'pop3',123:'ntp',220:'imap3',3389:'remote dekstop Xp',389:'ldap(server)',143:'imap4',443:'ssl',1503:'ms Netmeting',1720:'voip',5900:'vnc',111:'portmap',3306:'msyql',981:'tcp',3306:'mysql',631:'ipp',13:'rfc',17:'Quote of the Day',18:'Message Send Protocol',19:'	Character Generator',34:'rf',35:'qms/printer server',37:'time Protocol',41:'Graphics',42:'arpa/wins',43:'whois',47:'gre',49:'tacacs',52:'xns',54:'xns',55:'isi-gl',56:'rap',57:'mtp',58:'xns mail',70:'gopher',79:'finger',81:'topark',82:'topark',83:'mit ml divace',88:'kerberos',90:'dnsix',90:'pointcast',99:'wip',101:'nic',102:'iso-tsap',104:'arc/nema',105:'ccso',108:'sna',109:'pop2',111:'sun/irc',113:'auth',115:'sftp',117:'uucp',118:'sql',119:'nntp',135:'dce endpoint',137:'Netbios',138:'Netbios',139:'Netbios',152:'bftp',153:'sgmp',156:'sql',161:'snmp',162:'snmptrap',170:'print-svr',177:'xdmcp',179:'bgp',194:'irc',199:'smux',201:'apple talk',209:'quick mail',210:'ansi',231:'ipx',218:'mpp',256:'2sp',259:'esro',264:'bgmp',308:'navastor',311:'mac Os svr',318:'pkix',323:'immp',369:'rpc2portmap',370:'codaauth2',371:'clearcase albd',383:'hp data alarm',401:'ups',402:'altiris',427:'slp',445:'ms-dos smb',464:'kerberos',465:'cisco',497:'dantz Retrospect',500:'isakmp',501:'stmf',502:'modbus',504:'citadel',512:'rexec',513:'login/who',514:'shell/syslog',517:'talk',518:'ntalk',520:'RIP',532:'netnews',540:'uucp',545:'osisoft',554:'rtsp',587:'smtp',591:'filemaker',636:'ldaps',639:'msdp',641:'ldp',648:'rrp',652:'dtcp',691:'ms exchange',692:'hyperware-isp',694:'linux-ha',698:'olsr',700:'epp',706:'silc',720:'smqp',750:'rfile',751:'pupm',752:'qrh',753:'rrh',754:'krb5_prop',754:'tell send',760:'ns',783:'spamAssassin',892:'cmp',843:'adobe flash socket',860:'iscsl',873:'rsync',888:'cddb',901:'samba',902:'vmware',911:'nca',991:'nas',993:'imaps',995:'pop3s',999:'scimoreDB',1001:'JtoMb',1002:'Opsware',1023:'reserved'}
		y=78
		for x in port.keys():
			try:
				cn = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
				cn.connect((target,x))
				y+=18
				if len('%s' %x)==2:
					wx.StaticText(self,-1,"%d\t\t\tOpen\t\t%s" %(x, port[x]),(15,y))
				else:
					wx.StaticText(self,-1,"%d\t\tOpen\t\t%s" %(x, port[x]),(15,y))
			except:
				continue
		wx.StaticText(self,-1,">> Scanning Done <<",(50,240))
		self.host=wx.TextCtrl(self,-1,'',(60,20),(160,20))
		
	def clear(self,event):
		self.Destroy()
		gui()
	def quit(self,event):
		self.Destroy()
	def help(self,event):
		wx.MessageDialog(self, 'Input Host Target and press scan button to see open port target', 'Help', wx.OK|wx.ICON_INFORMATION).ShowModal()
	def about(self,event):
		wx.MessageDialog(self, 'Port_I\'m v0.2 Created by bara(gxrg Crew)\nReport bug shineofbara@yahoo.com\nwww.rndc.or.id ', 'About', wx.OK|wx.ICON_INFORMATION).ShowModal()
			
	def __init__(self):
		wx.Frame.__init__(self,None,-1,"Port_I'm",size=(300,290))
		self.Center()
		menu=wx.MenuBar()
		file=wx.Menu()
		help=wx.Menu()
		file.Append(101,'Quit')
		help.Append(201,'Help')
		help.AppendSeparator()
		help.Append(202,'About')
		menu.Append(file,'&File')
		menu.Append(help,'&Help')
		wx.EVT_MENU(self, 101, self.quit )
		wx.EVT_MENU(self, 201, self.help )
		wx.EVT_MENU(self, 202, self.about)
		self.SetMenuBar(menu)
		wx.StaticText(self,-1,"Host : ",(10,20))
		wx.StaticText(self,-1,"Port\t\tStatus\t\tSevice",(15,78))
		self.host=wx.TextCtrl(self,-1,'',(60,20),(160,20))
		wx.StaticBox(self,-1,"Open Port Target",(5,60),(220,200))
		btn=wx.Button(self,-1,"Scan",(230,70),(50,40))
		btn.Bind(wx.EVT_BUTTON,self.scan)
		btn1=wx.Button(self,-1,"Clear",(230,120),(50,40))
		btn1.Bind(wx.EVT_BUTTON,self.clear)
		self.Show()
		
if __name__=='__main__':
	app=wx.App()
	gui()
	app.MainLoop()
