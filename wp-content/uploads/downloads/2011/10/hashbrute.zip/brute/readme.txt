 __________________________________________________________________________________________________________
/  Author		: Farid                                                                            \
|  Category		: Cryptography                                                                     |
|  Mail			: azure [at] indonesianhacker [dot] org                                            |
|  Site			: azure.securityvist.org , projects.gxrg.org , s1.gxrg.org                         |
|  Projetcs		: Brute Password [ Md5 , Etc ]                                                     |
|  Compiler		: G++ / C++                     						   |
|  To Compile		: g++ -o brutepas brutepas.cpp -O6 -lm						   |
|  Usage		: ./brutepas [ Password encrypted ]                                                |
|  Example		: ./brutepas fcdd08c0e5675bb615e97eaa7d1fb55b					   |
|  License		: GNU Public License                                                               |
|  Credits		: All Staff n GXRG crew                                                            |
|  Special thanks	: Ahmmad N. [ Your My inspirate Dude :P ]                                          |
\			  Christian Gilla [ Thx 4 masukannya dari lo akhirnya jiwa crypto gw balik :P ]    /
 ----------------------------------------------------------------------------------------------------------
  \
   \
   \
       ___
     {~._.~}
      ( Y )
     ()~*~()
     (_)-(_)   __________________________________
	      (U /"___|u\ \/"/U |  _"\ uU /"___|u )
	      ( | |  _ //\  /\ \| |_) |/\| |  _ / )
	      ( | |_| |U /  \ u |  _ <   | |_| |  
	      (  \____| /_/\_\  |_| \_\   \____|  )
	      (  _)(|_,-,>> \\_ //   \\_  _)(|_   )
	      ( (__)__)\_)  (__)__)  (__)(__)__)  )
	      ------------------------------------
         	   o
		    o
		     .--.
	            |o_o |
		    |:_/ |
		   //   \ \
		  (|     | )
	          /'\_   _/`\
		  \___)=(___/
