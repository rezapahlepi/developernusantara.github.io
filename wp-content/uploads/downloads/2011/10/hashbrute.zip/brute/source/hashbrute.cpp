/*********************************************************
** brute force password	
**
** to compile : g++ -o brutepas brutepas.cpp -O6 -lm
**
** version 	 : alpha
** farid [ azure@indonesianhacker.org ]	
--------------------------------------------------------
|	   ____  __  __   ____      ____		|
|	U /"___|u\ \/"/U |  _"\ uU /"___|u		|
|	 | |  _ //\  /\ \| |_) |/\| |  _ /		|
|	 | |_| |U /  \ u |  _ <   | |_| |		|
|	  \____| /_/\_\  |_| \_\   \____|		|
|	  _)(|_,-,>> \\_ //   \\_  _)(|_		|
|	 (__)__)\_)  (__)__)  (__)(__)__)		|
| [G]unadarma [X]malang [R]esearch [G]roup		|
--------------------------------------------------------
*********************************************************/
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h> // memset
#include <unistd.h> // usleep
using namespace std;

//TYPE DATA

struct rand_struct {  //Struktur
  unsigned long seed1,seed2,max_value;
  double max_value_dbl;
};

void make_scrambled_password(char *,const char *);
char *scramble(char *,const char *,const char *, int);

int brute(const char *password) {
       ////////////////////////////// U CAN EDIT HERE ///////////////////////////////////////////////////////////
      // Rubah min / max untuk jangkauan MIN/MAX   karakter hasil encrypt                                      //
     //  Ex -> fcdd08c0e5675bb615e97eaa7d1fb55b : mempunyai jangkauan MIN 32 karakter [ bersifat md5 ]        //
    //   width di gunakan untuk MAX jangkauan karakter hasil decrypt                                         //
   //    Ex -> gxrg [ mempunyai 4 karakter ] jika dalam program ini berarti 11 karakter                     //
  //     maka hasil dari fcdd08c0e5675bb615e97eaa7d1fb55b [32] adalah gxrg [4].                            //
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////
 
  unsigned int min=32,max=122,pos=0,width=11,max_pos=0;
  unsigned char data[255];
  register unsigned long long loops=0;
  char *encrypted_password = new char[255];
  memset(encrypted_password, 0, 255);
  memset((char*)&data, min, 255);
  while(width) {
    loops++;
    if(data[pos] != max) {
      data[pos]++;
    } else {
      for(register int i=pos; i<max; i++) {
        if(data[i] != max) {
          data[i]++;
          pos=i;
          break;
        }
      }

      if(pos>max_pos)
        max_pos=pos;

      for(register int i=pos-1; i >= 0; i--) {
        if(i==0 && data[i] == max) {
          data[i] = min;
          pos = 0;
          break;
        }
        if(data[i] != max || i==0) {
          pos = i;
          break;
        }
        data[i] = min;
      }
    }

    if(max_pos>width) {
      cout<<"No match found"<<endl; //GAGAL !!
      width=0;
      return(0);
    }
    data[max_pos+1] = 0;
        make_scrambled_password(encrypted_password,(const char*)data);
    if(!strcmp(encrypted_password,password)) {
      cout<<"MATCH ["<<data<<"] ["<<encrypted_password<<"]==["<<password<<"]"<<endl; //BERHASIL !!
      return(0);
    }
    data[max_pos+1] = min;
    if((loops%500000)==0) { //penambahan nilai loops / desimalnya secara random sebanyak 500000 [ biar lebih cepet prosessnya ]
     cout<<"[ "<<dec<<loops<<" ]";
      for(int i=0; i<=max_pos; i++) {
          cout<<" 0x"<<hex<<(int)data[i];  //HEX = > hasil desimal akan di jadikan hexanya
      }
      data[max_pos+1] = 0;
      cout<<" ["<<data<<"]";  //Ascii => dari hexa akan di jadikan ascii
      data[max_pos+1] = min;
      cout<<endl;
    }
  }
}

// Parameter
int main(int argc, char* argv[]) {
  if(argc!=2) {
    fprintf(stderr,"usage   -> %s [ encrypted password ]\nexample -> %s fcdd08c0e5675bb615e97eaa7d1fb55b\n",argv[0],argv[0]);
    return(0); //fcdd08c0e5675bb615e97eaa7d1fb55b adalah encrypt,dari 'gxrg'
  }
  brute(argv[1]);
}

void randominit(struct rand_struct *rand_st,ulong seed1, ulong seed2) {
  rand_st->max_value= 0x3FFFFFFFL;
  rand_st->max_value_dbl=(double) rand_st->max_value;
  rand_st->seed1=seed1%rand_st->max_value ;
  rand_st->seed2=seed2%rand_st->max_value;
}
static void old_randominit(struct rand_struct *rand_st,ulong seed1) {
  rand_st->max_value= 0x01FFFFFFL;
  rand_st->max_value_dbl=(double) rand_st->max_value;
  seed1%=rand_st->max_value;
  rand_st->seed1=seed1 ; rand_st->seed2=seed1/2;
}
double rnd(struct rand_struct *rand_st) {
  rand_st->seed1=(rand_st->seed1*3+rand_st->seed2) % rand_st->max_value;
  rand_st->seed2=(rand_st->seed1+rand_st->seed2+33) % rand_st->max_value;
  return(((double) rand_st->seed1)/rand_st->max_value_dbl);
}
inline void hash_password(ulong *result, const char *password) {
  register ulong nr=1345345333L, add=7, nr2=0x12345671L;
  ulong tmp;
  for (; *password ; password++) {
    if (*password == ' ' || *password == '\t')
      continue;
  tmp= (ulong) (unsigned char) *password;
  nr^= (((nr & 63)+add)*tmp)+ (nr << 8);
  nr2+=(nr2 << 8) ^ nr;
  add+=tmp;
  }
  result[0]=nr & (((ulong) 1L << 31) -1L);;
  result[1]=nr2 & (((ulong) 1L << 31) -1L);
  return;
}
inline void make_scrambled_password(char *to,const char *password) {
  ulong hash_res[2];
  hash_password(hash_res,password);
  sprintf(to,"%08lx%08lx",hash_res[0],hash_res[1]);
}
static inline uint char_value(char X) {
  return (uint) (X >= '0' && X <= '9' ? X-'0' : X >= 'A' && X <= 'Z' ? X-'A'+10 : X-'a'+10); //Unit Nil X
}
char *scramble(char *to,const char *message,const char *password, int old_ver) {
  struct rand_struct rand_st;
  ulong hash_pass[2],hash_message[2];
  if(password && password[0]) {
    char *to_start=to;
    hash_password(hash_pass,password);
    hash_password(hash_message,message);
    if (old_ver)
      old_randominit(&rand_st,hash_pass[0] ^ hash_message[0]);
    else
      randominit(&rand_st,hash_pass[0] ^ hash_message[0],
    hash_pass[1] ^ hash_message[1]);
    while (*message++)
      *to++= (char) (floor(rnd(&rand_st)*31)+64);
    if (!old_ver) {
      char extra=(char) (floor(rnd(&rand_st)*31));
      while(to_start != to)
        *(to_start++)^=extra;
    }
  }
  *to=0;
  return to;
}

