#!/usr/bin/python
from ftplib import FTP
import os, time, getpass, sys
def download():
    nfile = raw_input("File Name : ")
    directory = ftp.pwd()
    f = open(file,"wb")
    ftp.retrbinary("RETR " + file,f.write)
    f.close()
    download(ftp, directory, nfile)
def upload():
	try:
		cmd = raw_input("File Location: ")
		a = raw_input("Name File : ")
		b = open(cmd,'rb')
		print "[+] ",ftp.storbinary('STOR '+a, b)
	except:
		print "[-] Check you're location file / file location"
def help():
	print """
debug -o  => turns off debug Output"
debug -v  => turns the debug output to Verbose mode"
debug -b  => turns the debug output to Base"
dir 	  => lists the contents of the directory
rename    => rename a file
delete	  => delete a file	
cd	      => change which directory you're in
clear     => clear screen
mkdir     => creates a new directory
pwd       => prints the path of the directory you are currently in
rmdir     => removes/deletes an entire directory
upload    => stores a local file onto the server
size      => returns the size in bytes of the specified file
ls        => lists the contents of the directory
quit      => quit
	"""
os.system('clear')
try:
     host = raw_input('host : ')
     user = raw_input('user : ')
     passw = getpass.getpass()
     
     try:
          ftp = FTP('ftp.al-aryl.com')
     except socket.gaierror:
          print "Name or service not known"
     try:
          try:
               ftp.login('alarylco','carylsuripatty')
               print """
#############################################################
# Gxftp                                                     #
# Author: caryl                                             #
# Site: http://al-aryl.com, http://projects.gxrg.org        #
# Email: al_aryl@yahoo.com                                  #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups        #
#############################################################"""
               print '\n'+ftp.getwelcome()
          except ftplib.error_perm:
               print "Login authentication failed"
     except NameError:
          print "Check your User & Password"  
          sys.exit(1)      
     print '\n'
     try:
     	while True:
     		cmd = raw_input('>> ')
     		if "ls" in cmd:
     		     ftp.retrlines('list')
     		elif cmd == "rename":
				try:
					old = raw_input("From Name : ")
					to = raw_input("To Name : ")
					
					print "[+] ",ftp.rename(old,to)
				except:
					print "[-] Check from name"
     		elif "delete " in cmd:
				try:
					a = cmd.replace("delete ","")
					b = a.replace("\n","")
					
					print "[+] ",ftp.delete(b)
				except:
					print "[-] Check file name"
     		elif "cd" in cmd:
				try:
					a = cmd.replace("cd ","")
					b = a.replace("\n","")
					print "[+] ",ftp.cwd(b)
				except:
					print "[-] Check directory name"
     		elif cmd == "help" or cmd == "h":
     			help()
     		elif "mkdir " in cmd:
				try:
					a = cmd.replace("mkdir ","")
					b = a.replace("\n","")
					print "[+] ",ftp.mkd(b)," create"
				except:
					print "[-] Check directory name"
     		elif "rmdir " in cmd:
				try:
					a = cmd.replace("rmdir ","")
					b = a.replace("\n","")
					print "[+] ",ftp.rmd(b)
				except:
					print "[-] Check directory"
     		elif cmd == "pwd":
     			print "[+] "+ftp.pwd()
     		elif cmd == "exit" or cmd == "quit" or cmd == "q":
     		     ftp.quit()
     		     sys.exit(1)
     		elif cmd == "upload":
     		     upload()
     		elif "dir" in cmd:
				try:
					a = cmd.replace("dir ","")
					b = a.replace("\n","")
					print "[+] ",ftp.dir(b)
				except:
					print "[-] Check directory"
		elif "size" in cmd:
			try:
				a = cmd.replace("size ","")
				b = a.replace("\n","")
				print "[+] ",str(ftp.size(b)), " bytes."
			except:
				print "[-] Check your file"
          	elif cmd == "debug -b":
          		ftp.set_debuglevel(1)
          		print "Debug mode set to Base."
          	elif cmd == "debug -v":
          		ftp.set_debuglevel(2)
          		print "Debug mode set to Verbose."
          	elif cmd == "debug -o":
          		ftp.set_debuglevel(0)
          		print "Debug mode turned Off."
          	elif cmd == "download":
				download()
		elif cmd == "clear":
			     os.system(cmd)
          	elif cmd == "quit":
				ftp.quit()
				sys.exit(1)
     		else:
     			print "Unknown command"
     except ftplib.error_perm:
     	print "Unknown command"
except KeyboardInterrupt:
     print '\n[-] system exit'
     sys.exit(1)
