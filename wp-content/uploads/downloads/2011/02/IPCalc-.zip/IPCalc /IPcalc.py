#############################################################################
# Ipcalc v.0.1 (IPv4)                                   (c)copyleft 01/2011 #
# Author: d_kun                                   	                    #
# Email: dhika [dot] linix [at] gmail.com                                   #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups 	                    #
# license: Licensed under the GNU General Public License                    #
#############################################################################

#########################################################################
# ___________   _____       _            _       _              	#
#|_   _| ___ \ /  __ \     | |          | |     | |             	#
#  | | | |_/ / | /  \/ __ _| | ___ _   _| | __ _| |_  ___  _ __ 	#
#  | | |  __/  | |    / _` | |/ __| | | | |/ _` | __|/ _ \| '__|	#
# _| |_| |     | \__/\ (_| | | (__| |_| | | (_| | |_| (_) | |   	#
# \___/\_|      \____/\__,_|_|\___|\__,_|_|\__,_|\__|\___/|_|   	#
#                                                   Gxrg Crew  		#
#########################################################################

#notes :
#this program using netaddr module to use this program install netadddr frist

"""
Thanks to GxRg Linux Team : 
abi ,ray16, mad, v0dka, cgilla, virus, isal90, ch00ber, Azure, Bara, stupid, acha,
z4ke, d_kun, bag0el, etc 
"""

from os import *
from sys import *
try:
	from netaddr import *
	
except ImportError:
	print 'need netaddr module , please instal frist !'


def ClassIp():
	if ipnum1 == 10 :
		print 'info \t\t: Privat Class A '
	elif ipnum1 >= 1 and ipnum1 <=126:
		print 'info \t\t: This IP Class A '
	elif ipnum1 == 127:
		print 'info \t\t: Local Host '
	elif ipnum1 == 172 :
		if ipnum2 >= 16 and ipnum2 <= 31:
			print 'info \t\t: Privat Class B '
		else :
			print 'info \t\t: This IP Class B '
	elif ipnum1 >= 128 and ipnum1 <= 191 :
		print 'info \t\t: This IP Class B '
	elif ipnum1 == 192 and ipnum2 == 168 :
		print 'info \t\t: Privat Class C '
	elif ipnum1 >= 192 and ipnum1 <= 223 :
		print 'info \t\t: This IP Class C '
	elif ipnum1 >= 224 and ipnum1 <= 139 :
		print 'info \t\t: Multicast IP'
	else :
		print 'info \t\t: Reserved for future use, or Research and Development Purposes.'


system("clear")


print ('''
 ___________   _____       _            _       _              
|_   _| ___ \ /  __ \     | |          | |     | |             
  | | | |_/ / | /  \/ __ _| | ___ _   _| | __ _| |_  ___  _ __ 
  | | |  __/  | |    / _` | |/ __| | | | |/ _` | __|/ _ \| '__|
 _| |_| |     | \__/\ (_| | | (__| |_| | | (_| | |_| (_) | |   
 \___/\_|      \____/\__,_|_|\___|\__,_|_|\__,_|\__|\___/|_|   
                                                   Gxrg Crew  
                                                  

''')


try :
	print ("IP Calculator IPv4 v.0.1 ")
	print ("to use please insert IP number slash CIDR prefix bitmask \n ex: 192.xxx.xxx.xxx/24 \n")
	try :	
		ipinput = raw_input ("Insert Your Ip : ")
		ip = IPNetwork(ipinput)
	except UnboundLocalError:
		print "Oooppss ! wrong input ","\nplease input your Ip slash CIDR prefix bitmask"
		exit(1)
	except ValueError:
		print "Oooppss ! wrong input ","\nplease input your Ip slash CIDR prefix bitmask"
		exit(1)
	jumip = len(ip)
	i = jumip - 1 
	yourip = ip.ip
	host = jumip - 2
	netmask = ip.netmask
	broadcast = ip.broadcast
	netid = ip.network
	ipnext = IPNetwork(netid)
	ipprev = IPNetwork(broadcast)
	ipnum1 = int(IPAddress(yourip).words[0])
	ipnum2 = int(IPAddress(yourip).words[1])
	print "\n"
	print "Your IP \t:",str(yourip)
	print "Network ID \t:",str(netid)
	print "IP Broadcast \t:",str (broadcast)
	print "Netmask \t:", netmask
	print "IP Range \t:", ipnext.next().ip,"-",ipprev.previous().ip
	if host < 0 :
		print "Ip Host \t: 0"
	else :
		print "Ip Host \t:" , host
	print "All Ip  \t:", jumip

	ClassIp()
	print "\n"
except KeyboardInterrupt :
	print "\n"
	exit(1)
	



 
     
