#!/usr/bin/env ruby1.8
## ####################################################################################### ##
## Adminpf - Admin page finder v0.1							   ##
## (C) Credits - [G]gunadarma[X]xmalang[R]research[G]groups, 2012 // Author: gear0wn_	   ##
## ####################################################################################### ##
## This program is free software: you can redistribute it and/or modify it under the terms ##
## Of the GNU General Public License http://www.gnu.org/licenses.			   ##
## This program is distributed in hope that it will be useful.				   ##
## But Without any Warranty, just for share and education purpose only.			   ##
## Project site http://projects.gxrg.org/						   ##
## ####################################################################################### ##

require 'thread'
require 'open-uri'
require 'getoptlong'

class Admin
 attr_accessor :host, :agent, :agent_store,
	       :array, :gen_host # Make this public
 attr_reader :status # Can't change after initialize
  def initialize(args={})
	@array=[] # Use for pooling things
	@host=(args[:host]) # Host target store here
	@gen_host=(args[:gen_host]) # List generate host with path
	@agent=(args[:agent]) # Random user-agent set to True if use, False if not
	@agent_list='/pentest/database/sqlmap/txt/user-agents.txt' # Generate from user-agent list sqlmap/1.0-dev (r4009).
	@agent_store=['Mozilla/5.0 (X11; Linux i686; rv:9.0.1) Gecko/20100101 Firefox/9.0.1'] # This is default user-agent but we can change it.
	gen_agent! if agent
  end
  def gen_agent!
	File.open(@agent_list).each do |random|
		array.push(random) unless random.match(/#/)
	end
		@agent_store=array[rand(array.length)].strip!
		array.clear
	rescue Errno::ENOENT => errfile
		puts "[-] Sorry can't use this option. Reason: %s" %errfile.message
		puts "[+] Run with default User-agent: %s" %agent_store
  end
  def run_finder(target)
	open(target,
	     'User-Agent' => agent_store.to_s
	    ) {|result| array << ("-> #{target}\s%s\sFound") %result.status[0]
			("-> \e[32m%s\sFound\e[0m") %result.status[0] }
		rescue => ec0de
	 case ec0de
	   when OpenURI::HTTPError
		if ec0de.message.match(/403\sForbidden/)
		   array << ("-> #{target} #{ec0de.message.upcase} is worth to check")
		   ("-> \e[34m%s\e[0m is worth to check") %ec0de.message
		elsif ec0de.message.match(/404\sNot\sFound/)
		   array << ("-> #{target} #{ec0de.message.upcase}")
		   ("-> \e[31m%s\e[0m") %ec0de.message
		end
	   when RuntimeError
		if ec0de.message.match(/redirection\sforbidden/)
		   array << ("-> #{target} #{ec0de.message.match(/redirection\sforbidden/)[0].upcase} is worth to check")
		   ("-> \e[34m%s\e[0m is worth to check") %ec0de.message.match(/redirection\sforbidden/)[0].upcase
		end
	   when Timeout::Error
		   ec0de.message
		retry
	   when Errno::ETIMEDOUT
		   ec0de.message
		retry
	   when Errno::ECONNREFUSED
		   ("-> \e[31m%s\e[0m") %ec0de.message
		retry
	   end
		rescue Timeout::Error => timeout
		   ("-> \e[31m'Fail'\s%s\s\s\e[0m | \e[34mReason\e[0m: It looks like your running on slow network or the site is taking to long respons") %timeout.message.upcase
  end
  def page
	qpool=Queue.new # here we create new pool for threading
	mpool=Mutex.new # use for handling pool threading
	gen_host.each { |gen| qpool << gen }
	gen_host.length.times.map {
	  Thread.new do
		while !qpool.empty?
		target_in_pool=qpool.pop(true)
		target_get_status=run_finder(target_in_pool)
		mpool.synchronize {
		    yield target_in_pool, target_get_status
		}
		end
	  end
	}.each { |x| x.join }
		puts "\n[+] Finish."
			gen_log # Generate log if finish
		rescue Interrupt
			puts "[-]\s\e[31mInterrupt\sby\suser\e[0m"
			gen_log # save the rest of log to report cause by interrupt
			exit()
	   	rescue NameError => nerr
		   	puts "[-]\s\e[31mHost\sNot\sFound\e[0m"
  end
  def gen_log
	logh=host[0].split('/')[2]+'.log'
	log=File.open(logh,'w')
	log.puts "# Adminpf - Admin page finder log report"
	log.puts "# Generate at #{Time.now.ctime}\n"
	log.puts "# Status:"
	log.puts "# 	 -  200 Found		  : Status page found"
	log.puts "#	 -  404 Not Found	  : Status page not found"
	log.puts "#	 -  403 Forbidden	  : Status page is forbidden but it might be possible page found"
	log.puts "#	 -  REDIRECTION FORBIDDEN : Status page is forbidden and get redirect but it still possible page found."
	log.puts "#\n#\n# Result:"
	log.puts "	[+] Target host: #{logh.split('.log')}"
	log.puts "	[+] User Agent : #{agent_store}"
	log.puts "	[+] Finish time: #{Time.now.ctime}"
	log.puts "\n\n"
	log.puts array
	puts "[+] Generate Log report: %s" %logh
	exit()
  end
  def help(*arg)
	sleep(0.1);printf("\n	%s - Admin page finder version %s\n",arg[0],arg[2])
	printf("	http://christian.gxrg.org | %s\n\n",arg[4])
	printf("Author by: %s %s\n",arg[1],arg[3])
	printf("Usage: %s [options] [host]\n",arg[0])
	printf("Options: -u, --url		set host target\n")
	printf("	 -p, --path		set your own custom admin path list\n")
	printf("	     --random-agent	set adminpf to run with random user agent\n") 
	printf("	 -h, --help		display this message\n")
	printf("	 -v, --version		display adminpf version and exit\n\n")
	printf("Example: %s --url http://example.com\n",arg[0])
	printf("	 %s --url http://example.com --path your_own_custom_path.txt --random-agent\n\n",arg[0])
	exit()
  end
end

############ Define Default Instance ############
basename	= __FILE__
author		= 'gear0wn_'
version		= 'v0.1'
date		= 'January 2012'
site		= 'http://projects.gxrg.org'
path		= 'admin-path-list.txt'
url_host	= nil
url_host_gen	= []
status		= false
agent		= false
opt_required	= false
list_options	= []

############# Define new object ###################

usage=Admin.new
opts=GetoptLong.new(
     ['--url', '-u', GetoptLong::REQUIRED_ARGUMENT],
     ['--path', '-p', GetoptLong::OPTIONAL_ARGUMENT],
     ['--random-agent', GetoptLong::NO_ARGUMENT],
     ['--help', '-h', GetoptLong::NO_ARGUMENT],
     ['--version', '-v', GetoptLong::NO_ARGUMENT]
)
ARGV.each { |cmd| list_options << cmd }

############### Argument parsing ##################

begin
opts.each { |opt,arg|
  case opt
    when '--url' || '-u'
	if list_options.include?(opt) || list_options.include?('-u')
	   opt_required=true
	   url_host=arg.split(',')
	else
	   printf("%s: invalid option `#{list_options.grep(/--u|-u/)}' invalid option\n",basename)
	   usage.help(basename,author,version,date,site)
	end
    when '--path' || '-p'
	if list_options.include?(opt) || list_options.include?('-p')
	   path=arg unless arg.eql?("")
	else
	   printf("%s: invalid option `#{list_options.grep(/--path|-p/)}' invalid option\n",basename)
	   usage.help(basename,author,version,date,site)
	end
    when '--random-agent'
	if list_options.include?(opt)
	   agent=true
	else
	   printf("%s: invalid option `#{list_options.grep(/--r|-r/)}' invalid option\n",basename)
	   usage.help(basename,author,version,date,site)
	end
    when '--help' || '-h'
	   usage.help(basename,author,version,date,site)
    when '--version' || '-v'
	   printf("%s - Version: %s\n",basename.gsub('./a','A'),version)
	   exit()
  end
}
	usage.help(basename,author,version,date,site) if opt_required.eql?(false)
rescue
usage.help(basename,author,version,date,site)
end

## Filter url here ##
for index in 0..url_host.length-1
	if url_host[index].split('/').include?('http:')
	   url_host[index] << '/' unless url_host[index][-1,1].eql?('/')
	else
	   url_host[index].insert(0, 'http://')
	   url_host[index] << '/' unless url_host[index][-1,1].eql?('/')
	end
end

## Combine path and host list here ##
File.open(path).each { |list| url_host_gen << url_host[0]+list.strip }


### Call function ###
call=Admin.new( :host => url_host,
		:path => path,
		:gen_host => url_host_gen,
		:status => status,
		:agent => agent)
puts "++++++++++++++++++++++++++++++++++++++++++++++"
puts "	Adminpf - Admin page finder %s" %version
puts "	Author	- %s" %author
puts "	Project - %s\n" %site
puts "++++++++++++++++++++++++++++++++++++++++++++++"
puts "[+] Host: %s" %url_host
puts "[+] Path: %s\n\n" %path
call.page do |target,status|
	puts "#{target} #{status}"
end

##EOF##
