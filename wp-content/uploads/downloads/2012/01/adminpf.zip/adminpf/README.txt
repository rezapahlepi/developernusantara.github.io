================================
adminpf - Admin Page Finder v0.1
================================

Author by   : gear0wn_ January/2012
Email       : gear0wn_@gxrg.org
Site        : http://projects.gxrg.org | http://christian.gxrg.org
Credits     : [G]gunadarma[X]xmalang[R]research[G]groups

Thanks to God,GXRG.
Thanks to ray16,_mac

How to install and use :

[*] Running on Linux debian :
    - install ruby version 1.8, apt-get install ruby ruby-full
    - add execute permission, chmod +x dork-finder.rb
    - ./adminpf.rb [options]

[*] Running on Windows :
    - install ruby version 1.8
    - download installer on -> http://www.ruby-lang.org/id/
    - ruby adminpf.rb [options]

[*] Report error :
    - Report error to <gear0wn_@gxrg.org>
