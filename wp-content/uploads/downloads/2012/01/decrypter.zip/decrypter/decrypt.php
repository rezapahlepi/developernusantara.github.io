#!/usr/bin/php
<?php
## ####################################################################################### ##
## Hash Decrypter - md5 hash cracker v0.1                                                  ##
## (C) Credits - [G]gunadarma[X]xmalang[R]research[G]groups, 2012 // Author: mac_          ##
## ####################################################################################### ##
## This program is free software: you can redistribute it and/or modify it under the terms ##
## Of the GNU General Public License http://www.gnu.org/licenses.                          ##
## This program is distributed in hope that it will be useful.                             ##
## But Without any Warranty, just for share and education purpose only.                    ##
## Project site http:://projects.gxrg.org/                                                 ##
## ####################################################################################### ##
class decrypter {

     const __credit__ = '[G]unadarma [X]malang [R]esearch [G]roup';

     private $hash, $rsource, $init, $ext, $uri = 'http://www.md5cracker.org/';
     public $result, $agent = array('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1',
			'Googlebot/2.1(http://www.googlebot.com/bot.html');

     function __construct($data) {
	   declare(ticks = 1);
	   $this->hash = $data;
	   $this->ext = get_loaded_extensions();
	   print $this->banner();

	   try {
	      if(strlen($this->hash) < 32 || strlen($this->hash) > 32)
		 throw new exception($this->format('Invalid','Md5-Hash must be 32 character!'));

	      if(!in_array('curl',$this->ext))
		 throw new exception($this->format('Error','you must install Curl extension before run this program'));

	   }catch(Exception $get) {
		 exit($get->getMessage() . "\n" .self::__credit__."\n");
	   }

   	   pcntl_signal(SIGINT, 'self::signal_handler');
	   $this->decrypt($this->hash);
     }

     function format($type,$data,$respon='') {
	   $data = preg_replace('/"/',"",$data);
	   switch($type) {
		case "Invalid":
		      echo " \033[0;37m[!]\033[0;36m".$data."\033[0m\n";
		      break;
		case "NotFound":
		      echo " \033[0;37m[-]\033[1;34m".$data."\033[0m->\033[0;31m Not Found!\033[0m\n";
		      break;
		case "Found":
		      echo " \033[0;37m[+]\033[1;34m".$data."\033[0m->\033[0;37m ".$respon."\n";
		      break;
		case "Error":
		      echo "\n \033[0;37m[!]\033[0;36m".$data."\033[0m\n\n";
	   }

     }

     function signal_handler($no) {
	   if($no == SIGINT)
		exit($this->format('Error',"Interrupt by user. . .\n\n"));
     }

     function decrypt($hash) {
	   $cont =1;
	   try {
		do {
		      $this->init = curl_init($this->uri.'/hash.php?hash='.$this->hash.'&id='.$cont);
		      curl_setopt_array($this->init, array(CURLOPT_USERAGENT  	=> $this->agent[array_rand($this->agent)],
						     CURLOPT_RETURNTRANSFER	=> 1,
						     CURLOPT_TIMEOUT		=> 25));
		      $this->rsource = curl_exec($this->init);
		      if(curl_errno($this->init))
			      throw new exception(curl_error($this->init));

		      curl_close($this->init);
		      if(preg_match_all('/#--#(.*?)#--#|(http:\/\/(.*?)\")/',$this->rsource,$got)) {

			      $this->result = array_values($got[0]);
			      list($path,$md5) = split('#--#|/"',implode($this->result));

			      if(substr($md5,0,7) == 'Der MD5') {
				      $this->format('Invalid',"it's seem the chars not typically MD5!");

			      }elseif(preg_match_all('/notfound-*|\s+/',$md5,$h)){
				      $this->format('NotFound',$path);

			      }else {
				      if(empty($md5)) {
					      $this->format('NotFound',$path);
				      }else {
					      $this->format('Found',$path,$md5);
				      }
			      }

		      }$cont++;


		}while($cont < 13);

	   }catch(Exception $x) {
		      exit($this->format('Error',$x->getMessage()) . self::__credit__ . "\n\n");
		}

     }

     static function banner() {
      echo "
 /   |   \_____    _____|  |__   \______ \   ____   ___________ ___.__._______/  |_  ___________
/    ~    \__  \  /  ___/  |  \   |    |  \_/ __ \_/ ___\_  __ <   |  |\____ \   __\/ __ \_  __ \
\    Y    // __ \_\___ \|   Y  \  |    `   \  ___/\  \___|  | \/\___  ||  |_> >  | \  ___/|  | \/
 \___|_  /(____  /____  >___|  / /_______  /\___  >\___  >__|   / ____||   __/|__|  \___  >__|
       \/      \/     \/     \/          \/     \/     \/       \/     |__|        v.0.1\/by mac_  \n\n";

     }
}

if($_SERVER['argc'] < 2 or $_SERVER['argc'] > 2){
      decrypter::banner();
      die(" Usage: " .$_SERVER['argv'][0]. " [hash]\n\n".decrypter::__credit__."\n\n");
}
$init = new decrypter($_SERVER['argv'][1]);
print "\n" . decrypter::__credit__ . "\n\n";

?>
