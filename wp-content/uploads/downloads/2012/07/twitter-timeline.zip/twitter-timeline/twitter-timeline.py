#!/usr/bin/python

# Version 1.0.
# Author ebby.net.
# [G]unadarma [X]malang [R]esearch [G]roup.

import socket,urllib, re, sys, getopt

def main(argv):
   e = "+++++++++++++++++++++++++++++++++++++++++"
   b = "Author ebby.net."
   y = "[G]unadarma [X]malang [R]esearch [G]roup."
   user = ""
   count = ""
   
   try:
      opts, args = getopt.getopt(argv,"hu:c:",["user", "count"])
   
   except getopt.GetoptError:

      print "[+]Error Command Usage."
		
      print "\n[+]Options:\n" 
      print "\t-h,   :: show this help message and exit ::"
      print "\t-u,   :: The user of twitter ::"
      print "\t-c,   :: Specifies the number of tweets to try and retrieve, up to a maximum of 200 ::\n"
		
      
      sys.exit(2)
   
   for opt, arg in opts:
      if opt == '-h' and '--help' :
         
	 print "\nCommand Usage:\n\n\tpython twitter-timeline.py -u [user] -c [count]"
         print "\tpython twitter-timeline.py -u dooot_"
         print "\tpython twitter-timeline.py -u dooot_ -c 10"
         
	 print "\nOptions:\n" 
         print "\t-h,   :: show this help message and exit ::"
         print "\t-u,   :: The user of twitter ::"
         print "\t-c,   :: Specifies the number of tweets to try and retrieve, up to a maximum of 200 ::"

	 sys.exit()
      
      elif opt == '-u' and '--user' :
		user = arg
      
      elif opt == '-c' and '--count' :
                count = arg
    
   username = user
   counter = count
   
   totet = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   totet.connect (("www.twitter.com", 80))
   file = totet.makefile('r', 0)
   url = "/statuses/user_timeline.xml?screen_name="+username+"&count="+counter

   idiot = "GET "+url+" HTTP/1.0\r\n\r\n"
   file.write(idiot)
   buff = file.readlines()
   print e+"\n"+b+"\n"+y+"\n"+e+"\n"
   for i in buff:
            if re.search("<text>",i):
                   recv = i.split("<text>")[1]
                   exp = recv.split("<")[0]
                   print "Tweet "+username+" >> "+exp


if __name__ == "__main__":
   main(sys.argv[1:])
   print "\n+++++++++++++++++++++++++++++++++++++++++"

#EOF
