twitter-timeline 1.0

Run this in command prompt!!!

python twitter-timeline.py  -u <username> or python twitter-timeline.py -u <username> -c <10>


===Project Home===

http://projects.gxrg.org/


===Arguments===

-h,   :: show this help message and exit ::"
-u,   :: The user of twitter ::"
-c,   :: Specifies the number of tweets to try and retrieve, up to a maximum of 200 ::\n"



