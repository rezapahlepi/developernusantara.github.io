#!/usr/bin/env ruby1.8
## ######################################################################################## ##
## BatteryNotif - Battery notification (rev0.3)						    ##
## (C) Credits  - GXRG, May 2012 // Author: gear0wn_					    ##
## ######################################################################################## ##
##											    ##
## This program is free software: you can redistribute it and/or modify it under the terms  ##
## Of the GNU General Public License http://www.gnu.org/licenses.			    ##
## This program is distributed in hope that it will be useful.				    ##
##											    ##
## Project site: * http://projects.gxrg.org/						    ##
##											    ##
## Description : * This program simply check your battery status. when your current battery ##
##		   Is low or less than you expected, you will be warn.			    ##
## Disclaimer  : * I know there is more good and fancy tools out there for handling this    ##
##		   Kind of situation. but, i made this only for my self code documentation  ##
##		   And fill what i needs that's all.					    ##
##											    ##
## ######################################################################################## ##

begin
  require 'tk'
   rescue LoadError => tklib
	printf("\e[31m[-]\e[0m Error: %s\n",tklib.message.capitalize)
	printf("\e[34m[+]\e[0m Howto: Please install tklib gui first for notification pop-up\n")
	printf("\t\s\s\s* aptitude install libtcltk-ruby1.8\n")
	exit()
   rescue RuntimeError => env
end

class BatteryNotif
 attr_accessor :info, :state,
	       :max, :path # Make all this for _public_
  def initialize(max) # _Construct_
	self.max   = max
	self.path  = '/proc/acpi/battery'
	self.info  = path + '/%s' + '/info'
	self.state = path + '/%s' + '/state'
	self.is_exist? # First call
  end
	## Check and grab available slot ##
  def is_exist?
	state = self.state
	info  = self.info
	Dir.foreach(self.path) do |slot|
	    next if slot.match(/\./)
		self.state = state % slot
		self.info  = info % slot
		is_present? ? (state = self.state
			       info = self.info):()
	end
  end
	## Check for battery presence ##
  def is_present?
      present  = File.open(state,'r').read.scan(/present:\s+(\w+)/).to_s
	return present.eql?('yes')
		rescue Errno::ENOENT
			present = false
  end
	## Check for charging status ##
  def is_charging?
      ch_stats = File.open(state,'r').read.match(/charging.*\:\s+(\w+)/)[1]
	return ch_stats.eql?("discharging")
  end
	## Get and calculate current power ##
  def get_power
      capacity = File.open(info,'r').read.scan(/last.*/)[0].match(/\d+/)[0].to_i
      rate,remains = File.open(state,'r').read.
			  scan(/remaining.*\:\s+(\d+)|rate:\s+(\d+)/)
      rate,remains = Integer(rate.compact![0]),Integer(remains.compact![0])
      current = (100 * remains / capacity)
	unless rate.eql?(0)
		hours   = (1 * remains) / (1 * rate)
		minutes = (60 * remains / rate - hours * 60)
		minutes = minutes.to_s.insert(0,'0') if minutes.to_s.length.eql?(1)
		hours	= hours.to_s.slice(0,1).to_i if hours.to_s.length > 1
		estimate= '%s:%s' % [hours,minutes]
	else
		estimate= 'Full ( AC is on-line )'
	end
	return current <= max,current,estimate
  end
	## Notification will pop-up, so we get warn ##
  def notif(curr,estimate)
	mesg = "Please recharge your battery now
		Status: %s -- %s".gsub(/\t/,'') % [String(curr)+'%',estimate]
	wind = TkRoot.new( :title => "WARNING",
			   :wm_geometry => '-5+5',
			   :resizable => [ false, false ]
			 )
	       TkLabel.new(wind) do
			   justify('left')
			   text(mesg)
			   font('size' => 12, 'family' => 'terminus')
			   pack('padx' => 15, 'pady' => 15)
	       end
	       Tk.mainloop
	       Tk.restart
  end
end

	## Class config batterynotif ##
class Config
 attr_accessor :init, :max,
	       :tmp, :bconf
  def initialize
	self.bconf = '/etc/batterynotif.conf'
	self.init = nil
	self.max = nil
	self.tmp = '' # Tmp old conf in case you change maximum bat warn.
	self.chkbconf # Check config file first
  end
	## Check and grab config here ##
  def chkbconf
	begin
	   File.open(bconf,'r').each do |conf|
		conf.index(/#/) ?
		    self.tmp += conf:
		    self.tmp += conf.gsub(/\d+/,'%s')
		next if conf.match(/#/)
		re = conf.match(/.*[^\n]/).to_s
		unless re.nil?
		    self.max  = Integer(re.match(/\d+/).to_s) if re.match(/warn/)
		    self.init = String(re.match(/\/.*/).to_s) if re.match(/\//)
		end
	   end
	rescue Errno::ENOENT => conferr
		printf("\e[31m[-]\e[0m Error: %s\n",conferr)
		exit()
	end
  end
	## Set notif warn for battery ##
  def set_notif(warn_at)
	cf = File.open(bconf,'w')
	cf.puts tmp % warn_at
	cf.close
	puts "\e[34m[+]\e[0m Battery warn notification set to %s%" % warn_at
	puts "    Please restart batterynotifd to take the effect."
  end
	## Get enviroment init script ##
  def chkenv
       mesgs = "Since batterynotif is running daemon, scripts is invoking to init through /etc/init.d
		Please use init scripts or service(8) utility, e.g. /etc/init.d/batterynotifd [command]
		See help message for more info, type: batterynotif --help".gsub(/\t/,'')
	if ENV.has_key?('_')
	     abort(mesgs) if ENV['_'] == __FILE__ || ENV['_'] != init
	else
	     abort(mesgs)
	end
  end
	## Display info usage/version ##
  def msg(param)
	name = __FILE__.split(/\//).last
	date = "May 2012"
	site = [ '[ http://projects.gxrg.org', 'http://christian.gxrg.org ]' ]
	author = "gear0wn_"
	mesg = "Author by %s // %s
		Site   %s\n
		Usage: %s [options] [args]
		Options: -n, --notif-set          set new warn notif percent
		         -s, --status-bat         display status battery percent and time left
		         -v, --version            display %s current version
		         -h, --help               display this message\n
		Example: %s --notif-set 30
		".gsub(/\t/,'')
	puts "%s -- version: 1.0 (rev0.3)" % name if param.eql?('version')
	puts mesg % [author,date,
		     site.join(' '),
		     name,name,name] if param.eql?('help')
  end
end
	## New instance objects calls ##
	cek = Config.new
	run = BatteryNotif.new(cek.max)

	## Get arg'n environment path ##
	optls = [ '-n', '--notif-set',
		  '-s', '--status-bat',
		  '-v', '--version',
		  '-h', '--help'
		]
	gopts = []
	   if ARGV.length.eql?(1) || ARGV.length.eql?(2)
	      ARGV.each { |opt| gopts << opt }
		if gopts.include?(optls[0]) || gopts.include?(optls[1])
		  begin
		   arg = Integer(ARGV[1])
		   if arg == 0
			mesg = "\e[31m[-]\e[0m Error: Option `%s' needs argument, e.g. 20
			           See help message for more info.".gsub(/\t/,'')
			puts mesg % [gopts[0]]
			exit()
		   else
			cek.set_notif(arg)
			exit()
		   end
		  rescue
			puts "\e[31m[-]\e[0m Error: Argument must be number/integer, e.g: 20"
			exit()
		  end
		elsif (gopts.include?(optls[2]) || gopts.include?(optls[3])) && ARGV[1].nil?
			(run.is_present? ? (curr,est = run.get_power[1..2]
			puts "\e[34m[+]\e[0m Status: %s -- %s" % [curr.to_s+'%',est ]):
			(puts "\e[34m[+]\e[0m Status: AC power is in use."))
			exit()
		elsif (gopts.include?(optls[4]) || gopts.include?(optls[5])) && ARGV[1].nil?
			cek.msg('version')
			exit()
		elsif (gopts.include?(optls[6]) || gopts.include?(optls[7])) && ARGV[1].nil?
			cek.msg('help')
			exit()
		else
			optls[2..7].include?(gopts.first) ?
			(puts "\e[31m[-]\e[0m Error: %s can't take an argument" % gopts.first):
			(puts "\e[31m[-]\e[0m Error: No such option %s" % gopts.join(' '))
			exit()
		end
	   elsif ARGV.length > 2
			puts "\e[31m[-]\e[0m Error: No such option %s" % [ARGV-optls].join(' ')
			exit()
	   else	
			cek.chkenv

	   end

	## Always loop and sleep here ##
	loop do
		sleep(5)
		next unless run.is_present?
		bool,curr,est = run.get_power
		run.notif(curr,est) if bool and run.is_charging?
	end
	## EOF ##
