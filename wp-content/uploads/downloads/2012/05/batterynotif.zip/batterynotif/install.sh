#!/bin/bash
#
# * BatteryNotif -- Installer script
#
# Author gear0wn_ // May 2012
# (C) GXRG // projects.gxrg.org
#
# This is installer script for batterynotif program.
# We must run it first otherwise, everything will not work properly.
#
# Begin

## Checking file system function ##
function fs_check {
	BIN="/opt" # this is directory bin where we will put batternotif
	SBIN="/usr/sbin" # this is directory where we will link the bin of batterynotif
	INIT="/etc/init.d" # this is default service directory for main program of batterynotif
	RB_ENV=`which ruby1.8` # checking ruby environment bin [ requirement ruby1.8 ]
	BASE_NAME="BatteryNotif" # this is our program name for directory
		echo -n "Checking File-System.. "
		sleep 0.1
			if [ -d "$BIN" ] && [ -d "$INIT" ] && [ -d "$SBIN" ]; then
				echo "done"
			else
				echo "failed."
				echo "Error: File system not match."
				exit 1
			fi
		echo -n "Checking Environment.. "
		sleep 0.1
			if [ -e "$RB_ENV" ]; then
				echo "done"
				echo "Matching ruby1.8 environment."
				sleep 0.1
			else
				echo "failed"
				echo "Error: Not matching for requirement ruby1.8 environment."
				echo "       The program 'ruby' is currently not installed."
				echo "Try: apt-get install ruby ruby-full rubygems"
				exit 1
			fi
		echo -n "Checking dependencies.. "
		sleep 1
	LIB=($(aptitude search libtcltk-ruby1.8))
			if [ "$LIB" == "p" ]; then
					echo "$BASE_NAME dependencies libtcltk-ruby1.8 for pop-up message is not installed yet"
						sleep 0.1
					echo -n -e "Install now [Y/n] ? "
				read ans
					if [ "$ans" == "Y"] || [ "$ans" == "y" ]; then
						echo "Installing dependencies now."
						sleep 0.1
						echo "Please wait a moment"
						sleep 1
						aptitude install libtcltk-ruby1.8 -y >/dev/null
						echo "Done"
					else
						echo "$BASE_NAME will need this dependencies, you must install that manually"
					fi
			else
				echo "It looks like dependencies already installed, nothing to do."
				sleep 1
			fi
}

## Process installation function ##
function run_install {
		echo "Creating Directory bin PATH: /opt/BatteryNotif"
		mkdir -p $BIN/$BASE_NAME 2>/dev/null
		sleep 0.2
		echo "Copying $BASE_NAME main program.."
		sleep 0.2
		chmod +x batterynotif.rb
		cp batterynotif.rb README $BIN/$BASE_NAME 2>/dev/null
		rm batterynotif.rb 2>/dev/null
		sleep 1
		echo "Creating $BASE_NAME service program.."
echo '#!/bin/bash
##
## INIT scripts for batterynotif
##
## Author: gear0wn_ // May 2012
## (C) GXRG // http://projects.gxrg.org
##
## Desc: This script is simply use to start,stop,restart and check batterynotif status
##

# We declare name,pidfile and main program var
NAME=batterynotif
PID_FILE=/var/run/$NAME.pid
MAIN_PROGRAM='$SBIN'/$NAME

# Option argument with case
case "$1" in
	start)
		if [ -f "$PID_FILE" ]; then
	      pid=$(cat $PID_FILE 2>/dev/null)
	      echo -ne "+ $NAME start/running, pid: $pid"
	      sleep 1
	      echo -ne "\n"
		else
	      start-stop-daemon --start --quiet -m --pidfile $PID_FILE --background --exec $MAIN_PROGRAM 2>/dev/null
	      pid=$(cat $PID_FILE 2>/dev/null)
	      echo -ne "+ $NAME start/running, pid: $pid"
	      sleep 1
	      echo -ne "\n"
		fi
	     ;;
	stop)
	      start-stop-daemon --stop --quiet --oknodo --pidfile $PID_FILE 2>/dev/null
	      pid=$(cat $PID_FILE 2>/dev/null)
	      echo -ne "+ $NAME stop/waiting"
	      sleep 1
		if [ -f "$PID_FILE" ]; then
			kill -9 $pid 2>/dev/null
			rm $PID_FILE 2>/dev/null
		fi
	      echo -ne "\n"
	     ;;
	restart)
		if [ -f "$PID_FILE" ]; then
	      pid=$(cat $PID_FILE 2>/dev/null)
		    echo -ne "+ $NAME stop/waiting"
		    sleep 0.1
	      start-stop-daemon --stop --quiet --oknodo --retry 30 --pidfile $PID_FILE 2>/dev/null
		    kill -9 $pid 2>/dev/null
		    rm $PID_FILE 2>/dev/null
	      start-stop-daemon --start --quiet -m --pidfile $PID_FILE --background --exec $MAIN_PROGRAM 2>/dev/null
	      pid=$(cat $PID_FILE 2>/dev/null)
		    echo -ne "\n+ $NAME start/running, pid: $pid"
		    sleep 1
		    echo -ne "\n"
		else
	      start-stop-daemon --start --quiet -m --pidfile $PID_FILE --background --exec $MAIN_PROGRAM 2>/dev/null
	      pid=$(cat $PID_FILE 2>/dev/null)
		    echo -ne "+ $NAME status start/running, pid: $pid"
		    sleep 1
		    echo -ne "\n"
		fi
	     ;;
	status)
		if [ -f "$PID_FILE" ]; then
	      pid=$(cat $PID_FILE 2>/dev/null)
		    echo -ne "+ $NAME status running, pid: $pid"
		    sleep 1
		    echo -ne "\n"
		else
		    echo -ne "+ $NAME status stop/waiting"
		    sleep 1
		    echo -ne "\n"
		fi
	     ;;
	*)
	      echo -ne "Usage: "$0" {start|stop|restart|status}\n"
	      exit 1
esac
exit 0
#EOF' > batterynotifd ; chmod +x batterynotifd ; mv batterynotifd $INIT 2>/dev/null
		sleep 1
		echo "Creating Symbolic link.."
		sleep 0.2
		ln -s $BIN/$BASE_NAME/batterynotif.rb $SBIN/batterynotif 2>/dev/null
		sleep 1
		echo "Creating Configuration file PATH: /etc/batterynotif.conf"
		sleep 1
echo "# $BASE_NAME configuration file.
#
# This is default main config file generate at first install.
# Of course you can change this config as what you need.
# Change with following param below.
#			param warn : 20 ( This is set by default and it means you'll be warn if the battery power is less than 20.
#			param init : /sbin/start-stop-daemon ( This is default, DONT change this unless your start-stop-daemon program
#							       is installed at different path.
#
# NOTE: This configuration file is a case sensitive so please change exactly the same as the EXAMPLE below.
#
# EXAMPLE:
# warn : 30
#

# Max warn percent
warn : 20
# Default init path
init : /sbin/start-stop-daemon
" > batterynotif.conf ; mv batterynotif.conf /etc/
		echo -ne "\n$BASE_NAME warn percent is set to 20 ( Default )\n"
		echo "See help message or config file if you wish to change."
		sleep 5
		echo "$BASE_NAME installed."
		sleep 1
		echo "* Starting batterynotif program.."
		sleep 1
		/etc/init.d/batterynotifd start
		echo -ne "* Done.\n"
		exit 0
}
	you=`whoami`

## MAIN ##
		if [ "$you" == "root" ]; then
			echo -n -e "Do you want to install batterynotif [Y/n] ? "
			read ans
			    if [ "$ans" == "y" ] || [ "$ans" == "Y" ]; then
				fs_check && run_install
				exit 0
			    elif [ "$ans" == "n" ] || [ "$ans" == "N" ]; then
				echo "Aborting installation process."
				sleep 1
				echo "Quit."
				exit 0
			    else
				echo "Sorry, you have to type [Y/n]"
				exit 0
			    fi
		else
			echo "Sorry, running this installer require a superuser privileges (eg. root)."
			exit 0
		fi
## EOF ##
