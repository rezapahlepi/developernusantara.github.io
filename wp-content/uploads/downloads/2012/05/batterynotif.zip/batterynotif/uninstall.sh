#!/bin/bash
#
# * BatteryNotif -- Uninstaller script
#
# Author gear0wn_ // May 2012
# (C) GXRG // projects.gxrg.org
#
# This is uninstaller script for batterynotif program.
#
# Begin


# Check privilege. must be 'root'
who=`whoami`

# BatteryNotif directory bin
batbin="/opt/BatteryNotif"

# BatteryNotif Configuration and Pid file
batconf="/etc/batterynotif.conf"
batpid="/var/run/batterynotif.pid"

# BatteryNotif symlink
binlink="/usr/sbin/batterynotif"
service="/etc/init.d/batterynotifd"

function uninstall {

echo -ne "\nUninstalling BatteryNotif:"
	sleep 1
echo -ne "\n\nRemoving installation directory."
rm -rf $batbin 2> /dev/null
	sleep 0.1
echo -ne "\nRemoving Configuration files."
rm $batconf 2> /dev/null
rm $batpid 2> /dev/null
	sleep 0.1
echo -ne "\nRemoving symbolic link."
rm $binlink 2> /dev/null
rm $service 2> /dev/null
	sleep 1

echo -ne "\n\nUninstallation completed.\n"
	sleep 1
}

	# This is first running
	if [ "$who" == "root" ]; then
		echo -ne "Are you sure you want to remove/uninstall BatteryNotif [Y/n] ? "
		read ans
	   if [ "$ans" == "Y" ] || [ "$ans" == "y" ]; then
		uninstall
		exit 0
	   elif [ "$ans" == "N" ] || [ "$ans" == "n" ]; then
		echo -ne "\nAbort uninstallation."
		sleep 1
		echo -ne "\nExit.\n"
	   else
		echo -ne "Sorry, you must type [Y/n]"
	   fi
	else
		echo -ne "Error: Failed remove/uninstall BatteryNotif"
		echo -ne "     - You need 'root' privileges."
		exit 0
	fi

#
# EOF
#
