/* Encrypts and decrypts text
Author: farid
Date: 26/10/10
for : projects.gxrg.org
                             __                                    .__
  ___________ ___.__._______/  |_  ____   ________________  ______ |  |__
_/ ___\_  __ <   |  |\____ \   __\/  _ \ / ___\_  __ \__  \ \____ \|  |  \
\  \___|  | \/\___  ||  |_> >  | (  <_> ) /_/  >  | \// __ \|  |_> >   Y  \
 \___  >__|   / ____||   __/|__|  \____/\___  /|__|  (____  /   __/|___|  /
     \/       \/     |__|              /_____/            \/|__|        \/

*/
#include <stdio.h>

void encrypt(int key);

int main(void)
{
        int key;
        int decrypt;
        printf("\n\n\n=========================================\nCRYPTOGRAPH \n\t CHIPER ENCRYPT AND DECRYPT TEXT\n=========================================");
        printf("\n\n\nmasukan keynya: ");
        scanf("%d", &key);
        printf("\n==========\n1.ecrypt\n2.decrypt\n==========\n\nsilakan pilih: ");
        scanf("%d", &decrypt);
        while(getchar() != '\n');
        if (decrypt == 1)
                encrypt(key);
        else
        {
                key = -1 * key;
                encrypt(key);
        }
        return 0;
}

void encrypt(int key)
{
        char ch;
        printf("\nmasukan plain text mu: ");
        ch = getchar();
        while(ch != '\n')
        {
                if (ch == ' ')
                        putchar(ch);
                else
                {
                        if(key == 0)
                                putchar(ch + key);
                        else
                                putchar(ch - key);
                }
                ch = getchar();
        }
        putchar(ch);
        printf("\n\n");
}
