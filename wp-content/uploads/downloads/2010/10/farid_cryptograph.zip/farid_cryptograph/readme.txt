/* cryptograph
/* project GXRG 
cara compile

$ gcc crypto.c -o crypto

running this program

$ ./crypto


tabel encrypted with key 0 s/d 10, etc.key di gunakan sebagai kunci kita perlu menggunakan key yg sama untuk mendecryptnya
==========================================|=========================================|=========================================|
key=0                                     |key = 1                                  |key = 2                                  |
==========================================|=========================================|=========================================|
| plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz |
| encrypted  = abcdefghijklmnopqrstuvwxyz | encrypted  = `abcdefghijklmnopqrstuvwxy | encrypted  = _`abcdefghijklmnopqrstuvwx |
| decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz |
==========================================|=========================================|=========================================|

==========================================|=========================================|=========================================|
key=3                                     |key = 4                                  |key = 5                                  |
==========================================|=========================================|=========================================|
| plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz |
| encrypted  = ^_`abcdefghijklmnopqrstuvw | encrypted  = ]^_`abcdefghijklmnopqrstuv | encrypted  = \]^_`abcdefghijklmnopqrstu |
| decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz |
==========================================|=========================================|=========================================|

==========================================|=========================================|=========================================|
key=6                                     |key = 7                                  |key = 8                                  |
==========================================|=========================================|=========================================|
| plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz |
| encrypted  = [\]^_`abcdefghijklmnopqrst | encrypted  = Z[\]^_`abcdefghijklmnopqrs | encrypted  = YZ[\]^_`abcdefghijklmnopqr |
| decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz |
==========================================|=========================================|=========================================|

==========================================|=========================================|
|key=9                                    | key = 10                                |
|=========================================|=========================================|
| plain text = abcdefghijklmnopqrstuvwxyz | plain text = abcdefghijklmnopqrstuvwxyz |
| encrypted  = XYZ[\]^_`abcdefghijklmnopq | encrypted  = WXYZ[\]^_`abcdefghijklmnop |
| decryped   = abcdefghijklmnopqrstuvwxyz | decryped   = abcdefghijklmnopqrstuvwxyz |
==========================================|=========================================|

MAKA PADA KEY KE 32 HASIL ENCRYPT AKAN KEMBALI KE PADA 
alfabet awal namun perbedaan karakter yang terjadi
alfabet akan menjadi upcase atau huruf besar semua dan seterusnya

|==========================================|
|key=32                                    |
|==========================================|
| plain text = abcdefghijklmnopqrstuvwxyz  |
| encrypted  = ABCDEFGHIJKLMNOPQRSTUVWXYZ  |
|==========================================|

