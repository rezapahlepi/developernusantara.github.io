#!/usr/bin/perl
use MIME::Base64;

system("clear");
print "\n\n ,adPPYb,d8  8b,     ,d8  8b,dPPYba,   ,adPPYb,d8 \n";  
print "a8     `Y88   `Y8, ,8P'   88P'    Y8  a8     `Y88  \n";
print "8b       88     )888(     88          8b       88  \n";
print "8a,   ,d88    ,d8  8b,    88           8a,   ,d88  \n";
print " `YbbdP Y8  8P'     `Y8   88           `YbbdP Y8  \n";
print " aa,    ,88                            aa,    ,88  \n";
print "  Y8bbdP                                Y8bbdP \n\n\n";
print " ROT 13  &  Base64 \n Encoder &  Decoder       email: im_stupid\@ymail.com	\n\n";
print " 0 for ROT13	& 	1 for base64\n";
print "which one do you want to use? [0/1] : ";
$q = <>;
if ($q == 0) {
	goto ROT13;
} else {
	goto BASE64;
}

BASE64:
print "encoder or decoder? [0/1] : ";
$q2 = <>;
if ($q2 == 0) {
	goto ENCODER;
} else {
	goto DECODER;
} 
ENCODER:
print "\ntype plain text : ";
$binput = <>;
$boutput = encode_base64($binput);
print "\nencrypted       : $boutput\n";
die "\nDone.. :)\n";

DECODER:
print "\ntype base64  : ";
$b64input = <>;
$b64output = decode_base64($b64input);
print "\ndecoded      : $b64output\n";
die "\nDone.. :)\n";
ROT13:
print "\nplain text : ";
$encode = <>;
$encode =~ tr/a-mn-zN-ZA-M/n-za-mA-MN-Z/;
print "\nencrypted  : $encode\n";

#EOF
