#!/usr/bin/python
#
###############################################################
# sniffing v.0.1                     (c) copyleft 11/2010     #
# Author: madexpert19                                         #
# Site: http://expert19.wordpress.com                  	      #
# Email:  madexpert19[at] gmail.com               	      #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups 	      #
###############################################################
#Thanks to all GXRG crew, GXRG Linux team.
#
#DESC:
#This tool to perform sniffing network packet

import sys
import logging 

logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

try:
	from scapy.all import *
except ImportError:
	print '[!] Please install scapy module first.'
	sys.exit(1)

		
def MAIN ():
	try:
		conf.verb=0 #dont display packet send 
		#iface
		interface = sys.argv[1]
		
		#ip sniff
		ip_sniff = sys.argv[2] 
	
		#ip target
		ip_target = sys.argv[3]  
 		#protocol
		proto = ["80","1080","443","139","445","53","110","21","20"]
		while True: 
		
			#Construct IP and packets data
			ip = IP(src=ip_sniff, dst=ip_target/TCP(dport=[proto],flags="SA"))
			#sniffing packets
			s = sniff(iface=interface, prn=lambda x:x.sprintf("%IP.src%:%TCP.sport% -> %IP.dst%:%TCP.dport% %IP.proto% %IP.id% %2s,TCP.flags% :"))
			# display all of packets after sniffing
			s.conversations()
			print s.summary()
			#capture packet
			wrpcap("temp.cap",s)
			rdpcap("temp.cap")
			uid = 0
			guid = 0
	except KeyboardInterrupt:
		sys.exit()
if len(sys.argv) == 4:
	MAIN ()		
else:	
	print 'Usage : ' + sys.argv[0] + '[iface][ip_sniff][ip_target]'
	print 'Ex: ./sniffing wlan0 192.168.56.1 192.168.56.101'
	print 'Please visit <http://projects.gxrg.org,http://expert19.wordpress.com>'
	print 'Send comments to madexpert19 <madexpert19@gmail.com>'

	