<?

function html($post) {

	$header = 	"
				<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
				<html>
				<head>
				<title>Foursquare Auto Checkins | ray16</title>
				<link href=\"style.css\" rel=\"stylesheet\" type=\"text/css\">
				</head>			
				<body>
				";
				
	$login 	=	"
				<form action='".$_SERVER['PHP_SELF']."' method='post'>
				<div><input type='hidden' name='array' value='0'/>
				<table border='0'>
				  <tr>
				  <td>Optional:</td>
				  <td><input type='checkbox' name='private' value='1' /> Off The Grid 
				  <input type='checkbox' name='twitter' value='1' /> Twitter
				  <input type='checkbox' name='facebook' value='1' /> Facebook
 				  </td>
				  </tr>
				  <tr>
				  <td height='10'>
				  </td>
				  <td height='10'>
				  </td>
				  </tr>
				  <tr>
				  <td>Email/phone:</td>
				  <td><input name='username' type='text' /></td>
				  </tr>
				  <tr>
				  <td height='10'>
				  </td>
				  <td height='10'>
				  </td>
				  </tr>
				  <tr>
				  <td>Password:</td>
				  <td><input name='password' type='password' size='10' /></td>
				  </tr>
				  <tr>
				  <td height='10'>
				  </td>
				  <td height='10'>
				  </td>
				  </tr>
				  <tr>
				  <td>Timer/Venue:</td>
				  <td><input name='timer' type='text' size='2' /> Minutes</td>
				  </tr>
				  <tr>
				  <td height='10'>
				  </td>
				  <td height='10'>
				  </td>
				  </tr>
				  <tr>
				  <td>Venue ID List:</td>
				  <td><input name='venue' type='text' size='35' /></td>
				  </tr>
				  <tr>
				  <td>
				  </td>
				  <td>*use (,) as separator.<br />
				  ex: 89018,7389,937201,01901 ..</td>
				  </tr>
				  <tr>
				  <td height='15'>
				  </td>
				  <td height='15'>
				  </td>
				  </tr>
				  <tr>
					<td></td>
					<td><input value='Go Check-In!' type='submit' /></td>
				  </tr>
				</table>
			  </form>	
				";

	
	$footer	=	"
				<hr />
				(c) 2010 - [G]unadarma [X]malang [R]esearch [G]roups
				</body>
				</html>
				";
				
	
	$response['Header'] = $header;
	$response['Login']	= $login;
	$response['Footer']	= $footer;
	
	return $response;
}


	function FourSquareCheckins($post, $Config) {
	
	define('ABSPATH', dirname(__FILE__).'/');
	
	$C				= $post['array'];
	$V				= $post['venue'];
	$pId 			= $C+1;
	$VenueId		= explode(",", $V);
	$VenueIdNow		= $VenueId[$C];
	$VenueIdNext	= $VenueId[$pId]; 

	$TourOverStatus = 	"
						<p>VID Selanjutnya NULL, Exitting ..</p>
						<p>Click <a href='".$_SERVER['PHP_SELF']."' />Here</a> To Back Home ..</p>
						";
	
	$TourOver['end'] = $TourOverStatus;
	
	// TOUR OVER
	if($VenueIdNow == null) {
	
	return $TourOver;	
	
	}
	
	// CHECKINS DATA
	$PostCheckins	= array (
						vid			=> $VenueIdNow,
						twitter		=> $post['twitter'],
						facebook	=> $post['facebook'],
						"private"	=> $post['private'],
						shout		=> null
						);


	// POST CHECKINS
	$curlOptionsPost = array(
		CURLOPT_FAILONERROR 	=> 	true,
		CURLOPT_AUTOREFERER 	=> 	true,
		CURLOPT_RETURNTRANSFER 	=> 	true,
		CURLOPT_POST			=> 	true,
		CURLOPT_TIMEOUT 		=> 	60,
		CURLOPT_POSTFIELDS		=>	$PostCheckins,
		CURLOPT_URL				=> 	'https://api.foursquare.com/v1/checkin.xml',
		CURLOPT_USERAGENT 		=> 	$Config['userAgent'],
		CURLOPT_USERPWD			=>	$post['username'].':'.$post['password']
	);
	
	// GET VENUE DETAILS FOR NEXT CHECKINS
	$curlOptionsGet = array(
		CURLOPT_AUTOREFERER 	=> 	true,
		CURLOPT_RETURNTRANSFER 	=> 	true,
		CURLOPT_TIMEOUT 		=> 	60,
		CURLOPT_HEADER			=>	0,
		CURLOPT_CUSTOMREQUEST	=>	'GET',
		CURLOPT_URL				=> 	'https://api.foursquare.com/v1/venue.xml?vid='.$VenueIdNext,
		CURLOPT_USERAGENT 		=> 	$Config['userAgent']
	);
	
	// GET USER DETAIL
	$curlOptionsUser = array(
		CURLOPT_AUTOREFERER 	=> 	true,
		CURLOPT_RETURNTRANSFER 	=> 	true,
		CURLOPT_TIMEOUT 		=> 	60,
		CURLOPT_HEADER			=>	0,
		CURLOPT_CUSTOMREQUEST	=>	'GET',
		CURLOPT_URL				=> 	'https://api.foursquare.com/v1/user.xml',
		CURLOPT_USERAGENT 		=> 	$Config['userAgent'],
		CURLOPT_USERPWD			=>	$post['username'].':'.$post['password']
	);
	
	// CURL EXECUTE
	$ch1 			= curl_init();
	$ch2			= curl_init();
	$ch3			= curl_init();

	curl_setopt_array($ch1, $curlOptionsGet);
	curl_setopt_array($ch2, $curlOptionsPost);
	curl_setopt_array($ch3, $curlOptionsUser);
	
	$mh = curl_multi_init();
	
	curl_multi_add_handle($mh,$ch1);
	curl_multi_add_handle($mh,$ch2);
	curl_multi_add_handle($mh,$ch3);

	$active = null;
	//execute the handles
	do {
		$mrc = curl_multi_exec($mh, $active);
	} while ($mrc == CURLM_CALL_MULTI_PERFORM);

	while ($active && $mrc == CURLM_OK) {
		if (curl_multi_select($mh) != -1) {
			do {
				$mrc = curl_multi_exec($mh, $active);
			} while ($mrc == CURLM_CALL_MULTI_PERFORM);
		}
	}
	
	$postContents	= curl_multi_getcontent($ch1);
	$PostContents	= curl_multi_getcontent($ch2);
	$UserDetail		= curl_multi_getcontent($ch3);
	
	curl_multi_remove_handle($mh, $ch1);
	curl_multi_remove_handle($mh, $ch2);
	curl_multi_remove_handle($mh, $ch3);
	
	curl_multi_close($mh);
	
	// RETURN REPORTS
	$response['contents']	 = $PostContents;
	$response['getVenue']	 = $postContents;
	$response['VenueIdNext'] = $VenueId[$pId];
	$response['vId']		 = $pId;
	$response['UserDetail']	 = $UserDetail;
	
	return $response;
	
	}



?>