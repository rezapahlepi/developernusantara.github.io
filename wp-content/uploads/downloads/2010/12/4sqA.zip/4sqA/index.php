<?php

	$post = $_POST;
	$Config['userAgent'] 	= "G Square:1.0 Profile/MIDP-2.0 Configuration/CLDC-1.1 VendorID/105 Blackberry|Curve";
	
	// SET '0' IF NOT CHECKED
	if($post['twitter'] == null) $post['twitter'] = '0';
	if($post['facebook'] == null) $post['facebook'] = '0';
	if($post['private'] == null) $post['private'] = '0';

	require_once 'autoLib.php';

	$html 		= html($post); 

	if (!isset($post['array']) || !isset($post['username']) || !isset($post['password']) || !isset($post['timer']) || !isset($post['venue'])) {
	
	echo $html['Header'];
	echo "
			<img src='header_mobile.png' />
			<br />
			<b><a href='".$_SERVER['PHP_SELF']."' />Auto Checkins</a></b>
			<hr />
		";
	echo $html['Login'];
	echo $html['Footer'];
	exit();
	
	}

	elseif (isset($post['array']) && isset($post['username']) && isset($post['password']) && isset($post['timer']) && isset($post['venue'])) {

	$sq			= FourSquareCheckins($post, $Config);
	
	// CONVERT OUTPUT AS XML TO STRING
	$User		= simplexml_load_string($sq['UserDetail']);
	$contents 	= simplexml_load_string($sq['contents']);
	$NextVenue 	= simplexml_load_string($sq['getVenue']);
	
	if( ($User->checkin->venue->city == null) || ($User->checkin->venue->state == null) ) {
	
	$User->checkin->venue->city = 'NaN';
	$User->checkin->venue->state = 'NaN'; 
	
	}

	// VENUE ID NULL
	if (isset($sq['end'])) {
	
	echo $html['Header'];
	print 	"
			<table>
			<tr>
			<td>
			<img src='header_mobile.png' />
			</td>
			<td>
			</td>
			</tr>
			</table>
			<br />
			<b><a href='".$_SERVER['PHP_SELF']."' />Auto Checkins</a></b>
			<hr />";
	echo $sq['end'];
	echo $html['Footer'];
	
	exit();
	
	}
	
	//  CANNOT FETCH CONTENT
	if ($contents->message == null) {
	
	echo $html['Header'];
	print 	"
			<table>
			<tr>
			<td>
			<img src='header_mobile.png' />
			</td>
			<td>
			</td>
			</tr>
			</table>
			<br />
			<b><a href='".$_SERVER['PHP_SELF']."' />Auto Checkins</a></b>
			<hr />";
	echo 	"
			<p>UserName atau Password Salah, Exitting ..</p>
			<p>Click <a href='".$_SERVER['PHP_SELF']."' />Here</a> To Back Home ..</p>
			";
	echo $html['Footer'];
	
	exit();	
	
	
	}
	
	echo $html['Header'];
	
	// SHOW TIMER, NEXT CHECKINS
	if(!$sq['VenueIdNext'] == null) {

	
	echo	"
			<script type='text/javascript'>
			
			var mins
			var secs;

			function cd() {
				mins = 1 * m('".$post['timer']."'); 
				secs = 0 + s(':01'); 
				redo();
			}

			function m(obj) {
				for(var i = 0; i < obj.length; i++) {
					if(obj.substring(i, i + 1) == ':')
					break;
				}
				return(obj.substring(0, i));
			}

			function s(obj) {
				for(var i = 0; i < obj.length; i++) {
					if(obj.substring(i, i + 1) == ':')
					break;
				}
				return(obj.substring(i + 1, obj.length));
			}

			function dis(mins,secs) {
				var disp;
				if(mins <= 9) {
					disp = ' 0';
				} else {
					disp = ' ';
				}
				disp += mins + ':';
				if(secs <= 9) {
					disp += '0' + secs;
				} else {
					disp += secs;
				}
				return(disp);
			}
			
			function redo() {
				secs--;
				if(secs == -1) {
					secs = 59;
					mins--;
				}
				document.cd.disp.value = dis(mins,secs);
				if((mins == 0) && (secs == 0)) {
					document.getElementById('sn0w').submit();
				} else {
					cd = setTimeout('redo()',1000);
				}
			}

			function init() {
			  cd();
			}
			window.onload = init;
			
			</script>
	
			";	
	
	print 	"
			<table>
			<tr>
			<td>
			<img src='header_mobile.png' />
			</td>
			<td>
			<form name = 'cd'>
			<input id='txt' readonly='true' type='text' value='".$post['timer'].":01' border='0' name='disp'>
			</form>
			</td>
			</tr>
			</table>
			<br />
			<b><a href='".$_SERVER['PHP_SELF']."' />Auto Checkins</a></b> (".$User->firstname." in "
			.$User->checkin->venue->city.", ".$User->checkin->venue->state.")
			<hr />
			<b>Next Checkins -> <a href='javascript:document.getElementById(\"sn0w\").submit();' /><font color='#00CC00' />"
			.$NextVenue->name."</a></font>  (".$NextVenue->city.", ".$NextVenue->state.")</b>";
	}
	
	// FINISHED
	else {
	
	print	"<img src='header_mobile.png' />
			<br />
			<b><a href='".$_SERVER['PHP_SELF']."' />Auto Checkins</a></b> (".$User->firstname." in "
			.$User->checkin->venue->city.", ".$User->checkin->venue->state.")
			<hr />			
			<b>Next Checkins -> <font color='#FF0000' />Finished!</font> Click <a href='"
			.$_SERVER['PHP_SELF']."' />Here</a> To Back Home ..</a></b>";
	
	}
	
	// MESSAGE
	print	"
			<br />
			<br />
			<div>
			<b>[".$contents->venue->id."] ".$contents->venue->name."<br />
			".$contents->message."</b>
			</div>
			<br />
			";
			
	// SCORING IF TRUE
	if (isset($contents->scoring)) {
	
	print		 "<b>Your check-in score:</b>
			     <br />
		         <table>";

	foreach ($contents->scoring as $ScoreDetails)  {
				 
	if (isset($contents->scoring->score[1])) {
	
		$TotalScore = $ScoreDetails->score[0]->points+$ScoreDetails->score[1]->points;
	
		print		"<tr>
					<td><img width='20' height='20' src='".$ScoreDetails->score[0]->icon."' alt='icon' /></td>
					<td>".$ScoreDetails->score[0]->message." (+".$ScoreDetails->score[0]->points.")</td>
					</tr>
					<tr>
					<td><img width='20' height='20' src='".$ScoreDetails->score[1]->icon."' alt='icon' /></td>
					<td>".$ScoreDetails->score[1]->message." (+".$ScoreDetails->score[1]->points.")</td>
					</tr>
					<tr> 
					<td></td>
					<td><b>Total: ".$TotalScore." pts</b></td>
					</tr>
					</table><br />";
				
	}
		else {
	
			print		 "<tr>
						<td><img width='20' height='20' src='".$ScoreDetails->score[0]->icon."' alt='icon' /></td>
						<td>".$ScoreDetails->score[0]->message." (+".$ScoreDetails->score[0]->points.")</td>
						</tr>
						<tr> 
						<td></td>
						<td><b>Total: ".$ScoreDetails->score[0]->points." pts</b></td>
						</tr>
						</table><br />";
		}
		
	}		

	
	}
	

	// OUTPUT MAYOR
	if(isset($contents->mayor)) {
	print	"<table class='result_block'>
			<tr>
			<td>
			<img width='30' height='30' 
			src='".$contents->mayor->user->photo."' 
			alt='".$contents->mayor->user->firstname."' />
			</td>
			<td>".$contents->mayor->message."</td>
			</tr>
			</table>
			<br />";
	}
				

	// BADGES	
	if(isset($contents->badges)) {
	
	$count = count($contents->badges->badge);
	
		if($count > 1) {

			for($i=0; $i<$count; $i++) {
				print	 "
						<br />
						<table class='result_block'>
						<tr>
						<td>
						<img width='30' height='30'  
						src='".$contents->badges->badge[$i]->icon."' 
						alt='".$contents->badges->badge[$i]->name."' />
						</td>
						<td>".$contents->badges->badge[$i]->description."</td>
						</tr>
						</table>
						<br />
						";
				}
		}
		
		else {
		
				print	 "
						<br />
						<table class='result_block'>
						<tr>
						<td>
						<img width='30' height='30'  
						src='".$contents->badges->badge->icon."' 
						alt='".$contents->badges->badge->name."' />
						</td>
						<td>".$contents->badges->badge->description."</td>
						</tr>
						</table>
						<br />
						";		
		
		}
	
	}
	
	// SUBMIT I <3 SNOW :)
	print	"
	
	<form id='sn0w' name='sn0w' method='post' action='".$_SERVER['PHP_SELF']."' />
	
	<input type='hidden' name='username' 	value='".$post['username']."' />
	<input type='hidden' name='password' 	value='".$post['password']."' />
	<input type='hidden' name='twitter' 	value='".$post['twitter']."' />
	<input type='hidden' name='facebook' 	value='".$post['facebook']."' />
	<input type='hidden' name='private' 	value='".$post['private']."' />
	<input type='hidden' name='timer' 		value='".$post['timer']."' />
	<input type='hidden' name='array'	 	value='".$sq['vId']."' />
	<input type='hidden' name='venue'	 	value='".$post['venue']."' />
	
	</form>
	
			";
			
	print "<b>Show Checkins On : ";
	if($post['private'] == '0') print "<font color='#C0C0C0' />Off The Grid</font>"; else print "<font color='#0000FF' />Off The Grid</font>";
	print " | ";
	if($post['twitter'] == '0') print "<font color='#C0C0C0' />Twitter</font>"; else print "<font color='#0000FF' />Twitter</font>";
	print " | ";
	if($post['facebook'] == '0') print "<font color='#C0C0C0' />Facebook</font>"; else print "<font color='#0000FF' />Facebook</font>";	
	print "</b><br />";
	
	echo $html['Footer'];

		
	}

?>