#!/bin/bash
#------------------------------------------------------------------------------------
#scan-ip.sh v.1.0
#written by aBi71 juli-2010
#l0g[dot]bima[at]gmail[dot]com
#http://abi71.wordpress.com, http://projects.gxrg.org
#credits: [G]gunadarma[X]xmalang[R]research[G]group 
#license: GPL (Gnu public license)
#scan-ip is a simple bash script for network scanner, only used for class C networks.
#with this script you can find a live host in the network.
#------------------------------------------------------------------------------------
#--------- set color ---------
white='\033[1;37m'
red='\033[0;31;1;31m'
yellow='\033[1;33m'
green='\033[0;32;1;32m'
blue='\033[1;34m'
default='\033[0m'
#--------- function help ---------
function display_help (){
echo -e "${white}Usage: $0 <options> [ip_start] [ip_end] <interface>
Options: 
   -h    Display usage information
   -m    Include MAC address

option -m (include MAC address), only used for super users (eg. root) !!!

Please visit <http://projects.gxrg.org, http://abi71.wordpress.com>
Report bugs to <l0g.bima@gmail.com>${default}"
exit 0
}
#---------- console usage  ----------
if [ $# -lt 1 ]; then
display_help
else
case $1 in
         -h)
            echo -e "${white}Example: $0 125.160.119.30 125.160.119.71 
         $0 -m 192.168.1.20 192.168.1.55 wlan0${default}"
            exit 0
            ;;
         -m)       
            include_mac=yes    
             case $2 in
                 *.*.*.*) 
                         ip_start=$2
                          case $3 in
                              *.*.*.*)
                                      ip_end=$3
                                          case $4 in
                                                 *)
                                                   iface=$4
                                                 ;;
                                          esac
                                      ;;
                                *.*.*)
                                      display_help 
                                      ;;
                                  *.*)
                                      display_help
                             	      ;;
                            	    *) 
                                      display_help
                             	      ;;
                  	   esac
               	         ;;
                   *.*.*)
                         display_help
                         ;;
                     *.*)
                         display_help
                         ;;
                       *) 
                         display_help
                         ;;         
            esac
            ;;
    *.*.*.*)
            ip_start=$1
             case $2 in
                 *.*.*.*)
                         ip_end=$2
                         ;;
                   *.*.*)
                         display_help
                         ;;
                     *.*)
                         display_help
                         ;;
                       *) 
                         display_help
                         ;;
             esac
               ;;
      *.*.*)
            display_help
            ;;
        *.*)
            display_help
            ;;
          *) 
            display_help
            ;;         
esac
fi
#---------- set variable ---------- 
who_use=`whoami`
ip_host1=$(echo $ip_start | sed 's/\./ /g' | awk '{print $4}')
ip_host2=$(echo $ip_end | sed 's/\./ /g' | awk '{print $4}')
ip_class_c1=$(echo $ip_start | sed 's/\./ /g' | awk '{print $1,$2,$3}')
ip_class_c2=$(echo $ip_end | sed 's/\./ /g' | awk '{print $1,$2,$3}')
scan_start=$(date +%H\:%M\:%S)
#---------- check ----------
if [ "$ip_class_c1" = "$ip_class_c2" ] && [ "$ip_host1" -le "$ip_host2" ]; then 
     ip_class_c=$(echo $ip_start | sed 's/\./ /g' | awk '{print $1,$2,$3}')
     gateway=$(netstat -nr | grep "$iface" | grep "UG" | awk '{print $2}' | sed 's/\./ /g' | awk '{print $1"."$2"."$3}')
     echo $gateway > /tmp/.our_ip
     touch /tmp/.ip_list.sh
     echo "#!/bin/bash" > /tmp/.ip_list.sh
else
     display_help
fi
#----------scan process ----------
echo -n -e "${blue}[+]${default} ${white}scanning${default}"
while [ "$ip_host1" -le "$ip_host2" ]; do
  echo -n -e "${white}.${default}"
  join_ip_class_host=$(echo $ip_class_c $ip_host1 | sed 's/\ /./g')
  if [ "$include_mac" != "yes" ]; then
     ip_ping=$(ping -q -w 1 $join_ip_class_host | grep "avg" | sed 's/\// /g' | sed 's/\./ /g'  | awk '{print $8}' &)
        if [ "$ip_ping" != "" ]; then              
           echo "echo -e '${white}$join_ip_class_host ${default} ${green}alive${default}'" >> /tmp/.ip_list.sh
	   let count_iplive++ 
             else 
           echo "echo -e '${white}$join_ip_class_host${default} ${red} timeout${default}'" >> /tmp/.ip_list.sh
	   let count_ipdead++
        fi
      else if [ "$who_use" = "root" ]; then
                 if [ "$iface" = "" ] || [ "$gateway" = "" ]; then
                    echo -e "\n${red}[!]${default} ${white}Inactive network cards, Please try again and make sure you have an interface with the correct insert.${default}\n"
                    $0 -h
                    exit 0
                 fi
             our_ip=$(ifconfig -a | grep -f /tmp/.our_ip | sed 's/\:/ /g' | awk '{print $3}')
             arp_ping=$(arping -f -c 1 -I $iface -s $our_ip $join_ip_class_host | grep "reply" | awk '{print $4" at "$5}' &)
                 if [ "$arp_ping" != "" ]; then              
                    echo "echo -e '${white}$arp_ping ${default}${green}alive${default}'" >> /tmp/.ip_list.sh
	            let count_iplive++ 
                  else 
                    echo "echo -e '${white}$join_ip_class_host at [00:00:00:00:00:00]${default}${red} timeout${default}'" >> /tmp/.ip_list.sh
	            let count_ipdead++
                 fi
      else
         echo -n -e "\n${red}[!]${default} ${white}Sorry you can't used this options, so running it may require superuser privileges (eg. root).${default}\n"
         exit 0
      fi 
  fi
  let process++
  let ip_host1++
done
#---------- scanned list ----------
scan_end=$(date +%H\:%M\:%S)
echo -e "\n${green}                              _       
    ___  ___ __ _ _ __       (_)_ __  
   / __|/ __/ _' | '_ \ _____| | '_ \ 
   \__ \ (_| (_| | | | |_____| | |_) |
   |___/\___\__,_|_| |_|     |_| .__/ 
    ${yellow}version 1.0${default}                ${green}|_|${default}    
${default}"
echo -e "${green}--${default} ${yellow}scan-ip.sh v.1.0${default} ${green}--------------------------${default}"
echo -e "${yellow}IP range:${default} ${white}$ip_start${default} ${yellow}to${default} ${white}$ip_end${default}"
echo -e "${yellow}Started:${default} ${white}$scan_start${default}"
echo -e "${yellow}Ended:${default} ${white}$scan_end${default}"
echo -e "${yellow}IP live:${default} ${white}$count_iplive${default}"
echo -e "${yellow}IP dead:${default} ${white}$count_ipdead${default}"
echo -e "${yellow}Total scan:${default} ${white}`expr $count_iplive + $count_ipdead`${default}"
echo -e "${yellow}Scanned on host:${default} 
`bash /tmp/.ip_list.sh`"
echo -e "${yellow}Speed scanned:${default} ${white}`echo $(echo $scan_end | sed 's/\:/ /g' | sed 's/ //g')-$(echo $scan_start | sed 's/\:/ /g' | sed 's/ //g') | bc` second${default}"
echo -e "${green}----------------------------------------------${default}"
echo -e "                          ${yellow}(c) July 2010 - GXRG ${default}"
#--------- clear created file ---------
rm /tmp/.ip_list.sh && rm /tmp/.our_ip
exit 0
