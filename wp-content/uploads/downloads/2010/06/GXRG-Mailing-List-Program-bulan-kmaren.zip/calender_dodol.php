<html>
<head>
<title>
Calender
</title>
<style ="text/css">
body{
background-image:url(1.jpg);
background-repeat:no-repeat;
background-attachment:fixed;
background-position:center;
}
option{
font-size:12pt;
}
td{
font-size:12pt;
font-weight:bold;
}
td.dua{
font-family:sanserif;
font-size:12pt;
font-weight:bold;
color:#036505;
}
</style>

<script type="text/javascript">
var namaBulanI = new Array( "January","February","March","April","May","June",
"July","August","September","October","November","December" );
var namaHariI = new Array( "Thursday","Friday","Saturday","Sunday","Monday","Tuesday","Wednesday" );

function showDate() {
now = new Date();

iTanggalM = now.getDate();
iBulanM = now.getMonth();
iTahunM = now.getYear();
if(iTahunM<1900) { iTahunM += 1900; } // Y2K

iJam=now.getHours();
iMenit=now.getMinutes();
iDetik=now.getSeconds();

hr = Date.UTC(iTahunM,iBulanM,iTanggalM,0,0,0)/1000/60/60/24;

sDate = namaHariI[hr%7]+", "+iTanggalM+" "+namaBulanI[iBulanM]+" "+iTahunM+"<br>";
sDate += (iJam<10?"0"+iJam:iJam)+":"+
(iMenit<10?"0"+iMenit:iMenit)+":"+
(iDetik<10?"0"+iDetik:iDetik);

if(document.all)
{ document.all.clock.innerHTML=sDate; }
else if(document.getElementById)
{ document.getElementById( "clock" ).innerHTML=sDate; }
else { document.write(sDate); }
}

function showIt() {
showDate();
if(document.all||document.getElementById)
{ setInterval("showDate()",1000); }
}
</script>

</head>
<body>
<br>
<form method='POST' action='calender_dodol.php'>
<table>
<tr>
<td width=100>Month</td>
<td>
<select name="month">
<option>January</option>
<option>February</option>
<option>March</option>
<option>April</option>
<option>May</option>
<option>June</option>
<option>July</option>
<option>August</option>
<option>September</option>
<option>October</option>
<option>November</option>
<option>December</option>
</select>
</td>
</tr>
<tr>
<td>Year</td>
<td>
<select name="year">
<option>2007</option>
<option>2008</option>
<option>2009</option>
<option>2010</option>
<option>2011</option>
<option>2012</option>
<option>2013</option>
<option>2014</option>
<option>2015</option>
<option>2016</option>
<option>2017</option>
<option>2018</option>
<option>2019</option>
<option>2020</option>
<option>2021</option>
<option>2022</option>
</select>
</td>
</tr>
<tr>
<td></td>
<td>
<input type="submit" name="submit" value="Submit">
</td></tr>
</table>
</form>
</body>
</html>

<?php

$c = $_POST['month'];
$b = $_POST['year'];

$x = array ("January","February","March","April","May","June","July","August","September","October","November","December");
$y = array ("01","02","03","04","05","06","07","08","09","10","11","12");
for($ab = 0; $ab < 12; $ab++){
if($c == $x[$ab]){
$a = $y[$ab];
}
}

 
$date = 01;
$asd = 01;
$day = 01; 
$off = 00; 
$month = date("m");
$year = date("Y");

if($_POST['submit']){
$month = $a;
$year = $b;
}

for($ab = 0; $ab < 12; $ab++){
if($month == $y[$ab]){
$p = $x[$ab];
}
}

while (checkdate($month,$date,$year)): 
$date++; 
endwhile; 
echo "<center><table cellpadding='5' cellspacing='5' border=0><tr>";
echo "<th  colspan=7><h1>$p $year</h1></th></tr>";

echo "<tr><th width=90><b><font face='Verdana','Arial' color='#FF0300'>Sunday</font></b></th>"; 
echo "<th width=90><b><font face='Verdana','Arial'>Monday</font></b></th>"; 
echo "<th width=90><b><font face='Verdana','Arial'>Tuesday</font></b></th>"; 
echo "<th width=90><b><font face='Verdana','Arial'>Wednesday</font></b></th>"; 
echo "<th width=90><b><font face='Verdana','Arial'>Thursday</font></b></th>"; 
echo "<th width=90><b><font face='Verdana','Arial'>Friday</font></b></th>"; 
echo "<th width=90><b><font face='Verdana','Arial' color='#0300FF'>Saturday</font></b></th>";

echo "<tr align='right'>";

while ($day<$date): 



if ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Sunday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td><blink><font size='6' color='FF0300'>$day</font></blink></td>"; 
}
else{
echo "<td><font color='FF0300'>$day</font></td>"; 
}   
$off = '01'; 
}
elseif ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Monday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td></td><td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td></td><td>$day</td>"; 
}  
$off= '02'; 
} 
elseif ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Tuesday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td></td><td></td><td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td></td><td></td><td>$day</td>"; 
} 
$off= '03'; 
} 
elseif ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Wednesday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td></td><td></td><td></td><td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td></td><td></td><td></td><td>$day</td>"; 
} 
$off= '04'; 
} 
elseif ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Thursday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td></td><td></td><td></td><td></td><td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td></td><td></td><td></td><td></td><td>$day</td>"; 
} 
$off= '05'; 
} 
elseif ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Friday') {
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td></td><td></td><td></td><td></td><td></td><td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td></td><td></td><td></td><td></td><td></td><td>$day</td>"; 
}
$off= '06'; 
} 
elseif ($day == '01' && date('l', mktime(0,0,0,$month,$day,$year)) == 'Saturday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td></td><td></td><td></td><td></td><td></td><td></td><td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td></td><td></td><td></td><td></td><td></td><td></td><td>$day</td>"; 
} 
$off= '07'; 
} 
elseif ($day == $asd && date('l', mktime(0,0,0,$month,$day,$year)) == 'Sunday') { 
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td><blink><font size='6' color='FF0300'>$day</font></blink></td>"; 
}
else{
echo "<td><font color='FF0300'>$day</font></td>"; 
}
}
else{
if($day == date("j") && $month == date("m") && $year == date("Y")){
echo "<td><blink><font size='6'>$day</font></blink></td>"; 
}
else{
echo "<td>$day</td>"; 
} 
}  

$day++; 
$off++;
$asd++; 

if ($off>7) { 
echo "</tr><tr align='right'>"; 
$off ='01'; 
}
else { 
echo ""; 
}

endwhile;

echo "</table></center>";
?>

<?php
echo "<br><br>";
echo "<table border=0 align='center' cellpadding=10><tr><td class='dua' width=525 align='right'><font size=28>NOW</font></td>";
echo "<td class='dua' align='right'><span id='clock'><script>showIt();</script></span></td></tr></table>";
?>
