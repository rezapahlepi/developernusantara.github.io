<b>Topik Bantuan</b>
<br /><br />
<b>Cek Pesan Masuk dan Pesan Terkirim</b><br />
Kamu bisa cek pesan masuk dan terkirim dari Link Personal Box dibawah.<br />
Masukkan 7 Angka akhir dari nomor telp yang ingin di cek message nya.<br />
<br />
<b>1. No Tujuan</b><br />
Minimal 10 Angka, dan dimulai dengan angka 0.
<i>ex:</i> 0856897xxxx atau 0219567xxx.<br /><br />
<b>2. Isi Pesan</b><br />
Maximal 160 Karakter (untuk 1 SMS), bebas, symbol etc, dan diperbolehkan Enter. <br />
Jumlah karakter Pesan akan otomatis di potong maximal 160.<br /><br />
<b>3. Jumlah Pesan</b> -- Sementara hanya untuk Donatur<br />
Maximal 2 per kirim, jika ingin lebih (bebas jumlah pesan berapa saja) silahkan Donasi.
<br /><br />
<b>4. Donasi</b><br />
Paling tidak kami membutuhkan Donasi, berupa:<br />
1. pulsa AXIS.<br />
2. server dan kelengkapan server (modem, etc) kami akan melakukan setup dan maintenance secara free<br />
untuk itu silahkan kirim Direct Messages ke twitter <a href='http://twitter.com/rey_jerk'>@rey_jerk</a>.
<br /><br />
<b>Daftar Donatur:</b>
<br />
1. isal - modem huawei.<br />
2. gxrg - server dan kartu perdana AXIS.
<br /><br />
<b>G X R G</b> - Gunadarma Xmalang Research Groups<br />
1. Coder - Murray (Special Thanks to Princess Snowdrop)<br />
2. Maintenance Server - Murray, Divi, Edwin<br />
3. Big Thanks to GXRG CREW, Isal, Dennis, Singgih, dan Uchiha Effendi
<br />
<br />
