#!/usr/bin/ruby

####################################################################
# static-ip.rb                                                     #
# Author : ChRistian                                               #
# Site   : http://cgilaa12.wordpress.com, http://projects.gxrg.org #
# Email  : christiangilaa [at] ymail.com                           #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups               #
####################################################################

class Pertama
def method1
puts    "\n------------- Manual -------------"
puts    "-> input device :"
dev   = gets.chomp
iface = "ifconfig #{dev} down | macchanger -r #{dev} | grep unknown | awk '{print $1,$2,$3}'"
puts `#{iface}`
puts    "\n-> input ip-addr :"
addr  = gets.chomp
ip    = "ifconfig #{dev} #{addr}/24 | ifconfig #{dev} | grep 'inet addr:'"
puts `#{ip}`
puts    "\n-> input ip-gateway :"
route = gets.chomp
gw    = "route add default gw #{route}"
puts `#{gw}`
puts    "-> input dns-nameserver :"
dns   = gets.chomp
nserv = "echo nameserver #{dns} > /etc/resolv.conf | cat /etc/resolv.conf"
puts `#{nserv}`
list  = "\niwlist #{dev} scan | grep ESSID | sed 's/\"/ /g'"
puts `#{list}`
puts    "\n-> input Channel/ESSID :"
chan  = gets.chomp
essid = "iwconfig #{dev} essid #{chan}"
puts `#{essid}`
ping  = "ping -c 3 #{route}"
puts `#{ping}`
arp   = "ip neigh | grep REACHABLE | awk '{print $1,$5}'"
stat  = "arp -s `#{arp}`"
puts `#{stat}`
ether = "arp -a"
puts `#{ether}`
puts "   Back to menu or exit program ?"
puts "-> 1 -exit\n   2 -back menu"
puts "---------------------------"
$ans   = gets.to_i
if $ans== 1
obj   = Pertama.new
obj.method3
end;
if $ans== 2
obj = Kedua.new
obj.method1
end;
end

def method2
puts    "\n------------ Automatic -----------"
puts    "-> input device :"
dev1  = gets.chomp
iface1= "ifconfig #{dev1} down | macchanger -r #{dev1} | grep unknown | awk '{print $1,$2,$3}'"
puts `#{iface1}`
upping= "ifconfig #{dev1} up"
puts `#{upping}`
list1 = "\niwlist #{dev1} scan | grep ESSID | sed 's/\"/ /g'"
puts `#{list1}`
puts    "\n-> input Channel/ESSID :"
chan1 = gets.chomp
essid1= "iwconfig #{dev1} essid #{chan1}"
puts `#{essid1}`
req   = "dhclient #{dev1}"
puts `#{req}`
arp1  = "ip route | grep default | awk '{print $3}'"
ping1 = "ping -c 3 `#{arp1}`"
puts `#{ping1}`
arp1  = "ip neigh | grep REACHABLE | awk '{print $1,$5}'"
stat1 = "arp -s `#{arp1}`"
puts `#{stat1}`
ether1= "arp -a"
puts `#{ether1}`
puts "   Back to menu or exit program ?"
puts "-> 1 -exit\n   2 -back menu"
puts "---------------------------"
$ans   = gets.to_i
if $ans== 1
obj   = Pertama.new
obj.method3
end;
if $ans== 2
obj = Kedua.new
obj.method1
end;
end

def method3
puts "Exit program"
Thread.exit
system "clear"
end
end

class Kedua
def method1
system "clear"
puts	"\n		[G]unadarma [X]malang [R]esearch [G]roups
                                    ruby script
                                 utility-network\n\n"

puts    "--------type of connection--------"
puts    '1. Manual'
puts    '2. Automatic'
puts    '3. Exit'
puts    "----------------------------------\n\n"
puts    "-> Select type :"
$a     = gets.to_i

if $a==1
obj = Pertama.new
obj.method1
end;
if $a==2
obj = Pertama.new
obj.method2
end;
if $a==3
obj = Pertama.new
obj.method3
end;
end
end
obj = Kedua.new
obj.method1
