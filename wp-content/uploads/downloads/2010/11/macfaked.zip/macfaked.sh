#!/bin/bash
#------------------------------------------------------------------------------------
#macfaked.sh v.0.1 
#written by aBi71 Sept-2010
#l0g[dot]bima[at]gmail[dot]com
#http://abi71.wordpress.com, http://projects.gxrg.org
#credits: [G]gunadarma [X]xmalang [R]research [G]groups
#license: Licensed under the GNU General Public License 
#------------------------------------------------------------------------------------
#Greatz to GXRG linux team.
#
#DESC: This tools is a simple bash script for changing mac address.
#

faked=True
whouse=`whoami`

function display_help (){
echo -e "macfaked 0.1 by aBi71 <l0g.bima@gmail.com>

Usage: $0 <options> [interface]

Ex: ./macfaked.sh -r eth0 
    ./macfaked.sh -m 00:11:22:33:44:55 wlan0

Options: 
   -r    random mac address
   -m    mac address

Please visit <http://projects.gxrg.org, http://abi71.wordpress.com>"
exit 0
}

if [ "$whouse" == "root" ]; then
	while [ "$faked" == "True" ]; do
	#variable random
	a=$(cat /dev/urandom | tr -cd '0-9a-f' | head -c2)
	b=$(cat /dev/urandom | tr -cd '0-9a-f' | head -c2)
	c=$(cat /dev/urandom | tr -cd '0-9a-f' | head -c2)
	d=$(cat /dev/urandom | tr -cd '0-9a-f' | head -c2)
	e=$(cat /dev/urandom | tr -cd '0-9a-f' | head -c2)
	f=$(cat /dev/urandom | tr -cd '0-9a-f' | head -c2)
		if [ $# -lt 1 ]; then
			display_help
		elif [ "$1" == "-r" ] && [ "$2" != "" ]; then
			down_iface=$(ifconfig $2 down 2> /tmp/macfaked.log; cat /tmp/macfaked.log)
  				if [ "$down_iface" == "" ]; then
					before=$(ifconfig $2 | grep HWaddr | awk '{print $5}')
					mac_changer=$(ifconfig $2 hw ether $a:$b:$c:$d:$e:$f 2> /tmp/macfaked.log; cat /tmp/macfaked.log)
					if [ "$mac_changer" == "" ]; then
                				echo "Changed: [$before]  ->  [$a:$b:$c:$d:$e:$f]"
						faked=False
					fi
				else
					echo "$2: No such device."
					faked=False
				fi
		elif [ "$1" == "-m" ] && [ "$2" != "" ] && [ "$3" != "" ]; then
			down_iface=$(ifconfig $3 down 2> /tmp/macfaked.log; cat /tmp/macfaked.log)
				if [ "$down_iface" == "" ]; then
					before=$(ifconfig $3 | grep HWaddr | awk '{print $5}')
					macAddress=$(echo $2 > /tmp/macchange.log ;wc /tmp/macchange.log | awk '{print $3}')
					if [ "$macAddress" == "18" ]; then
						mac_changer=$(ifconfig $3 hw ether $2 2> /tmp/macchange.log; cat /tmp/macchange.log)
					else
						mac_changer=failed
					fi

					if [ "$mac_changer" == "" ] && [ "$macAddress" == "18" ] ; then
						echo "Changed: [$before]  ->  [$2]"
						faked=False
					else
						echo "[!] Cannot assign requested address, please try again."
						faked=False
					fi
					
				else
				echo "$3: No such device."
				faked=False
				fi
		else
			display_help
		fi
	done
rm /tmp/macfaked.log 2> /dev/null
rm /tmp/macchange.log 2> /dev/null
else
echo "[!] You must be root."	
fi

