/*
root@ author by Rio
      http://www.shine-of-bara.blogspot.com

LINUX SYSTEM CLEANER version v.01 beta

by :
~@@ <G>unadarma <X>malang <R>easerch <G>rub @@~

for Gxrg Crew
30 Oktober 2010.
*/

#include <stdio.h>
#include <string.h>
int pil;
int b;
char app[23];
char gab[30];
void menu();
void tanya();
int main(){
	menu();
return 0;
	}
void menu()
{
		system("clear");
		printf("\t.:@ Linux System Cleaner @:.\n");
		printf("\n");
		printf("\tMenu :\n");
		printf("\t  1. Apt Clean \n");
		printf("\t  2. Delete Packege\n");
		printf("\t  3. Remove karnel\n");
		printf("\t  4. Delete file temp\n");
		printf("\t  5. Exit\n");
		printf("\n");
		printf("YOUR OPTIONS : ");scanf("%d",&pil);
		switch(pil){
		    case 1: system("sudo apt-get autoremove");
			    system("sudo apt-get autoclean");
			    printf("\nFinish.!!\n");tanya();break;
		    case 2: printf("Name package : ");scanf("%s",app);
		            sprintf(gab,"sudo dpkg -r %s --purge",app);
		            system(gab);
		            printf("Finish.!!\n");printf("\n");
		            tanya();break;
		    case 3: system("sudo dpkg --get-selections | grep linux-header");
		            system("sudo dpkg --get-selections | grep linux-image");
		            printf("\n");
		            printf("Warning [!]\n");
		            system("uname -r");
		            printf("don't delete your karnel which used  @ \n");
		            printf("\n");
		            printf("Input ex. 2.6.32-21");
		            printf("\n");
		            printf("Input karnel version for delete : ");
		            scanf("%s",app);
		            sprintf(gab,"sudo apt-get remove --purge %s-* ",app);
		            system(gab);
			    printf("\nFinish.!!\n");
			    tanya();break;
		    case 4: system("sudo find / -name *~ ");		    
		            printf("\nDelete file temp press 0 : ");scanf("%d",&b);
			    printf("\n");
			    if (b==0)
				{system("sudo find / -name *~ -delete");printf("Delete file temp succes.! n_nb\n");}
			    else
				printf("File is not delete\n"); 
		            	tanya();
		    case 5: printf("\nFinishing Program\n");system("date");printf("\n");system("exit");break;
	    	   default: printf("Syntax Error\n");printf("Finishing Program\n");system("date");printf("\n");break;
		}
}
void tanya(){
char a;
			printf("try again to clean your system [Y/t]: ");scanf("%s",&a);printf("\n");
			if (a=='Y'||a=='y'){
				menu();
				 }
			else if (a=='T'||a=='t') {
				printf("\n");
				printf("Finishing Program \n");
				system("date");
				system("exit");
				}
			else {
				printf("syntax error\n");
				printf("\n");
		 		}
   
}



