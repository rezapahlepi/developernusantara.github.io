#!/usr/bin/python
######################################################################
# port-scanner v.0.1                            (c) copyleft 09/2010 #
# Author: aBi71                                                      #
# Site: http://abi71.wordpress.com                                   #
# Email: l0g [dot] bima [at] gmail.com                               #
# Credits: [G]unadarma [X]malang [R]esearch [G]roups                 #
######################################################################
#Greatz to GXRG linux team.
#This program for educational purposes only.

import sys, socket

#Global Value
status = 0
timeout = 0.001
start_port = 20
end_port = 3306

#Service port dictionaries, For translate an internet port number to a service name.
#You can add the port number, Or please use module socket.getservbyport :D
service = {21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "domain", 80: "www", 110: "pop3", 111: "rpcbind", 135: "msrpc", 139: "netbios-ssn", 143: "imap", 199:"smux", 443: "https", 445: "microsoft-ds", 465: "smtps", 1720: "H.323/Q.931", 2046: "sdfunc", 2049: "nfs", 3306: "mysql", 5900: "vnc", 9876: "sd"}


#Main
def main():
	try:
		domain = socket.getfqdn(host)
		ipd = socket.gethostbyname_ex(domain)
		print 'Port-Scanner v.0.1'
		print 'Copyleft Sept 2010 - GXRG'
		print '\nScanning ports on ' + str(domain) + ' (' + str(ipd[2][0]) + ')'
		print '\nPORT\t' 'PROTO\t' 'STATUS\t' 'SERVICE'
		for port in range (start_port, end_port+1):
			scan(domain, port)
		if status == 0:
			print "\n[!] Port is not open, or connection problem." 
		print '\nDone !'
		sys.exit()
	except:
		sys.exit()

#Run Scan !!
def scan(host, port): #host=domain
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	try:
		global status
		sock.connect((host, port))
		sock.settimeout(timeout) 
		print '%d\t' 'tcp\t' 'open\t' % (port) + (service[port])
		status = 1
	except socket.error:
		status = status
        except KeyboardInterrupt:
		sys.exit()
	sock.close()
	
#Display Help
def  help():
		print 'Usage :' + sys.argv[0] + ' <options> [host]'
		print 'Options:'
  		print '    -h   display this help'
   		print '    -p   range port number\n'
		print 'Ex: ./port-scanner.py localhost'
		print '    ./portscanner.py -p 445 192.168.1.10'
		print '    ./portscanner.py -p 20 3306 domain.com\n'
		print 'Please visit <http://projects.gxrg.org, http://abi71.wordpress.com>'
		sys.exit()
		
#Console usage & Error check
if len(sys.argv) == 2 and sys.argv[1] == '-h':
	help()
if len(sys.argv) == 2 and len(sys.argv[1]) >=6:
	host = sys.argv[1]
	main()
if len(sys.argv) == 4 and sys.argv[1] == '-p':
	start_port = int(sys.argv[2]) 
	end_port = start_port
	host = sys.argv[3]
	main()
if len(sys.argv) == 5 and sys.argv[1] == '-p':
	start_port = int(sys.argv[2])
	end_port = int(sys.argv[3])
	host = sys.argv[4]
	if start_port <= end_port:
		main()
	else:
		help()
else:
	help()
