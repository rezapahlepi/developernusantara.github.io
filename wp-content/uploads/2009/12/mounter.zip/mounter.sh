clear
echo "            ~ G X R G ~    "
echo "(Gunadarma Xmalang Research Groups)"
echo 
echo "what you want??"
echo "1. mount partition"
echo "2. unmount partition"
echo "3. Cancel"
echo -n "your choice : "
read pil


function mounting
{
clear
echo "partition on your system..."
cat /etc/fstab
echo "enter name partition ? "
echo "example : for /dev/sda2"
echo "          you can type : sda2"
echo -n "your choice :"
read hd
echo
echo
echo "where you like to mount partition"
echo "1. hd0"
echo "2. hd1"
echo "3. hd2"
echo -n "your choice :"
read dir
if [ $dir = 1 ]; then
  dira="hd0"
elif [ $dir = 2 ]; then
  dira="hd1"
else
  dira="hd2"
fi
echo 
echo 
echo "Type partition"
echo "1. Linux Partition (ext2, ext3, ext4, etc)"
echo "2. ntfs"
echo -n "your choice :"
read par
if [ $par = 1 ]; then
  part="mount"
else
  part="mount.ntfs-3g"
fi
echo 
echo 
clear
echo "mounting partition"
$part /dev/$hd /media/$dira
echo "mounting done for $hd to directori $dira [OK]"
echo 
echo "thanks for using" 
echo "~~[NEver-Mind]~~" 
echo
echo "press any key for open partition" 
read
dolphin /media/$dir
}

function umounting
{
clear
echo "unmount partition ?? "
echo "1. hd0"
echo "2. hd1"
echo "3. hd2"
echo -n "your choice :"
read dir
if [ $dir = 1 ]; then
  dira="hd0"
elif [ $dir = 2 ]; then
  dira="hd1"
else
  dira="hd2"
fi
echo 
echo 
clear
echo "unmounting partition Now"
umount /media/$dira
echo "unmounting for $hd to directori $dira  [OK]"
echo 
echo "thanks for using" 
echo "~~[NEver-Mind]~~" 
read
dolphin /media/home
}

case $pil in
1)
  mounting;
  ;;
2)
  umounting;
  ;;
3)
  echo "thanks for using" 
  echo "~~[NEver-Mind]~~" 
  read
  ;;
esac