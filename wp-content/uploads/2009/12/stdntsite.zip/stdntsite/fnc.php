<?
// trimm username disini
$uname = trim($_POST['uname']);
$pass = trim($_POST['pass']);

if (empty($_POST)) exit;

// fungsi kecil
function studentsite($uname, $pass){
$post_autologin = $_POST['autologin'];
$mbox = @imap_open("{203.130.233.20:110/pop3}", $uname.'@student.gunadarma.ac.id', $pass);
if ($mbox) {
  print ("<font color=\"#008000\">logged in -> welcome ".$uname."@studentsite.gunadarma.ac.id!</font>");
}
else {
  print ("<font color=\"#FF0000\">username atau password salah</font>");
}
    }
?>