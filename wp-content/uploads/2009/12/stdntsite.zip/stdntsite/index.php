<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <title></title>
</head>

<body>
<center>
modul login studentsite.<br /><br />
<form method="post" action="<? echo $_SERVER['PHP_SELF']; ?>">
username: <input type="text" name="uname" /><br />
password: <input type="password" name="pass" /><br />
<input type="submit" value="login" />
</form><br />
<? include ("fnc.php");
studentsite($uname, $pass);
 ?>
</center>
</body>

</html>
