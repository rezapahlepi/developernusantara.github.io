#!/usr/bin/python
import codecs

import os.path

import urllib

import urllib2

import cookielib

#######################################
############### Konfigurasi Akun
#######################################
UserName = 'username'
PassWord = 'fake pass'
ServerName = 'speed.travian.com.my'


# for more info cek the help!



COOKIEFILE = 'travian.cookie'



cj = cookielib.LWPCookieJar()

if os.path.isfile(COOKIEFILE):

   cj.load(COOKIEFILE)

opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

urllib2.install_opener(opener)


txheaders =  {'User-agent' : 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT)'}
theurl = 'http://' + ServerName + '/login.php'

txdata = None



try:

   req = urllib2.Request(theurl, txdata, txheaders)

   handle = urllib2.urlopen(req)



except IOError, e:

   print 'Failed to connect "%s".' % theurl

   if hasattr(e, 'code'):

      print 'Failed with error code - %s.' % e.code

   elif hasattr(e, 'reason'):

      print "The error object has the following 'reason' attribute :"

      print e.reason

   

else:

   strForm = handle.read().decode('UTF-8')

   strForm = strForm[strForm.find(u'<input type="hidden" name="login" value="')+len(u'<input type="hidden" name="login" value="'):]

   loginvalue = strForm[:10]

   strForm = strForm[strForm.find(u'Nama:'):]

   strForm = strForm[strForm.find(u'name="')+len(u'name="'):]

   userfield = strForm[:7]

   strForm = strForm[strForm.find(u'Kata Laluan:'):]

   strForm = strForm[strForm.find(u'name="')+len(u'name="'):]

   passfield = strForm[:7]

   strForm = strForm[strForm.find(u'name="')+len(u'name="'):]

   extrafield = strForm[:7]

theurl = 'http://' + ServerName + '/dorf1.php'

txdata = urllib.urlencode({'w':'1280:1024','login':loginvalue.encode('UTF-8'),userfield.encode('UTF-8'):UserName.encode('UTF-8'),passfield.encode('UTF-8'):PassWord.encode('UTF-8'),extrafield.encode('UTF-8'):'','autologin':'ja'})

   

req = urllib2.Request(theurl, txdata, txheaders)


x=1
while x<1000:
   urllib2.urlopen(req)
   print x
   x=x+1